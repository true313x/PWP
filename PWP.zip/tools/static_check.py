#!/usr/bin/env python3
"""Cheap static checks (there is no Kotlin compiler in this environment):
package/directory agreement, balanced brackets, and that every com.pwp.reader.* import resolves to a declaration."""
import re, sys, pathlib
root = pathlib.Path(__file__).resolve().parent.parent
src = root / "app/src"
files = [p for p in src.rglob("*.kt")]
decl_re = re.compile(r"^\s*(?:@\w+(?:\([^)]*\))?\s+)*(?:(?:public|private|internal|protected|data|sealed|enum|abstract|open|inline|suspend|operator|const|lateinit|override|annotation|value|tailrec|infix|external|fun interface)\s+)*(class|interface|object|fun|val|var|typealias)\s+(?:<[^>]+>\s*)?(?:[\w.<>?, ]+\.)?(\w+)", re.M)

pkg_decls = {}
errors = []
for p in files:
    text = p.read_text()
    m = re.search(r"^package\s+([\w.]+)", text, re.M)
    if not m: errors.append(f"{p}: no package"); continue
    pkg = m.group(1)
    rel = p.parent.relative_to(src).parts
    expected = ".".join(rel[rel.index("java") + 1:]) if "java" in rel else None
    if expected and expected != pkg: errors.append(f"{p.name}: package {pkg} != dir {expected}")
    for d in decl_re.finditer(text):
        pkg_decls.setdefault(pkg, set()).add(d.group(2))
    # enum entries and companion members are importable through their parents; keep it simple.

TOKEN = re.compile(r'''("""(?:.|\n)*?""")|("(?:\\.|[^"\\\n])*")|('(?:\\.|[^'\\\n])')|(//[^\n]*)|(/\*.*?\*/)''', re.S)

def strip(s):
    """Single pass so that '//' inside a string literal is not mistaken for a comment."""
    def repl(m):
        if m.group(1) or m.group(2): return '""'
        if m.group(3): return "''"
        return ""
    return TOKEN.sub(repl, s)

for p in files:
    text = p.read_text()
    body = strip(text)
    for o, c in ("()", "[]", "{}"):
        if body.count(o) != body.count(c):
            errors.append(f"{p.name}: unbalanced {o}{c} ({body.count(o)} vs {body.count(c)})")
    for m in re.finditer(r"^import\s+(com\.pwp\.reader\.[\w.]+?)(?:\s+as\s+\w+)?\s*$", text, re.M):
        full = m.group(1)
        if full.endswith(".*"): continue
        pkg, _, name = full.rpartition(".")
        if name == "R" or full.endswith(".BuildConfig"): continue
        if name not in pkg_decls.get(pkg, set()):
            # nested enum / companion access, e.g. Foo.Bar -> check parent package decl
            parent_pkg, _, parent = pkg.rpartition(".")
            if parent in pkg_decls.get(parent_pkg, set()): continue
            errors.append(f"{p.name}: unresolved import {full}")

if errors:
    print("\n".join(sorted(set(errors)))); sys.exit(1)
print(f"static check OK: {len(files)} Kotlin files")
