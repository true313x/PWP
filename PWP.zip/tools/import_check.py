#!/usr/bin/env python3
"""Heuristic: flags commonly used Compose/AndroidX symbols that are used in a file but not imported."""
import re, pathlib, sys
root = pathlib.Path(__file__).resolve().parent.parent
TOKEN = re.compile(r'''("""(?:.|\n)*?""")|("(?:\\.|[^"\\\n])*")|('(?:\\.|[^'\\\n])')|(//[^\n]*)|(/\*.*?\*/)''', re.S)
strip = lambda s: TOKEN.sub(lambda m: '""' if (m.group(1) or m.group(2)) else ("''" if m.group(3) else ""), s)

F = "androidx.compose.foundation."
L = F + "layout."
M = "androidx.compose.material3."
R = "androidx.compose.runtime."
U = "androidx.compose.ui."
SYM = {
 "fillMaxSize": L, "fillMaxWidth": L, "fillMaxHeight": L, "padding": L, "size": L, "width": L, "height": L,
 "widthIn": L, "heightIn": L, "offset": L, "aspectRatio": L, "statusBarsPadding": L, "navigationBarsPadding": L,
 "Spacer": L, "Row": L, "Column": L, "Box": L, "BoxWithConstraints": L, "PaddingValues": L, "Arrangement": L,
 "background": F, "border": F, "clickable": F, "Image": F, "Canvas": F, "BorderStroke": F,
 "LazyColumn": F + "lazy.", "rememberLazyListState": F + "lazy.", "LazyRow": F + "lazy.",
 "clip": U + "draw.", "clipToBounds": U + "draw.", "alpha": U + "draw.", "drawBehind": U + "draw.",
 "Text": M, "Icon": M, "IconButton": M, "Surface": M, "MaterialTheme": M, "TextButton": M, "AlertDialog": M,
 "DropdownMenu": M, "DropdownMenuItem": M, "Slider": M, "Switch": M, "FilterChip": M, "HorizontalDivider": M,
 "Button": M, "OutlinedButton": M, "OutlinedTextField": M, "TextField": M, "Scaffold": M,
 "remember": R, "mutableStateOf": R, "getValue": R, "setValue": R, "LaunchedEffect": R, "DisposableEffect": R,
 "rememberCoroutineScope": R, "derivedStateOf": R, "produceState": R, "rememberUpdatedState": R, "snapshotFlow": R,
 "mutableIntStateOf": R, "mutableFloatStateOf": R, "CompositionLocalProvider": R, "SideEffect": R,
 "Modifier": U, "Alignment": U, "stringResource": U + "res.", "painterResource": U + "res.",
 "graphicsLayer": U + "graphics.", "Color": U + "graphics.", "dp": U + "unit.", "sp": U + "unit.",
 "RoundedCornerShape": F + "shape.", "CircleShape": F + "shape.",
 "collectAsStateWithLifecycle": "androidx.lifecycle.compose.", "hiltViewModel": "androidx.hilt.navigation.compose.",
 "pointerInput": U + "input.pointer.", "TextOverflow": U + "text.style.", "TextAlign": U + "text.style.",
 "FontWeight": U + "text.font.", "LocalContext": U + "platform.", "LocalDensity": U + "platform.",
 "ContentScale": U + "layout.", "Dispatchers": "kotlinx.coroutines.", "withContext": "kotlinx.coroutines.",
 "launch": "kotlinx.coroutines.", "viewModelScope": "androidx.lifecycle.", "stateIn": "kotlinx.coroutines.flow.",
 "SharingStarted": "kotlinx.coroutines.flow.", "combine": "kotlinx.coroutines.flow.", "first": "kotlinx.coroutines.flow.",
 "map": "kotlinx.coroutines.flow.", "Flow": "kotlinx.coroutines.flow.", "MutableStateFlow": "kotlinx.coroutines.flow.",
 "StateFlow": "kotlinx.coroutines.flow.",
}
# a few symbols are legitimately resolved without an import in some files; handled by per-symbol guards below
LOCAL_OK = {"map", "first", "launch", "size", "width", "height", "padding", "border", "background", "offset", "Color", "Image", "combine", "Flow"}
problems = []
for p in sorted((root / "app/src").rglob("*.kt")):
    raw = p.read_text()
    body = strip(raw)
    imports = re.findall(r"^import\s+([\w.]+)(?:\s+as\s+(\w+))?", raw, re.M)
    names = {(a or full.rsplit(".", 1)[-1]) for full, a in imports}
    wild = {full[:-2] for full, a in imports if full.endswith(".*")}
    declared = set(re.findall(r"\b(?:class|object|interface|fun|val|var)\s+(?:<[^>]*>\s*)?(?:[\w.]+\.)?(\w+)", body))
    for sym, pkg in SYM.items():
        if sym in names or any(pkg.rstrip(".") == w for w in wild) or sym in declared: continue
        # usage patterns: modifier chain  .sym(  | call  sym(  | type/object  sym.  | type use  : Sym
        if sym[0].islower():
            pat = rf"(?:\.|\b){sym}\s*[({{]|\bby\s+{sym}\b|\bimport"
            used = re.search(rf"(?<![\w]){sym}\s*[({{]", body) or re.search(rf"\.{sym}\b", body)
        else:
            used = re.search(rf"(?<![\w.]){sym}\b", body)
        if used and sym not in LOCAL_OK:
            problems.append(f"{p.relative_to(root)}: '{sym}' used but not imported")
        elif used and sym in LOCAL_OK:
            # member-style/receiver usage is common for these; only flag clear free-function/type use
            if sym in {"Color", "Image", "Flow"} and re.search(rf"(?<![\w.]){sym}\b", body):
                problems.append(f"{p.relative_to(root)}: '{sym}' used but not imported")
print("\n".join(problems) if problems else "import heuristic: no missing imports found")
sys.exit(1 if problems else 0)
