# Room, Hilt and Compose ship consumer rules. Nothing extra is required.
-keep class org.xmlpull.v1.** { *; }
