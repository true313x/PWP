package com.pwp.reader.feature

import com.pwp.reader.feature.word.DocBreak
import com.pwp.reader.feature.word.DocParagraph
import com.pwp.reader.feature.word.DocSegment
import com.pwp.reader.feature.word.DocTable
import com.pwp.reader.feature.word.DocxParser
import com.pwp.reader.feature.word.ParaAlign
import com.pwp.reader.feature.word.searchableText
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class DocxParserTest {
    @get:Rule val tmp = TemporaryFolder()

    private val ns = "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" " +
        "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\""

    private fun docx(body: String, numbering: String? = null, styles: String? = null, rels: String? = null): File {
        val file = tmp.newFile()
        ZipOutputStream(file.outputStream()).use { zip ->
            fun put(name: String, text: String) { zip.putNextEntry(ZipEntry(name)); zip.write(text.toByteArray()); zip.closeEntry() }
            put("word/document.xml", "<?xml version=\"1.0\"?><w:document $ns><w:body>$body</w:body></w:document>")
            rels?.let { put("word/_rels/document.xml.rels", "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">$it</Relationships>") }
            numbering?.let { put("word/numbering.xml", "<w:numbering $ns>$it</w:numbering>") }
            styles?.let { put("word/styles.xml", "<w:styles $ns>$it</w:styles>") }
        }
        return file
    }

    private fun parse(file: File) = DocxParser.parse(file, tmp.newFolder())
    private fun paragraphs(file: File) = parse(file).blocks.filterIsInstance<DocParagraph>()

    @Test fun parsesHeadingsAndInlineFormatting() {
        val styles = "<w:style w:type=\"paragraph\" w:styleId=\"Heading1\"><w:name w:val=\"heading 1\"/><w:rPr><w:b/><w:sz w:val=\"32\"/></w:rPr></w:style>"
        val body = "<w:p><w:pPr><w:pStyle w:val=\"Heading1\"/></w:pPr><w:r><w:t>Chapter</w:t></w:r></w:p>" +
            "<w:p><w:pPr><w:jc w:val=\"center\"/></w:pPr><w:r><w:rPr><w:b/><w:i/><w:color w:val=\"FF0000\"/><w:sz w:val=\"44\"/></w:rPr><w:t>Bold</w:t></w:r><w:r><w:t xml:space=\"preserve\"> plain</w:t></w:r></w:p>"
        val p = paragraphs(docx(body, styles = styles))
        assertEquals(1, p[0].headingLevel)
        assertEquals("Chapter", p[0].plainText)
        assertEquals(ParaAlign.CENTER, p[1].align)
        val runs = (p[1].segments[0] as DocSegment.Text).runs
        assertTrue(runs[0].bold && runs[0].italic)
        assertEquals(0xFFFF0000.toInt(), runs[0].color)
        assertEquals(2f, runs[0].sizeRatio!!, 0.001f)
        assertEquals(" plain", runs[1].text)
        assertFalse(runs[1].bold)
    }

    @Test fun numbersOrderedListsAndBulletsLists() {
        val numbering =
            "<w:abstractNum w:abstractNumId=\"0\"><w:lvl w:ilvl=\"0\"><w:start w:val=\"1\"/><w:numFmt w:val=\"decimal\"/><w:lvlText w:val=\"%1.\"/></w:lvl>" +
            "<w:lvl w:ilvl=\"1\"><w:start w:val=\"1\"/><w:numFmt w:val=\"lowerLetter\"/><w:lvlText w:val=\"%2)\"/></w:lvl></w:abstractNum>" +
            "<w:abstractNum w:abstractNumId=\"1\"><w:lvl w:ilvl=\"0\"><w:numFmt w:val=\"bullet\"/><w:lvlText w:val=\"-\"/></w:lvl></w:abstractNum>" +
            "<w:num w:numId=\"1\"><w:abstractNumId w:val=\"0\"/></w:num><w:num w:numId=\"2\"><w:abstractNumId w:val=\"1\"/></w:num>"
        fun item(num: Int, lvl: Int, text: String) =
            "<w:p><w:pPr><w:numPr><w:ilvl w:val=\"$lvl\"/><w:numId w:val=\"$num\"/></w:numPr></w:pPr><w:r><w:t>$text</w:t></w:r></w:p>"
        val body = item(1, 0, "one") + item(1, 0, "two") + item(1, 1, "sub") + item(1, 0, "three") + item(2, 0, "dot")
        val labels = paragraphs(docx(body, numbering = numbering)).map { it.listLabel }
        assertEquals(listOf("1.", "2.", "a)", "3.", "•"), labels)
    }

    @Test fun parsesTablesWithSpansAndShading() {
        val body = "<w:tbl><w:tr><w:trPr><w:tblHeader/></w:trPr>" +
            "<w:tc><w:tcPr><w:gridSpan w:val=\"2\"/><w:shd w:fill=\"DDEEFF\"/></w:tcPr><w:p><w:r><w:t>Head</w:t></w:r></w:p></w:tc></w:tr>" +
            "<w:tr><w:tc><w:p><w:r><w:t>A</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>B</w:t></w:r></w:p></w:tc></w:tr></w:tbl>"
        val table = parse(docx(body)).blocks.filterIsInstance<DocTable>().single()
        assertEquals(2, table.rows.size)
        assertTrue(table.rows[0].header)
        assertEquals(2, table.rows[0].cells[0].span)
        assertEquals(0xFFDDEEFF.toInt(), table.rows[0].cells[0].fill)
        assertEquals("A\tB", table.rows[1].cells.joinToString("\t") { c -> c.blocks.joinToString { it.searchableText() } })
    }

    @Test fun keepsExternalHyperlinksOnTheirRuns() {
        val rels = "<Relationship Id=\"rId9\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink\" Target=\"https://example.org/\" TargetMode=\"External\"/>"
        val body = "<w:p><w:hyperlink r:id=\"rId9\"><w:r><w:t>site</w:t></w:r></w:hyperlink></w:p>"
        val run = (paragraphs(docx(body, rels = rels)).single().segments.single() as DocSegment.Text).runs.single()
        assertEquals("https://example.org/", run.link)
    }

    @Test fun preservesArabicTextAndBidirectionalParagraphs() {
        val body = "<w:p><w:pPr><w:bidi/><w:jc w:val=\"left\"/></w:pPr><w:r><w:t>مرحبا بالعالم Hello ١٢٣</w:t></w:r></w:p>"
        val p = paragraphs(docx(body)).single()
        assertTrue(p.rtl)
        assertEquals("مرحبا بالعالم Hello ١٢٣", p.plainText)
        assertEquals(ParaAlign.START, p.align)
    }

    @Test fun emitsPageAndSectionBreaks() {
        val body = "<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p><w:p><w:pPr><w:sectPr/></w:pPr><w:r><w:t>x</w:t></w:r></w:p>"
        val breaks = parse(docx(body)).blocks.filterIsInstance<DocBreak>()
        assertEquals(listOf(true, false), breaks.map { it.page })
    }

    @Test fun reportsUnsupportedGraphicsInsteadOfFailing() {
        val body = "<w:p><w:r><w:drawing><wp:inline xmlns:wp=\"x\"><a:graphic xmlns:a=\"y\"><a:graphicData uri=\"chart\"/></a:graphic></wp:inline></w:drawing></w:r><w:r><w:t>after</w:t></w:r></w:p>"
        val doc = parse(docx(body))
        assertTrue(doc.partial)
        assertEquals("after", (doc.blocks.single() as DocParagraph).plainText)
    }

    @Test fun skipsDeletedTrackedText() {
        val body = "<w:p><w:r><w:t>keep</w:t></w:r><w:del><w:r><w:delText>gone</w:delText></w:r></w:del></w:p>"
        assertEquals("keep", paragraphs(docx(body)).single().plainText)
    }

    @Test fun rejectsArchivesThatAreNotWordDocuments() {
        val file = tmp.newFile()
        ZipOutputStream(file.outputStream()).use { it.putNextEntry(ZipEntry("hello.txt")); it.write(1); it.closeEntry() }
        try { parse(file); fail("expected IOException") } catch (e: IOException) { /* expected */ }
    }

    @Test fun rejectsCorruptXml() {
        val file = docx("<w:p><w:r><w:t>oops</w:r></w:p>")
        try { parse(file); fail("expected IOException") } catch (e: IOException) { /* expected */ }
    }
}
