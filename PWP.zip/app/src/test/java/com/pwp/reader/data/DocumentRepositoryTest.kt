package com.pwp.reader.data

import com.pwp.reader.core.storage.DocumentSource
import com.pwp.reader.core.storage.FileInfo
import com.pwp.reader.data.database.BookmarkDao
import com.pwp.reader.data.database.BookmarkEntity
import com.pwp.reader.data.database.DocumentDao
import com.pwp.reader.data.database.DocumentEntity
import com.pwp.reader.data.database.DocumentTextEntity
import com.pwp.reader.data.database.TextIndexDao
import com.pwp.reader.data.repository.DocumentRepositoryImpl
import com.pwp.reader.domain.model.DocumentFormat
import com.pwp.reader.domain.model.OpenResult
import com.pwp.reader.domain.model.UserSettings
import com.pwp.reader.domain.repository.SettingsRepository
import com.pwp.reader.domain.usecase.SaveReadingPosition
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

private class FakeDocumentDao : DocumentDao {
    val items = MutableStateFlow<Map<String, DocumentEntity>>(emptyMap())
    private fun change(uri: String, f: (DocumentEntity) -> DocumentEntity) {
        items.value[uri]?.let { items.value = items.value + (uri to f(it)) }
    }
    override fun observeAll(): Flow<List<DocumentEntity>> = items.map { it.values.sortedByDescending { e -> e.lastOpenedAt } }
    override fun observe(uri: String): Flow<DocumentEntity?> = items.map { it[uri] }
    override suspend fun get(uri: String) = items.value[uri]
    override suspend fun allUris() = items.value.keys.toList()
    override suspend fun upsert(entity: DocumentEntity) { items.value = items.value + (entity.uri to entity) }
    override suspend fun setFavorite(uri: String, favorite: Boolean) = change(uri) { it.copy(isFavorite = favorite) }
    override suspend fun setPosition(uri: String, position: Int, offset: Int) = change(uri) { it.copy(lastPosition = position, lastOffset = offset) }
    override suspend fun setPageCount(uri: String, count: Int) = change(uri) { it.copy(pageCount = count) }
    override suspend fun touch(uri: String, time: Long) = change(uri) { it.copy(lastOpenedAt = time) }
    override suspend fun delete(uri: String) { items.value = items.value - uri }
    override suspend fun deleteAll() { items.value = emptyMap() }
}

private class FakeBookmarkDao : BookmarkDao {
    val items = MutableStateFlow<List<BookmarkEntity>>(emptyList())
    private var nextId = 1L
    override fun observe(uri: String): Flow<List<BookmarkEntity>> = items.map { l -> l.filter { it.documentUri == uri }.sortedBy { it.position } }
    override suspend fun upsert(entity: BookmarkEntity) { items.value = items.value + entity.copy(id = nextId++) }
    override suspend fun delete(id: Long) { items.value = items.value.filterNot { it.id == id } }
}

private class FakeTextIndexDao(private val docs: FakeDocumentDao) : TextIndexDao {
    val content = HashMap<String, String>()
    override suspend fun upsert(entity: DocumentTextEntity) { content[entity.uri] = entity.content }
    override suspend fun has(uri: String) = uri in content
    override suspend fun search(pattern: String): List<DocumentEntity> {
        val needle = pattern.trim('%').replace("\\%", "%").replace("\\_", "_").replace("\\\\", "\\")
        return content.filter { it.value.contains(needle) }.keys.mapNotNull { docs.items.value[it] }
    }
}

private class FakeSource : DocumentSource {
    val files = HashMap<String, FileInfo>()
    val persisted = ArrayList<String>()
    val released = ArrayList<String>()
    override fun query(uri: String) = files[uri]
    override fun persistAccess(uri: String) { persisted += uri }
    override fun releaseAccess(uri: String) { released += uri }
}

private class FakeSettings(initial: UserSettings = UserSettings()) : SettingsRepository {
    val state = MutableStateFlow(initial)
    override val settings: Flow<UserSettings> = state
    override suspend fun update(transform: (UserSettings) -> UserSettings) { state.value = transform(state.value) }
}

class DocumentRepositoryTest {
    private val docs = FakeDocumentDao()
    private val bookmarks = FakeBookmarkDao()
    private val index = FakeTextIndexDao(docs)
    private val source = FakeSource()
    private val repo = DocumentRepositoryImpl(docs, bookmarks, index, source)

    private val pdf = "content://x/report"

    @Test fun opensAndRegistersASupportedDocument() = runTest {
        source.files[pdf] = FileInfo("report.pdf", 2048, "application/pdf")
        val result = repo.open(pdf)
        assertTrue(result is OpenResult.Opened)
        val doc = (result as OpenResult.Opened).document
        assertEquals(DocumentFormat.PDF, doc.format)
        assertEquals(2048L, doc.sizeBytes)
        assertEquals(listOf(pdf), source.persisted)
        assertEquals(1, repo.observeAll().first().size)
    }

    @Test fun rejectsLegacyFormatsWithoutStoringThem() = runTest {
        source.files["content://x/old"] = FileInfo("old.doc", 10, "application/msword")
        assertEquals(OpenResult.Unsupported, repo.open("content://x/old"))
        assertTrue(repo.observeAll().first().isEmpty())
    }

    @Test fun reportsMissingFilesAsUnavailable() = runTest {
        assertEquals(OpenResult.Unavailable, repo.open("content://x/gone"))
    }

    @Test fun reopeningKeepsFavoriteAndReadingPosition() = runTest {
        source.files[pdf] = FileInfo("report.pdf", 2048, "application/pdf")
        repo.open(pdf)
        repo.setFavorite(pdf, true)
        repo.savePosition(pdf, 7, 120)
        repo.open(pdf)
        val doc = repo.get(pdf)!!
        assertTrue(doc.isFavorite)
        assertEquals(7, doc.lastPosition)
        assertEquals(120, doc.lastOffset)
    }

    @Test fun savingPositionClampsNegativeValues() = runTest {
        source.files[pdf] = FileInfo("report.pdf", 1, "application/pdf")
        repo.open(pdf)
        repo.savePosition(pdf, -3, -9)
        assertEquals(0, repo.get(pdf)!!.lastPosition)
    }

    @Test fun removingAndClearingReleasesAccess() = runTest {
        source.files[pdf] = FileInfo("a.pdf", 1, "application/pdf")
        source.files["content://x/b"] = FileInfo("b.docx", 1, null)
        repo.open(pdf); repo.open("content://x/b")
        repo.remove(pdf)
        assertNull(repo.get(pdf))
        assertEquals(listOf(pdf), source.released)
        repo.clearAll()
        assertTrue(repo.observeAll().first().isEmpty())
        assertTrue(source.released.contains("content://x/b"))
    }

    @Test fun addsAndRemovesBookmarks() = runTest {
        source.files[pdf] = FileInfo("a.pdf", 1, "application/pdf")
        repo.open(pdf)
        repo.addBookmark(pdf, 4, null)
        repo.addBookmark(pdf, 2, "intro")
        val list = repo.observeBookmarks(pdf).first()
        assertEquals(listOf(2, 4), list.map { it.position })
        repo.removeBookmark(list.first().id)
        assertEquals(listOf(4), repo.observeBookmarks(pdf).first().map { it.position })
    }

    @Test fun contentSearchIsScriptAware() = runTest {
        source.files["content://x/w"] = FileInfo("مذكرة.docx", 1, null)
        repo.open("content://x/w")
        repo.indexText("content://x/w", "تقرير المشروع النهائي مُحَمَّد")
        assertTrue(repo.hasTextIndex("content://x/w"))
        assertEquals(1, repo.searchContent("محمد").size)
        assertTrue(repo.searchContent("غير موجود").isEmpty())
        assertTrue(repo.searchContent("   ").isEmpty())
    }

    @Test fun indexingAnUnknownDocumentIsIgnored() = runTest {
        repo.indexText("content://x/none", "text")
        assertFalse(repo.hasTextIndex("content://x/none"))
    }

    @Test fun readingPositionIsOnlySavedWhenEnabled() = runTest {
        source.files[pdf] = FileInfo("a.pdf", 1, "application/pdf")
        repo.open(pdf)
        val settings = FakeSettings(UserSettings(rememberPosition = false))
        val save = SaveReadingPosition(repo, settings)
        save(pdf, 9, 1)
        assertEquals(0, repo.get(pdf)!!.lastPosition)
        settings.update { it.copy(rememberPosition = true) }
        save(pdf, 9, 1)
        assertEquals(9, repo.get(pdf)!!.lastPosition)
        assertNotNull(repo.get(pdf))
    }
}
