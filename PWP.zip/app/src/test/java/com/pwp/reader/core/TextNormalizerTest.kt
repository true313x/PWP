package com.pwp.reader.core

import com.pwp.reader.core.common.Opc
import com.pwp.reader.core.common.TextNormalizer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TextNormalizerTest {
    @Test fun foldsArabicDiacriticsAndLetterVariants() {
        assertEquals(TextNormalizer.normalize("محمد"), TextNormalizer.normalize("مُحَمَّد"))
        assertEquals(TextNormalizer.normalize("أحمد"), TextNormalizer.normalize("احمد"))
        assertEquals(TextNormalizer.normalize("مدرسة"), TextNormalizer.normalize("مدرسه"))
    }

    @Test fun foldsPersianLettersAndDigits() {
        assertEquals(TextNormalizer.normalize("کتاب"), TextNormalizer.normalize("كتاب"))
        assertEquals(TextNormalizer.normalize("فایل ۱۲۳"), TextNormalizer.normalize("فایل 123"))
        assertEquals("123", TextNormalizer.normalize("١٢٣"))
    }

    @Test fun isCaseInsensitiveForLatin() {
        assertEquals("report q3", TextNormalizer.normalize("REPORT Q3"))
    }

    @Test fun matchRangesPointIntoTheOriginalText() {
        val text = "تقرير مُحَمَّد النهائي"
        val matches = TextNormalizer.findMatches(text, "محمد")
        assertEquals(1, matches.size)
        assertEquals("مُحَمَّد", text.substring(matches[0].first, matches[0].last + 1))
    }

    @Test fun findsMultipleNonOverlappingMatches() {
        assertEquals(3, TextNormalizer.findMatches("aaa Aaa aAa", "AAA").size)
        assertTrue(TextNormalizer.findMatches("abc", "").isEmpty())
    }

    @Test fun resolvesRelationshipTargets() {
        assertEquals("word/media/image1.png", Opc.resolve("word/document.xml", "media/image1.png"))
        assertEquals("ppt/media/a.png", Opc.resolve("ppt/slides/slide1.xml", "../media/a.png"))
        assertEquals("ppt/slideLayouts/l.xml", Opc.resolve("ppt/slides/slide1.xml", "/ppt/slideLayouts/l.xml"))
        assertEquals("ppt/_rels/presentation.xml.rels", Opc.relsPathFor("ppt/presentation.xml"))
    }
}
