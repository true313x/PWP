package com.pwp.reader.domain

import com.pwp.reader.domain.model.DocumentFormat
import com.pwp.reader.domain.model.PwpDocument
import com.pwp.reader.domain.model.SortField
import com.pwp.reader.domain.model.SortOrder
import com.pwp.reader.domain.usecase.FilterAndSortDocuments
import org.junit.Assert.assertEquals
import org.junit.Test

class FilterAndSortDocumentsTest {
    private val useCase = FilterAndSortDocuments()

    private fun doc(name: String, format: DocumentFormat, size: Long?, opened: Long) = PwpDocument(
        uri = "content://x/$name", name = name, format = format, sizeBytes = size, pageCount = null,
        lastOpenedAt = opened, isFavorite = false, lastPosition = 0, lastOffset = 0,
    )

    private val docs = listOf(
        doc("beta.pdf", DocumentFormat.PDF, 300, 10),
        doc("Alpha.docx", DocumentFormat.DOCX, 100, 30),
        doc("gamma.pptx", DocumentFormat.PPTX, null, 20),
        doc("تقرير مُحَمَّد.pdf", DocumentFormat.PDF, 50, 5),
    )

    @Test fun sortsByNameCaseInsensitively() {
        val names = useCase(docs, order = SortOrder(SortField.NAME, ascending = true)).map { it.name }
        assertEquals(listOf("Alpha.docx", "beta.pdf", "gamma.pptx"), names.take(3))
    }

    @Test fun sortsByDateNewestFirstByDefault() {
        assertEquals("Alpha.docx", useCase(docs).first().name)
    }

    @Test fun sortsBySizeWithUnknownSizesLast() {
        val names = useCase(docs, order = SortOrder(SortField.SIZE, ascending = false)).map { it.name }
        assertEquals("gamma.pptx", names.last())
        assertEquals("beta.pdf", names.first())
    }

    @Test fun sortsByTypeThenName() {
        val result = useCase(docs, order = SortOrder(SortField.TYPE, ascending = true))
        assertEquals(DocumentFormat.PDF, result.first().format)
        assertEquals(DocumentFormat.PPTX, result.last().format)
    }

    @Test fun filtersByFormat() {
        assertEquals(2, useCase(docs, format = DocumentFormat.PDF).size)
    }

    @Test fun filenameSearchIsScriptAware() {
        assertEquals(listOf("تقرير مُحَمَّد.pdf"), useCase(docs, query = "محمد").map { it.name })
        assertEquals(listOf("Alpha.docx"), useCase(docs, query = "ALPHA").map { it.name })
    }

    @Test fun legacyFormatsAreNotDetected() {
        assertEquals(null, DocumentFormat.detect("old.doc", "application/msword"))
        assertEquals(null, DocumentFormat.detect("old.ppt", "application/vnd.ms-powerpoint"))
        assertEquals(DocumentFormat.PDF, DocumentFormat.detect("noext", "application/pdf"))
        assertEquals(DocumentFormat.DOCX, DocumentFormat.detect("A.DOCX", null))
    }
}
