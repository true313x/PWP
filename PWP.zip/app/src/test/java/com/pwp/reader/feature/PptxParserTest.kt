package com.pwp.reader.feature

import com.pwp.reader.feature.powerpoint.BoxShape
import com.pwp.reader.feature.powerpoint.Hsl
import com.pwp.reader.feature.powerpoint.PptAlign
import com.pwp.reader.feature.powerpoint.PptxPackage
import com.pwp.reader.feature.powerpoint.UnsupportedKind
import com.pwp.reader.feature.powerpoint.UnsupportedShape
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class PptxParserTest {
    @get:Rule val tmp = TemporaryFolder()

    private val a = "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\""
    private val p = "xmlns:p=\"http://schemas.openxmlformats.org/presentationml/2006/main\""
    private val r = "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\""
    private val relNs = "xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\""
    private val relType = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

    private fun pptx(slideShapes: String, withSlides: Boolean = true): File {
        val file = tmp.newFile()
        ZipOutputStream(file.outputStream()).use { zip ->
            fun put(name: String, text: String) { zip.putNextEntry(ZipEntry(name)); zip.write(text.toByteArray()); zip.closeEntry() }
            put("ppt/presentation.xml",
                "<p:presentation $p $r><p:sldIdLst>" + (if (withSlides) "<p:sldId id=\"256\" r:id=\"rId1\"/>" else "") +
                    "</p:sldIdLst><p:sldSz cx=\"9144000\" cy=\"5143500\"/></p:presentation>")
            put("ppt/_rels/presentation.xml.rels", "<Relationships $relNs><Relationship Id=\"rId1\" Type=\"$relType/slide\" Target=\"slides/slide1.xml\"/></Relationships>")
            put("ppt/slides/slide1.xml", "<p:sld $p $a $r><p:cSld><p:spTree>$slideShapes</p:spTree></p:cSld></p:sld>")
            put("ppt/slides/_rels/slide1.xml.rels", "<Relationships $relNs><Relationship Id=\"rId1\" Type=\"$relType/slideLayout\" Target=\"../slideLayouts/slideLayout1.xml\"/></Relationships>")
            put("ppt/slideLayouts/slideLayout1.xml",
                "<p:sldLayout $p $a><p:cSld><p:spTree><p:sp><p:nvSpPr><p:cNvPr id=\"2\" name=\"Title\"/><p:cNvSpPr/><p:nvPr><p:ph type=\"title\"/></p:nvPr></p:nvSpPr>" +
                    "<p:spPr><a:xfrm><a:off x=\"457200\" y=\"274638\"/><a:ext cx=\"8229600\" cy=\"1143000\"/></a:xfrm></p:spPr></p:sp></p:spTree></p:cSld></p:sldLayout>")
            put("ppt/slideLayouts/_rels/slideLayout1.xml.rels", "<Relationships $relNs><Relationship Id=\"rId1\" Type=\"$relType/slideMaster\" Target=\"../slideMasters/slideMaster1.xml\"/></Relationships>")
            put("ppt/slideMasters/slideMaster1.xml",
                "<p:sldMaster $p $a><p:cSld><p:spTree/></p:cSld><p:clrMap bg1=\"lt1\" tx1=\"dk1\" bg2=\"lt2\" tx2=\"dk2\"/>" +
                    "<p:txStyles><p:titleStyle><a:lvl1pPr><a:defRPr sz=\"4400\"/></a:lvl1pPr></p:titleStyle><p:bodyStyle><a:lvl1pPr><a:defRPr sz=\"2800\"/></a:lvl1pPr></p:bodyStyle></p:txStyles></p:sldMaster>")
        }
        return file
    }

    private val title = "<p:sp><p:nvSpPr><p:cNvPr id=\"2\" name=\"T\"/><p:cNvSpPr/><p:nvPr><p:ph type=\"title\"/></p:nvPr></p:nvSpPr><p:spPr/>" +
        "<p:txBody><a:bodyPr/><a:p><a:r><a:rPr lang=\"en-US\"/><a:t>Hello</a:t></a:r></a:p></p:txBody></p:sp>"

    @Test fun readsSlideSizeAndCount() {
        PptxPackage.open(pptx(title)).use { pkg ->
            assertEquals(1, pkg.slideCount)
            assertEquals(9144000f, pkg.size.width, 0f)
            assertEquals(5143500f, pkg.size.height, 0f)
        }
    }

    @Test fun placeholdersInheritPositionAndSizeFromTheLayout() {
        PptxPackage.open(pptx(title)).use { pkg ->
            val slide = pkg.slide(0)
            val box = slide.shapes.filterIsInstance<BoxShape>().single()
            assertEquals(457200f, box.rect.x, 0f)
            assertEquals(8229600f, box.rect.w, 0f)
            assertEquals(44f, box.text!!.paragraphs.single().runs.single().sizePt, 0f)
            assertEquals("Hello", slide.text)
            assertFalse(slide.partial)
        }
    }

    @Test fun parsesFillsRightToLeftTextAndExplicitSizes() {
        val shapes = title +
            "<p:sp><p:nvSpPr><p:cNvPr id=\"3\" name=\"R\"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x=\"100\" y=\"200\"/><a:ext cx=\"300\" cy=\"400\"/></a:xfrm>" +
            "<a:prstGeom prst=\"rect\"/><a:solidFill><a:srgbClr val=\"FF0000\"/></a:solidFill></p:spPr>" +
            "<p:txBody><a:bodyPr/><a:p><a:pPr rtl=\"1\"/><a:r><a:rPr sz=\"2000\" b=\"1\"/><a:t>مرحبا</a:t></a:r></a:p></p:txBody></p:sp>"
        PptxPackage.open(pptx(shapes)).use { pkg ->
            val boxes = pkg.slide(0).shapes.filterIsInstance<BoxShape>()
            val rect = boxes.last()
            assertEquals(0xFFFF0000.toInt(), rect.fill)
            val para = rect.text!!.paragraphs.single()
            assertTrue(para.rtl)
            assertEquals(PptAlign.RIGHT, para.align)
            assertEquals(20f, para.runs.single().sizePt, 0f)
            assertTrue(para.runs.single().bold)
            assertTrue(pkg.slide(0).text.contains("مرحبا"))
        }
    }

    @Test fun flagsChartsAsUnsupportedWithoutFailing() {
        val chart = "<p:graphicFrame><p:nvGraphicFramePr><p:cNvPr id=\"4\" name=\"C\"/></p:nvGraphicFramePr><p:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"1000\" cy=\"1000\"/></p:xfrm>" +
            "<a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/chart\"/></a:graphic></p:graphicFrame>"
        PptxPackage.open(pptx(chart)).use { pkg ->
            val slide = pkg.slide(0)
            assertTrue(slide.partial)
            assertEquals(UnsupportedKind.CHART, slide.shapes.filterIsInstance<UnsupportedShape>().single().kind)
        }
    }

    @Test fun rejectsPresentationsWithoutSlides() {
        try { PptxPackage.open(pptx(title, withSlides = false)); fail("expected IOException") } catch (e: IOException) { /* expected */ }
    }

    @Test fun luminanceAdjustmentLightensAndDarkens() {
        val white = Hsl.adjust(0x4472C4, 0f, 1f)
        assertEquals(0xFFFFFF, white)
        assertEquals(0x000000, Hsl.adjust(0x4472C4, 0f, 0f))
        val same = Hsl.adjust(0x4472C4, 1f, 0f)
        for (shift in intArrayOf(16, 8, 0)) {
            val delta = ((same shr shift) and 0xFF) - ((0x4472C4 shr shift) and 0xFF)
            assertTrue("channel drift $delta", kotlin.math.abs(delta) <= 1)
        }
    }
}
