package com.pwp.reader.core.storage

data class FileInfo(val name: String, val sizeBytes: Long?, val mimeType: String?)

/** Android-free view of the Storage Access Framework, so repositories stay unit-testable. */
interface DocumentSource {
    fun query(uri: String): FileInfo?
    fun persistAccess(uri: String)
    fun releaseAccess(uri: String)
}
