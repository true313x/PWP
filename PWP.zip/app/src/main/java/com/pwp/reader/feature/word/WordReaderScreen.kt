@file:OptIn(ExperimentalMaterial3Api::class, FlowPreview::class)

package com.pwp.reader.feature.word

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pwp.reader.R
import com.pwp.reader.core.common.TextNormalizer
import com.pwp.reader.core.common.decodeSampled
import com.pwp.reader.core.common.openExternalLink
import com.pwp.reader.core.common.rememberReducedMotion
import com.pwp.reader.core.common.shareDocument
import com.pwp.reader.core.designsystem.LoadingState
import com.pwp.reader.core.designsystem.PwpIcons
import com.pwp.reader.core.designsystem.isDarkSurface
import com.pwp.reader.domain.model.DocumentFormat
import com.pwp.reader.domain.model.PwpDocument
import com.pwp.reader.domain.model.ReadingTheme
import com.pwp.reader.feature.viewer.DocumentInfoDialog
import com.pwp.reader.feature.viewer.KeepScreenOnEffect
import com.pwp.reader.feature.viewer.ViewerErrorScreen
import com.pwp.reader.feature.viewer.ViewerTopBar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

private val SoftHighlight = Color(0x66FFD54F)
private val StrongHighlight = Color(0xCCFF9800)

@Immutable
private data class RenderContext(
    val baseSp: Float,
    val lineSpacing: Float,
    val textColor: Color,
    val linkColor: Color,
    val darkBackground: Boolean,
    val query: String,
    val currentBlock: Int,
    val currentOccurrence: Int,
    val onLink: (String) -> Unit,
)

@Composable
fun WordReaderScreen(onBack: () -> Unit, viewModel: WordViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val document by viewModel.document.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    when (val s = state) {
        WordUiState.Loading -> Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) { LoadingState() }
        is WordUiState.Failed -> ViewerErrorScreen(s.error, onBack) { scope.launch { viewModel.removeFromHistory(); onBack() } }
        is WordUiState.Ready -> WordReader(s, document, viewModel, onBack)
    }
}

@Composable
private fun readerPalette(theme: ReadingTheme): Triple<Color, Color, Boolean> {
    val dark = when (theme) {
        ReadingTheme.AUTO -> isDarkSurface()
        ReadingTheme.LIGHT -> false
        ReadingTheme.DARK -> true
    }
    return if (dark) Triple(Color(0xFF121214), Color(0xFFE6E6EA), true) else Triple(Color(0xFFFBFAF8), Color(0xFF1C1C1E), false)
}

@Composable
private fun WordReader(ready: WordUiState.Ready, document: PwpDocument?, viewModel: WordViewModel, onBack: () -> Unit) {
    val doc = ready.document
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val reduceMotion = rememberReducedMotion()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val bookmarks by viewModel.bookmarks.collectAsStateWithLifecycle()
    val (background, foreground, darkBackground) = readerPalette(settings.wordTheme)

    var chromeVisible by rememberSaveable { mutableStateOf(true) }
    var finding by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var matchIndex by rememberSaveable { mutableIntStateOf(0) }
    var noticeDismissed by rememberSaveable { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    var showBookmarks by remember { mutableStateOf(false) }

    val listState = rememberLazyListState(ready.startIndex, ready.startOffset)

    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex to listState.firstVisibleItemScrollOffset }
            .debounce(600)
            .collect { (i, o) -> viewModel.savePosition(i, o) }
    }
    DisposableEffect(listState) {
        onDispose { viewModel.savePosition(listState.firstVisibleItemIndex, listState.firstVisibleItemScrollOffset) }
    }
    KeepScreenOnEffect(settings.keepScreenOn)

    // (block, occurrence-in-block) for every match; recomputed off the main thread after a short debounce.
    val matches by produceState(emptyList<Pair<Int, Int>>(), query, doc) {
        value = if (query.isBlank()) emptyList() else {
            delay(250)
            withContext(Dispatchers.Default) {
                buildList {
                    doc.blocks.forEachIndexed { bi, block ->
                        ensureActive()
                        val n = TextNormalizer.findMatches(block.searchableText(), query).size
                        for (k in 0 until n) add(bi to k)
                    }
                }
            }
        }
    }
    LaunchedEffect(query) { matchIndex = 0 }
    LaunchedEffect(matchIndex, matches) {
        matches.getOrNull(matchIndex)?.let { (block, _) ->
            if (reduceMotion) listState.scrollToItem(block) else listState.animateScrollToItem(block)
        }
    }

    val firstVisible by remember { derivedStateOf { listState.firstVisibleItemIndex } }
    val current = matches.getOrNull(matchIndex)
    val ctx = remember(settings.wordFontSizeSp, settings.wordLineSpacing, foreground, darkBackground, query, current) {
        RenderContext(
            baseSp = settings.wordFontSizeSp,
            lineSpacing = settings.wordLineSpacing,
            textColor = foreground,
            linkColor = if (darkBackground) Color(0xFF8AB4FF) else Color(0xFF1A5FD0),
            darkBackground = darkBackground,
            query = query,
            currentBlock = current?.first ?: -1,
            currentOccurrence = current?.second ?: -1,
            onLink = { url -> context.openExternalLink(url) },
        )
    }

    val statusTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val enter = if (reduceMotion) EnterTransition.None else fadeIn()
    val exit = if (reduceMotion) ExitTransition.None else fadeOut()

    Box(Modifier.fillMaxSize().background(background), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .widthIn(max = 860.dp)
                .fillMaxHeight()
                .pointerInput(Unit) { detectTapGestures(onTap = { chromeVisible = !chromeVisible }) },
            contentPadding = PaddingValues(
                start = settings.wordMarginDp.dp,
                end = settings.wordMarginDp.dp,
                top = statusTop + if (finding) 120.dp else 72.dp,
                bottom = navBottom + 48.dp,
            ),
        ) {
            if (doc.blocks.isEmpty()) {
                item {
                    Text(stringResource(R.string.word_empty), color = foreground.copy(alpha = 0.7f), modifier = Modifier.padding(vertical = 24.dp))
                }
            }
            items(count = doc.blocks.size) { i -> BlockView(doc.blocks[i], i, ctx, ctx.textColor) }
        }

        AnimatedVisibility(chromeVisible, Modifier.align(Alignment.TopCenter), enter = enter, exit = exit) {
            val bookmarked = bookmarks.any { it.position == firstVisible }
            Column {
                ViewerTopBar(title = document?.name.orEmpty(), onBack = onBack) {
                    IconButton(onClick = { finding = !finding }) {
                        Icon(PwpIcons.Search, contentDescription = stringResource(R.string.find_in_document))
                    }
                    IconButton(onClick = { showSettings = true }) {
                        Icon(PwpIcons.Tune, contentDescription = stringResource(R.string.word_reading_settings))
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(PwpIcons.More, contentDescription = stringResource(R.string.more_options))
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text(stringResource(if (bookmarked) R.string.bookmark_remove else R.string.bookmark_add)) },
                                leadingIcon = { Icon(if (bookmarked) PwpIcons.Bookmark else PwpIcons.BookmarkOutline, contentDescription = null) },
                                onClick = {
                                    menuOpen = false
                                    viewModel.toggleBookmark(firstVisible, doc.blocks.getOrNull(firstVisible)?.searchableText())
                                },
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.bookmarks)) },
                                leadingIcon = { Icon(PwpIcons.Bookmark, contentDescription = null) },
                                onClick = { menuOpen = false; showBookmarks = true },
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.share)) },
                                leadingIcon = { Icon(PwpIcons.Share, contentDescription = null) },
                                onClick = {
                                    menuOpen = false
                                    context.shareDocument(viewModel.uri, DocumentFormat.DOCX.mimeType, document?.name ?: "DOCX")
                                },
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.document_info)) },
                                leadingIcon = { Icon(PwpIcons.Info, contentDescription = null) },
                                onClick = { menuOpen = false; showInfo = true },
                            )
                        }
                    }
                }
                if (finding) {
                    FindBar(
                        query = query,
                        onQueryChange = { query = it },
                        matchCount = matches.size,
                        index = matchIndex,
                        onPrevious = { if (matches.isNotEmpty()) matchIndex = (matchIndex - 1 + matches.size) % matches.size },
                        onNext = { if (matches.isNotEmpty()) matchIndex = (matchIndex + 1) % matches.size },
                        onClose = { finding = false; query = "" },
                    )
                }
            }
        }

        if (doc.partial && !noticeDismissed) {
            Surface(
                onClick = { noticeDismissed = true },
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                shadowElevation = 4.dp,
            ) {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(PwpIcons.Info, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.padding(4.dp))
                    Text(stringResource(R.string.word_partial), style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f, fill = false))
                }
            }
        }
    }

    if (showInfo) DocumentInfoDialog(document, "", onDismiss = { showInfo = false })

    if (showSettings) {
        ModalBottomSheet(onDismissRequest = { showSettings = false }, sheetState = rememberModalBottomSheetState()) {
            Column(Modifier.padding(horizontal = 24.dp).padding(bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(stringResource(R.string.word_reading_settings), style = MaterialTheme.typography.titleMedium)
                LabeledSlider(
                    label = stringResource(R.string.word_text_size),
                    valueLabel = "${settings.wordFontSizeSp.roundToInt()} sp",
                    value = settings.wordFontSizeSp,
                    range = 12f..30f,
                    steps = 17,
                ) { v -> viewModel.updateSettings { it.copy(wordFontSizeSp = v.roundToInt().toFloat()) } }
                LabeledSlider(
                    label = stringResource(R.string.word_line_spacing),
                    valueLabel = "%.1f".format(settings.wordLineSpacing),
                    value = settings.wordLineSpacing,
                    range = 1.0f..2.2f,
                    steps = 11,
                ) { v -> viewModel.updateSettings { it.copy(wordLineSpacing = (v * 10).roundToInt() / 10f) } }
                LabeledSlider(
                    label = stringResource(R.string.word_margins),
                    valueLabel = "${settings.wordMarginDp} dp",
                    value = settings.wordMarginDp.toFloat(),
                    range = 8f..48f,
                    steps = 9,
                ) { v -> viewModel.updateSettings { it.copy(wordMarginDp = ((v / 4).roundToInt() * 4)) } }
                Text(stringResource(R.string.word_theme), style = MaterialTheme.typography.bodyLarge)
                val themes = listOf(
                    ReadingTheme.AUTO to R.string.reading_auto,
                    ReadingTheme.LIGHT to R.string.reading_light,
                    ReadingTheme.DARK to R.string.reading_dark,
                )
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    themes.forEachIndexed { index, (theme, label) ->
                        SegmentedButton(
                            selected = settings.wordTheme == theme,
                            onClick = { viewModel.updateSettings { it.copy(wordTheme = theme) } },
                            shape = SegmentedButtonDefaults.itemShape(index, themes.size),
                        ) { Text(stringResource(label)) }
                    }
                }
            }
        }
    }

    if (showBookmarks) {
        ModalBottomSheet(onDismissRequest = { showBookmarks = false }, sheetState = rememberModalBottomSheetState()) {
            Column(Modifier.padding(bottom = 24.dp)) {
                Text(stringResource(R.string.bookmarks), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
                if (bookmarks.isEmpty()) {
                    Text(
                        stringResource(R.string.bookmarks_empty),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                    )
                }
                bookmarks.forEach { b ->
                    Row(Modifier.fillMaxWidth().padding(start = 24.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(
                            onClick = { showBookmarks = false; scope.launch { listState.scrollToItem(b.position) } },
                            modifier = Modifier.weight(1f),
                        ) {
                            Text(b.label ?: stringResource(R.string.bookmark_position, b.position + 1), maxLines = 2, modifier = Modifier.fillMaxWidth())
                        }
                        IconButton(onClick = { viewModel.removeBookmark(b.id) }) {
                            Icon(PwpIcons.Delete, contentDescription = stringResource(R.string.bookmark_remove))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LabeledSlider(label: String, valueLabel: String, value: Float, range: ClosedFloatingPointRange<Float>, steps: Int, onChange: (Float) -> Unit) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
            Text(valueLabel, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range, steps = steps)
    }
}

@Composable
private fun FindBar(
    query: String,
    onQueryChange: (String) -> Unit,
    matchCount: Int,
    index: Int,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onClose: () -> Unit,
) {
    Surface(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.97f), shadowElevation = 1.dp) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TextField(
                value = query,
                onValueChange = onQueryChange,
                singleLine = true,
                placeholder = { Text(stringResource(R.string.find_hint)) },
                modifier = Modifier.weight(1f),
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                ),
            )
            if (query.isNotBlank()) {
                Text(
                    if (matchCount == 0) stringResource(R.string.find_no_matches)
                    else stringResource(R.string.find_match_of, index + 1, matchCount),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            IconButton(onClick = onPrevious, enabled = matchCount > 0) {
                Icon(PwpIcons.ArrowUp, contentDescription = stringResource(R.string.find_previous))
            }
            IconButton(onClick = onNext, enabled = matchCount > 0) {
                Icon(PwpIcons.ArrowDown, contentDescription = stringResource(R.string.find_next))
            }
            IconButton(onClick = onClose) { Icon(PwpIcons.Close, contentDescription = stringResource(R.string.action_close)) }
        }
    }
}

@Composable
private fun BlockView(block: DocBlock, index: Int, ctx: RenderContext, textColor: Color) {
    when (block) {
        is DocParagraph -> ParagraphView(block, ctx, textColor, if (index == ctx.currentBlock) ctx.currentOccurrence else -1)
        is DocTable -> TableView(block, ctx)
        is DocBreak -> {
            Spacer(Modifier.height(10.dp))
            HorizontalDivider(color = ctx.textColor.copy(alpha = if (block.page) 0.25f else 0.12f))
            Spacer(Modifier.height(10.dp))
        }
    }
}

private fun headingRatio(level: Int): Float = when (level) {
    1 -> 1.7f
    2 -> 1.45f
    3 -> 1.25f
    4 -> 1.1f
    else -> 1f
}

private fun adjustColor(c: Color, textColor: Color, darkBackground: Boolean): Color = when {
    darkBackground && c.luminance() < 0.25f -> textColor
    !darkBackground && c.luminance() > 0.85f -> textColor
    else -> c
}

private fun buildText(p: DocParagraph, runs: List<DocRun>, ctx: RenderContext, textColor: Color, currentOccurrence: Int): AnnotatedString {
    val plain = StringBuilder()
    val text = buildAnnotatedString {
        for (r in runs) {
            val chunk = r.text.replace("\t", "    ")
            plain.append(chunk)
            val decorations = listOfNotNull(
                if (r.underline) TextDecoration.Underline else null,
                if (r.strike) TextDecoration.LineThrough else null,
            )
            val ratio = r.sizeRatio ?: headingRatio(p.headingLevel)
            val style = SpanStyle(
                fontWeight = if (r.bold || p.headingLevel > 0) FontWeight.Bold else null,
                fontStyle = if (r.italic) FontStyle.Italic else null,
                textDecoration = if (decorations.isEmpty()) null else TextDecoration.combine(decorations),
                color = r.color?.let { adjustColor(Color(it), textColor, ctx.darkBackground) } ?: Color.Unspecified,
                fontSize = (ctx.baseSp * ratio).sp,
            )
            val url = r.link
            if (url != null) {
                withLink(
                    LinkAnnotation.Clickable(
                        tag = url,
                        styles = TextLinkStyles(SpanStyle(color = ctx.linkColor, textDecoration = TextDecoration.Underline)),
                        linkInteractionListener = { ctx.onLink(url) },
                    ),
                ) { withStyle(style) { append(chunk) } }
            } else {
                withStyle(style) { append(chunk) }
            }
        }
        if (ctx.query.isNotBlank()) {
            TextNormalizer.findMatches(plain.toString(), ctx.query).forEachIndexed { i, range ->
                addStyle(
                    SpanStyle(background = if (i == currentOccurrence) StrongHighlight else SoftHighlight),
                    range.first, range.last + 1,
                )
            }
        }
    }
    return text
}

@Composable
private fun ParagraphView(p: DocParagraph, ctx: RenderContext, textColor: Color, currentOccurrence: Int) {
    val density = LocalDensity.current
    val gap = with(density) { (ctx.baseSp * if (p.headingLevel > 0) 0.5f else 0.6f).sp.toDp() }
    val top = if (p.headingLevel > 0) with(density) { (ctx.baseSp * 0.7f).sp.toDp() } else 0.dp
    val direction = if (p.rtl) LayoutDirection.Rtl else LocalLayoutDirection.current
    val firstText = p.segments.indexOfFirst { it is DocSegment.Text }

    CompositionLocalProvider(LocalLayoutDirection provides direction) {
        Column(Modifier.fillMaxWidth().padding(top = top, bottom = gap)) {
            if (p.segments.isEmpty()) {
                Spacer(Modifier.height(with(density) { (ctx.baseSp * 0.7f).sp.toDp() }))
            }
            p.segments.forEachIndexed { i, seg ->
                when (seg) {
                    is DocSegment.Text -> TextSegment(p, seg.runs, ctx, textColor, currentOccurrence, if (i == firstText) p.listLabel else null)
                    is DocSegment.Image -> DocImageView(seg.image)
                }
            }
        }
    }
}

@Composable
private fun TextSegment(p: DocParagraph, runs: List<DocRun>, ctx: RenderContext, textColor: Color, currentOccurrence: Int, label: String?) {
    val text = remember(runs, ctx, textColor, currentOccurrence) { buildText(p, runs, ctx, textColor, currentOccurrence) }
    val maxRatio = remember(runs, p.headingLevel) { runs.maxOf { it.sizeRatio ?: headingRatio(p.headingLevel) } }
    val style = TextStyle(
        fontSize = ctx.baseSp.sp,
        lineHeight = (ctx.baseSp * maxRatio * ctx.lineSpacing).sp,
        color = textColor,
        textAlign = when (p.align) {
            ParaAlign.START -> TextAlign.Start
            ParaAlign.CENTER -> TextAlign.Center
            ParaAlign.END -> TextAlign.End
            ParaAlign.JUSTIFY -> TextAlign.Justify
        },
        textDirection = if (p.rtl) TextDirection.Rtl else TextDirection.Content,
    )
    if (label != null) {
        Row(Modifier.padding(start = (p.listLevel * 20).dp)) {
            Text(label, style = style, modifier = Modifier.widthIn(min = 28.dp).padding(end = 6.dp))
            Text(text, style = style, modifier = Modifier.weight(1f))
        }
    } else {
        Text(text, style = style, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun DocImageView(image: DocImage) {
    val bitmap: ImageBitmap? by produceState<ImageBitmap?>(null, image.path) {
        value = withContext(Dispatchers.IO) { decodeSampled(1600) { File(image.path).inputStream() }?.asImageBitmap() }
    }
    bitmap?.let { b ->
        Image(
            bitmap = b,
            contentDescription = image.alt,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .then(if (image.widthDp != null) Modifier.widthIn(max = image.widthDp.dp) else Modifier)
                .fillMaxWidth()
                .padding(vertical = 6.dp),
        )
    }
}

@Composable
private fun TableView(table: DocTable, ctx: RenderContext) {
    val border = ctx.textColor.copy(alpha = 0.22f)
    val direction = if (table.rtl) LayoutDirection.Rtl else LocalLayoutDirection.current
    CompositionLocalProvider(LocalLayoutDirection provides direction) {
        Column(Modifier.fillMaxWidth().padding(vertical = 8.dp).border(BorderStroke(1.dp, border))) {
            table.rows.forEach { row ->
                Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                    row.cells.forEach { cell ->
                        val fill = cell.fill?.let { Color(it) }
                        val cellDark = fill?.let { it.luminance() < 0.5f } ?: ctx.darkBackground
                        val cellText = if (fill != null) (if (cellDark) Color.White else Color(0xFF1C1C1E)) else ctx.textColor
                        val cellCtx = ctx.copy(textColor = cellText, darkBackground = cellDark, currentBlock = -1)
                        Box(
                            Modifier
                                .weight(cell.span.toFloat())
                                .fillMaxHeight()
                                .border(BorderStroke(0.5.dp, border))
                                .then(
                                    if (fill != null) Modifier.background(fill)
                                    else if (row.header) Modifier.background(ctx.textColor.copy(alpha = 0.08f))
                                    else Modifier,
                                )
                                .padding(6.dp),
                        ) {
                            Column {
                                cell.blocks.forEach { b -> BlockView(b, -1, cellCtx, cellText) }
                            }
                        }
                    }
                }
            }
        }
    }
}
