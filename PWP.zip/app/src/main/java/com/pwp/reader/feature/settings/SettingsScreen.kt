package com.pwp.reader.feature.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pwp.reader.BuildConfig
import com.pwp.reader.R
import com.pwp.reader.core.common.formatFileSize
import com.pwp.reader.core.designsystem.LocalSnackbarHostState
import com.pwp.reader.core.designsystem.PwpIcons
import com.pwp.reader.core.designsystem.PwpScreen
import com.pwp.reader.core.designsystem.ScreenTitle
import com.pwp.reader.core.designsystem.isDarkSurface
import com.pwp.reader.core.designsystem.swatch
import com.pwp.reader.core.localization.AppLanguage
import com.pwp.reader.domain.model.AccentColor
import com.pwp.reader.domain.model.PdfZoomMode
import com.pwp.reader.domain.model.ThemeMode
import com.pwp.reader.domain.model.ViewMode
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private sealed interface Dialog {
    data object Theme : Dialog
    data object ViewMode : Dialog
    data object Language : Dialog
    data object PdfZoom : Dialog
    data object ClearHistory : Dialog
    data object Privacy : Dialog
    data object Licenses : Dialog
}

@Composable
fun SettingsScreen(viewModel: SettingsViewModel = hiltViewModel()) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val cacheBytes by viewModel.cacheBytes.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbar = LocalSnackbarHostState.current
    val scope = rememberCoroutineScope()
    var dialog by remember { mutableStateOf<Dialog?>(null) }
    var language by remember { mutableStateOf(AppLanguage.current()) }

    val themeLabels = mapOf(
        ThemeMode.SYSTEM to stringResource(R.string.theme_system),
        ThemeMode.LIGHT to stringResource(R.string.theme_light),
        ThemeMode.DARK to stringResource(R.string.theme_dark),
    )
    val viewLabels = mapOf(ViewMode.LIST to stringResource(R.string.view_list), ViewMode.GRID to stringResource(R.string.view_grid))
    val zoomLabels = mapOf(PdfZoomMode.FIT_WIDTH to stringResource(R.string.fit_width), PdfZoomMode.FIT_PAGE to stringResource(R.string.fit_page))
    val systemLanguage = stringResource(R.string.language_system)
    fun languageName(l: AppLanguage) = l.nativeName ?: systemLanguage

    PwpScreen {
        ScreenTitle(stringResource(R.string.settings_title))
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {

            SettingsGroup(stringResource(R.string.settings_appearance)) {
                ValueRow(PwpIcons.Palette, stringResource(R.string.settings_theme), themeLabels.getValue(settings.themeMode)) { dialog = Dialog.Theme }
                AccentRow(settings.accent) { accent -> viewModel.update { it.copy(accent = accent) } }
                ValueRow(PwpIcons.Grid, stringResource(R.string.settings_default_view), viewLabels.getValue(settings.defaultViewMode)) { dialog = Dialog.ViewMode }
            }

            SettingsGroup(stringResource(R.string.settings_language)) {
                ValueRow(PwpIcons.Language, stringResource(R.string.settings_language), languageName(language)) { dialog = Dialog.Language }
            }

            SettingsGroup(stringResource(R.string.settings_reading)) {
                ValueRow(PwpIcons.FitPage, stringResource(R.string.settings_pdf_zoom), zoomLabels.getValue(settings.pdfZoomMode)) { dialog = Dialog.PdfZoom }
                SwitchRow(
                    stringResource(R.string.settings_remember_position), stringResource(R.string.settings_remember_position_desc),
                    settings.rememberPosition,
                ) { v -> viewModel.update { it.copy(rememberPosition = v) } }
                SwitchRow(stringResource(R.string.settings_show_page_controls), null, settings.showPageControls) { v ->
                    viewModel.update { it.copy(showPageControls = v) }
                }
                SliderRow(
                    title = stringResource(R.string.settings_word_font_size),
                    valueLabel = "${settings.wordFontSizeSp.roundToInt()} sp",
                    value = settings.wordFontSizeSp,
                    range = 12f..30f,
                ) { v -> viewModel.update { it.copy(wordFontSizeSp = v.roundToInt().toFloat()) } }
                SwitchRow(stringResource(R.string.settings_show_thumbnails), null, settings.showSlideThumbnails) { v ->
                    viewModel.update { it.copy(showSlideThumbnails = v) }
                }
                SwitchRow(stringResource(R.string.settings_keep_screen_on), null, settings.keepScreenOn) { v ->
                    viewModel.update { it.copy(keepScreenOn = v) }
                }
            }

            SettingsGroup(stringResource(R.string.settings_storage_privacy)) {
                ValueRow(PwpIcons.Delete, stringResource(R.string.settings_clear_history), stringResource(R.string.settings_clear_history_desc)) { dialog = Dialog.ClearHistory }
                val clearedMessage = stringResource(R.string.cache_cleared)
                ValueRow(
                    PwpIcons.Storage,
                    stringResource(R.string.settings_clear_cache),
                    cacheBytes?.let { stringResource(R.string.settings_cache_usage, formatFileSize(context, it)) },
                ) { scope.launch { viewModel.clearCache(); snackbar.showSnackbar(clearedMessage) } }
                ValueRow(PwpIcons.Lock, stringResource(R.string.settings_privacy), null) { dialog = Dialog.Privacy }
            }

            SettingsGroup(stringResource(R.string.settings_about)) {
                ValueRow(PwpIcons.Info, stringResource(R.string.about_version), BuildConfig.VERSION_NAME, onClick = null)
                ValueRow(PwpIcons.Word, stringResource(R.string.about_licenses), null) { dialog = Dialog.Licenses }
            }
            Spacer(Modifier.size(24.dp))
        }
    }

    when (dialog) {
        Dialog.Theme -> ChoiceDialog(
            stringResource(R.string.settings_theme), themeLabels.toList(), settings.themeMode,
            onSelect = { m -> viewModel.update { it.copy(themeMode = m) }; dialog = null }, onDismiss = { dialog = null },
        )
        Dialog.ViewMode -> ChoiceDialog(
            stringResource(R.string.settings_default_view), viewLabels.toList(), settings.defaultViewMode,
            onSelect = { m -> viewModel.update { it.copy(defaultViewMode = m) }; dialog = null }, onDismiss = { dialog = null },
        )
        Dialog.PdfZoom -> ChoiceDialog(
            stringResource(R.string.settings_pdf_zoom), zoomLabels.toList(), settings.pdfZoomMode,
            onSelect = { m -> viewModel.update { it.copy(pdfZoomMode = m) }; dialog = null }, onDismiss = { dialog = null },
        )
        Dialog.Language -> ChoiceDialog(
            stringResource(R.string.settings_language), AppLanguage.entries.map { it to languageName(it) }, language,
            onSelect = { l -> dialog = null; language = l; AppLanguage.apply(l) }, onDismiss = { dialog = null },
        )
        Dialog.ClearHistory -> {
            val clearedMessage = stringResource(R.string.history_cleared)
            AlertDialog(
                onDismissRequest = { dialog = null },
                title = { Text(stringResource(R.string.clear_history_confirm_title)) },
                text = { Text(stringResource(R.string.clear_history_confirm_body)) },
                confirmButton = {
                    TextButton(onClick = {
                        dialog = null
                        scope.launch { viewModel.clearHistory(); snackbar.showSnackbar(clearedMessage) }
                    }) { Text(stringResource(R.string.action_clear_confirm), color = MaterialTheme.colorScheme.error) }
                },
                dismissButton = { TextButton(onClick = { dialog = null }) { Text(stringResource(R.string.action_cancel)) } },
            )
        }
        Dialog.Privacy -> InfoDialog(stringResource(R.string.settings_privacy), stringResource(R.string.privacy_body)) { dialog = null }
        Dialog.Licenses -> InfoDialog(stringResource(R.string.about_licenses), stringResource(R.string.licenses_body)) { dialog = null }
        null -> Unit
    }
}

@Composable
private fun SettingsGroup(title: String, content: @Composable () -> Unit) {
    Column {
        Text(
            title,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(start = 4.dp, bottom = 8.dp),
        )
        Surface(
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        ) { Column(content = { content() }) }
    }
}

@Composable
private fun ValueRow(icon: ImageVector, title: String, value: String?, onClick: (() -> Unit)?) {
    val base = Modifier.fillMaxWidth().heightIn(min = 56.dp)
    Row(
        (if (onClick != null) base.clickable(role = Role.Button, onClick = onClick) else base).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (value != null) Text(value, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 56.dp)
            .toggleable(value = checked, role = Role.Switch, onValueChange = onChange)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = null)
    }
}

@Composable
private fun SliderRow(title: String, valueLabel: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
            Text(valueLabel, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range, steps = (range.endInclusive - range.start).toInt() - 1)
    }
}

@Composable
private fun AccentRow(selected: AccentColor, onSelect: (AccentColor) -> Unit) {
    val dark = isDarkSurface()
    val names = mapOf(
        AccentColor.INDIGO to stringResource(R.string.accent_indigo),
        AccentColor.BLUE to stringResource(R.string.accent_blue),
        AccentColor.TEAL to stringResource(R.string.accent_teal),
        AccentColor.ROSE to stringResource(R.string.accent_rose),
        AccentColor.ORANGE to stringResource(R.string.accent_orange),
    )
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text(stringResource(R.string.settings_accent), style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.size(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            AccentColor.entries.forEach { accent ->
                val isSelected = accent == selected
                val color = accent.swatch(dark)
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(color)
                        .then(if (isSelected) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape) else Modifier)
                        .selectable(selected = isSelected, role = Role.RadioButton, onClick = { onSelect(accent) })
                        .semantics { contentDescription = names.getValue(accent) },
                    contentAlignment = Alignment.Center,
                ) {
                    if (isSelected) Icon(PwpIcons.Check, contentDescription = null, tint = androidx.compose.ui.graphics.Color.White)
                }
            }
        }
    }
}

@Composable
private fun <T> ChoiceDialog(title: String, options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                options.forEach { (value, label) ->
                    Row(
                        Modifier.fillMaxWidth().heightIn(min = 48.dp)
                            .selectable(selected = value == selected, role = Role.RadioButton, onClick = { onSelect(value) }),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = value == selected, onClick = null)
                        Spacer(Modifier.width(12.dp))
                        Text(label, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) } },
    )
}

@Composable
private fun InfoDialog(title: String, body: String, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(body, modifier = Modifier.verticalScroll(rememberScrollState()), style = MaterialTheme.typography.bodyMedium) },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_ok)) } },
    )
}
