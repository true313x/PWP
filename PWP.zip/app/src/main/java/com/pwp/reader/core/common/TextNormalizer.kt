package com.pwp.reader.core.common

/**
 * Script-aware text normalisation used for filename and content search.
 * Folds case, Arabic/Persian letter variants, diacritics, tatweel and Arabic-Indic digits so that
 * "مُحَمَّد", "محمد" and "ﻣﺤﻤﺪ" compare equal and "١٢٣" matches "123".
 */
object TextNormalizer {
    class Indexed(val text: String, val origin: IntArray)

    private fun isIgnorable(c: Char): Boolean =
        c in '\u0610'..'\u061A' || c in '\u064B'..'\u065F' || c == '\u0670' ||
            c in '\u06D6'..'\u06ED' || c == '\u0640' || c == '\u200C' || c == '\u200D' ||
            c == '\u200E' || c == '\u200F'

    private fun mapChar(c: Char): Char = when (c) {
        'أ', 'إ', 'آ', 'ٱ' -> 'ا'
        'ى', 'ی', 'ې' -> 'ي'
        'ک', 'ڪ' -> 'ك'
        'ة', 'ۀ', 'ە' -> 'ه'
        in '\u0660'..'\u0669' -> '0' + (c - '\u0660')
        in '\u06F0'..'\u06F9' -> '0' + (c - '\u06F0')
        else -> c.lowercaseChar()
    }

    /** Normalised text plus, for each normalised char, the index of the original char it came from. */
    fun indexed(input: String): Indexed {
        val sb = StringBuilder(input.length)
        val map = IntArray(input.length)
        var n = 0
        for (i in input.indices) {
            val c = input[i]
            if (isIgnorable(c)) continue
            sb.append(mapChar(c))
            map[n++] = i
        }
        return Indexed(sb.toString(), map.copyOf(n))
    }

    fun normalize(input: String): String = indexed(input).text

    /** Non-overlapping match ranges of [query] inside [text], expressed in indices of the original [text]. */
    fun findMatches(text: String, query: String): List<IntRange> {
        val q = normalize(query).trim()
        if (q.isEmpty() || text.isEmpty()) return emptyList()
        val idx = indexed(text)
        val result = ArrayList<IntRange>()
        var from = 0
        while (true) {
            val at = idx.text.indexOf(q, from)
            if (at < 0) break
            val start = idx.origin[at]
            val end = idx.origin[at + q.length - 1] + 1
            result += start until end
            from = at + q.length
        }
        return result
    }
}
