package com.pwp.reader.core.storage

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import com.pwp.reader.core.common.DocumentTooLargeException
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileNotFoundException
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DocumentAccess @Inject constructor(
    @ApplicationContext private val context: Context,
) : DocumentSource {

    override fun query(uri: String): FileInfo? {
        val parsed = Uri.parse(uri)
        val resolver = context.contentResolver
        val mime = runCatching { resolver.getType(parsed) }.getOrNull()
        return runCatching {
            resolver.query(
                parsed, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null,
            )?.use { c ->
                if (!c.moveToFirst()) return@use null
                val nameIdx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIdx = c.getColumnIndex(OpenableColumns.SIZE)
                val name = if (nameIdx >= 0 && !c.isNull(nameIdx)) c.getString(nameIdx) else null
                val size = if (sizeIdx >= 0 && !c.isNull(sizeIdx)) c.getLong(sizeIdx) else null
                FileInfo(name ?: parsed.lastPathSegment ?: "document", size, mime)
            }
        }.getOrNull()
    }

    override fun persistAccess(uri: String) {
        runCatching {
            context.contentResolver.takePersistableUriPermission(Uri.parse(uri), Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    override fun releaseAccess(uri: String) {
        runCatching {
            context.contentResolver.releasePersistableUriPermission(Uri.parse(uri), Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    fun isAccessible(uri: Uri): Boolean = runCatching {
        context.contentResolver.openFileDescriptor(uri, "r")?.use { true } ?: false
    }.getOrDefault(false)

    fun openFd(uri: Uri): ParcelFileDescriptor =
        context.contentResolver.openFileDescriptor(uri, "r") ?: throw FileNotFoundException("unavailable")

    /** Copies the document into the app cache (bounded by [maxBytes]); the caller deletes the file. */
    suspend fun copyToCache(uri: Uri, extension: String, maxBytes: Long): File = withContext(Dispatchers.IO) {
        val dir = File(context.cacheDir, "docs").apply { mkdirs() }
        val file = File.createTempFile("doc", ".$extension", dir)
        try {
            val input = context.contentResolver.openInputStream(uri) ?: throw FileNotFoundException("unavailable")
            input.use { ins ->
                file.outputStream().use { out ->
                    val buffer = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val n = ins.read(buffer)
                        if (n < 0) break
                        total += n
                        if (total > maxBytes) throw DocumentTooLargeException()
                        out.write(buffer, 0, n)
                        ensureActive()
                    }
                }
            }
            file
        } catch (t: Throwable) {
            file.delete()
            throw t
        }
    }

    fun cleanTempFiles() {
        File(context.cacheDir, "docs").deleteRecursively()
        File(context.cacheDir, "docx-img").deleteRecursively()
    }
}
