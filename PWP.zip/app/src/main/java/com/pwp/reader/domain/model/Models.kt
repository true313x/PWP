package com.pwp.reader.domain.model

enum class DocumentFormat(val extension: String, val mimeType: String) {
    PDF("pdf", "application/pdf"),
    DOCX("docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
    PPTX("pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation");

    companion object {
        /** Legacy .doc / .ppt are intentionally not detected: PWP cannot open them. */
        fun detect(name: String?, mimeType: String?): DocumentFormat? {
            val ext = name?.substringAfterLast('.', "")?.lowercase().orEmpty()
            return entries.firstOrNull { it.extension == ext } ?: entries.firstOrNull { it.mimeType == mimeType }
        }
    }
}

data class PwpDocument(
    val uri: String,
    val name: String,
    val format: DocumentFormat,
    val sizeBytes: Long?,
    /** Pages for PDF, slides for PPTX; null when unknown. */
    val pageCount: Int?,
    val lastOpenedAt: Long,
    val isFavorite: Boolean,
    val lastPosition: Int,
    val lastOffset: Int,
)

data class Bookmark(val id: Long, val documentUri: String, val position: Int, val label: String?, val createdAt: Long)

sealed interface OpenResult {
    data class Opened(val document: PwpDocument) : OpenResult
    data object Unsupported : OpenResult
    data object Unavailable : OpenResult
}

enum class SortField { NAME, DATE, SIZE, TYPE }
data class SortOrder(val field: SortField = SortField.DATE, val ascending: Boolean = false)

enum class ViewMode { LIST, GRID }
enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class AccentColor { INDIGO, BLUE, TEAL, ROSE, ORANGE }
enum class PdfZoomMode { FIT_WIDTH, FIT_PAGE }
enum class ReadingTheme { AUTO, LIGHT, DARK }

data class UserSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val accent: AccentColor = AccentColor.INDIGO,
    val defaultViewMode: ViewMode = ViewMode.LIST,
    val pdfZoomMode: PdfZoomMode = PdfZoomMode.FIT_WIDTH,
    val rememberPosition: Boolean = true,
    val showPageControls: Boolean = true,
    val keepScreenOn: Boolean = false,
    val wordFontSizeSp: Float = 17f,
    val wordLineSpacing: Float = 1.5f,
    val wordMarginDp: Int = 20,
    val wordTheme: ReadingTheme = ReadingTheme.AUTO,
    val showSlideThumbnails: Boolean = true,
)
