package com.pwp.reader.core.designsystem

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.FitScreen
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Slideshow
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.ViewAgenda
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material.icons.rounded.ZoomOut

/** Single place that maps semantic names to Material icons. */
object PwpIcons {
    val Back = Icons.AutoMirrored.Rounded.ArrowBack
    val Previous = Icons.AutoMirrored.Rounded.KeyboardArrowLeft
    val Next = Icons.AutoMirrored.Rounded.KeyboardArrowRight
    val Sort = Icons.AutoMirrored.Rounded.Sort
    val Add = Icons.Rounded.Add
    val Bookmark = Icons.Rounded.Bookmark
    val BookmarkOutline = Icons.Rounded.BookmarkBorder
    val Check = Icons.Rounded.Check
    val Close = Icons.Rounded.Close
    val Delete = Icons.Rounded.Delete
    val Word = Icons.Rounded.Description
    val Error = Icons.Rounded.ErrorOutline
    val FitPage = Icons.Rounded.FitScreen
    val Files = Icons.Rounded.Folder
    val OpenFolder = Icons.Rounded.FolderOpen
    val Fullscreen = Icons.Rounded.Fullscreen
    val FullscreenExit = Icons.Rounded.FullscreenExit
    val Grid = Icons.Rounded.GridView
    val Recent = Icons.Rounded.History
    val Home = Icons.Rounded.Home
    val Info = Icons.Rounded.Info
    val ArrowUp = Icons.Rounded.KeyboardArrowUp
    val ArrowDown = Icons.Rounded.KeyboardArrowDown
    val Language = Icons.Rounded.Language
    val Lock = Icons.Rounded.Lock
    val More = Icons.Rounded.MoreVert
    val Palette = Icons.Rounded.Palette
    val Pdf = Icons.Rounded.PictureAsPdf
    val Print = Icons.Rounded.Print
    val Refresh = Icons.Rounded.Refresh
    val Rotate = Icons.Rounded.RotateRight
    val Search = Icons.Rounded.Search
    val Settings = Icons.Rounded.Settings
    val Share = Icons.Rounded.Share
    val Slides = Icons.Rounded.Slideshow
    val Favorite = Icons.Rounded.Star
    val FavoriteOutline = Icons.Rounded.StarBorder
    val Storage = Icons.Rounded.Storage
    val Tune = Icons.Rounded.Tune
    val List = Icons.Rounded.ViewAgenda
    val ZoomIn = Icons.Rounded.ZoomIn
    val ZoomOut = Icons.Rounded.ZoomOut
}
