package com.pwp.reader.data.database

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface DocumentDao {
    @Query("SELECT * FROM documents ORDER BY lastOpenedAt DESC")
    fun observeAll(): Flow<List<DocumentEntity>>

    @Query("SELECT * FROM documents WHERE uri = :uri")
    fun observe(uri: String): Flow<DocumentEntity?>

    @Query("SELECT * FROM documents WHERE uri = :uri")
    suspend fun get(uri: String): DocumentEntity?

    @Query("SELECT uri FROM documents")
    suspend fun allUris(): List<String>

    // Upsert (not REPLACE) so foreign-key cascades never wipe bookmarks when a document is reopened.
    @Upsert
    suspend fun upsert(entity: DocumentEntity)

    @Query("UPDATE documents SET isFavorite = :favorite WHERE uri = :uri")
    suspend fun setFavorite(uri: String, favorite: Boolean)

    @Query("UPDATE documents SET lastPosition = :position, lastOffset = :offset WHERE uri = :uri")
    suspend fun setPosition(uri: String, position: Int, offset: Int)

    @Query("UPDATE documents SET pageCount = :count WHERE uri = :uri")
    suspend fun setPageCount(uri: String, count: Int)

    @Query("UPDATE documents SET lastOpenedAt = :time WHERE uri = :uri")
    suspend fun touch(uri: String, time: Long)

    @Query("DELETE FROM documents WHERE uri = :uri")
    suspend fun delete(uri: String)

    @Query("DELETE FROM documents")
    suspend fun deleteAll()
}

@Dao
interface BookmarkDao {
    @Query("SELECT * FROM bookmarks WHERE documentUri = :uri ORDER BY position ASC")
    fun observe(uri: String): Flow<List<BookmarkEntity>>

    @Upsert
    suspend fun upsert(entity: BookmarkEntity)

    @Query("DELETE FROM bookmarks WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface TextIndexDao {
    @Upsert
    suspend fun upsert(entity: DocumentTextEntity)

    @Query("SELECT EXISTS(SELECT 1 FROM document_text WHERE uri = :uri)")
    suspend fun has(uri: String): Boolean

    @Query(
        "SELECT d.* FROM documents d INNER JOIN document_text t ON t.uri = d.uri " +
            "WHERE t.content LIKE :pattern ESCAPE '\\' ORDER BY d.lastOpenedAt DESC",
    )
    suspend fun search(pattern: String): List<DocumentEntity>
}

@Dao
interface SearchHistoryDao {
    @Query("SELECT term FROM search_history ORDER BY usedAt DESC LIMIT 8")
    fun observeRecent(): Flow<List<String>>

    @Upsert
    suspend fun upsert(entity: SearchHistoryEntity)

    @Query("DELETE FROM search_history")
    suspend fun clear()
}
