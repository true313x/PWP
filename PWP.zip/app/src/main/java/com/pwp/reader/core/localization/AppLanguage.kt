package com.pwp.reader.core.localization

import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

/**
 * Interface languages. To add one: create res/values-<tag>/strings.xml, add its tag to
 * res/xml/locales_config.xml and add an entry below. Kurdish (ckb) is intentionally absent until a
 * native speaker has reviewed a translation.
 */
enum class AppLanguage(val tag: String?, val nativeName: String?) {
    SYSTEM(null, null),
    ENGLISH("en", "English"),
    ARABIC("ar", "العربية"),
    PERSIAN("fa", "فارسی"),
    SPANISH("es", "Español"),
    FRENCH("fr", "Français"),
    GERMAN("de", "Deutsch"),
    CHINESE("zh", "中文");

    companion object {
        fun current(): AppLanguage {
            val locales = AppCompatDelegate.getApplicationLocales()
            if (locales.isEmpty()) return SYSTEM
            val lang = locales[0]?.language
            return entries.firstOrNull { it.tag == lang } ?: SYSTEM
        }

        /** Recreates the activity; ViewModels and saved state survive the recreation. */
        fun apply(language: AppLanguage) {
            AppCompatDelegate.setApplicationLocales(
                if (language.tag == null) LocaleListCompat.getEmptyLocaleList()
                else LocaleListCompat.forLanguageTags(language.tag),
            )
        }
    }
}
