package com.pwp.reader.feature.powerpoint

import android.graphics.Bitmap
import android.net.Uri
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pwp.reader.core.common.ViewerError
import com.pwp.reader.core.common.decodeSampled
import com.pwp.reader.core.common.toViewerError
import com.pwp.reader.core.storage.AvailabilityTracker
import com.pwp.reader.core.storage.DocumentAccess
import com.pwp.reader.domain.model.PwpDocument
import com.pwp.reader.domain.model.UserSettings
import com.pwp.reader.domain.repository.DocumentRepository
import com.pwp.reader.domain.repository.SettingsRepository
import com.pwp.reader.domain.usecase.SaveReadingPosition
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import javax.inject.Inject

sealed interface PptxUiState {
    data object Loading : PptxUiState
    data class Failed(val error: ViewerError) : PptxUiState
    data class Ready(val pkg: PptxPackage, val startSlide: Int, val showThumbnails: Boolean) : PptxUiState
}

@HiltViewModel
class PptxViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val access: DocumentAccess,
    private val documents: DocumentRepository,
    private val settingsRepository: SettingsRepository,
    private val saveReadingPosition: SaveReadingPosition,
    private val tracker: AvailabilityTracker,
) : ViewModel() {

    val uri: String = savedStateHandle.get<String>("uri").orEmpty()

    private val _state = MutableStateFlow<PptxUiState>(PptxUiState.Loading)
    val state: StateFlow<PptxUiState> = _state

    val document: StateFlow<PwpDocument?> = (if (uri.isEmpty()) emptyFlow<PwpDocument?>() else documents.observe(uri))
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    val settings: StateFlow<UserSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UserSettings())

    private val _partialSlides = MutableStateFlow<Set<Int>>(emptySet())
    /** Slides that contain content PWP cannot render. */
    val partialSlides: StateFlow<Set<Int>> = _partialSlides

    private val slideCache = LruCache<Int, SlideContent>(8)
    private val imageCache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    init { load() }

    fun load() {
        if (uri.isEmpty()) {
            _state.value = PptxUiState.Failed(ViewerError.NOT_FOUND)
            return
        }
        _state.value = PptxUiState.Loading
        viewModelScope.launch {
            try {
                val file = access.copyToCache(Uri.parse(uri), "pptx", MAX_OOXML_BYTES)
                val pkg = withContext(Dispatchers.Default) {
                    try { PptxPackage.open(file) } catch (t: Throwable) { file.delete(); throw t }
                }
                val settings = settingsRepository.settings.first()
                documents.touch(uri)
                documents.updatePageCount(uri, pkg.slideCount)
                tracker.markAvailable(uri)
                val saved = documents.get(uri)
                val start = if (settings.rememberPosition && saved != null) saved.lastPosition.coerceIn(0, pkg.slideCount - 1) else 0
                _state.value = PptxUiState.Ready(pkg, start, settings.showSlideThumbnails)
                indexText(pkg)
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                val error = t.toViewerError()
                if (error == ViewerError.NOT_FOUND || error == ViewerError.PERMISSION) tracker.markUnavailable(uri)
                _state.value = PptxUiState.Failed(error)
            }
        }
    }

    /** Parses a slide off the main thread; null when the slide is damaged. Results are cached. */
    suspend fun slide(index: Int): SlideContent? {
        slideCache.get(index)?.let { return it }
        val pkg = (_state.value as? PptxUiState.Ready)?.pkg ?: return null
        val content = withContext(Dispatchers.Default) { runCatching { pkg.slide(index) }.getOrNull() } ?: return null
        slideCache.put(index, content)
        if (content.partial) _partialSlides.value = _partialSlides.value + index
        return content
    }

    suspend fun image(entry: String, targetWidthPx: Int): ImageBitmap? {
        val pkg = (_state.value as? PptxUiState.Ready)?.pkg ?: return null
        var bucket = 128
        while (bucket < targetWidthPx && bucket < 2048) bucket *= 2
        val key = "$entry@$bucket"
        imageCache.get(key)?.let { return it.asImageBitmap() }
        val bitmap = withContext(Dispatchers.IO) { decodeSampled(bucket) { pkg.openEntry(entry) } } ?: return null
        imageCache.put(key, bitmap)
        return bitmap.asImageBitmap()
    }

    private fun indexText(pkg: PptxPackage) {
        viewModelScope.launch(Dispatchers.Default) {
            val sb = StringBuilder()
            for (i in 0 until pkg.slideCount) {
                runCatching { pkg.slide(i).text }.getOrNull()?.let { sb.append(it).append('\n') }
                if (sb.length > 1_000_000) break
                yield()
            }
            documents.indexText(uri, sb.toString())
        }
    }

    fun savePosition(slide: Int) {
        viewModelScope.launch { withContext(NonCancellable) { saveReadingPosition(uri, slide, 0) } }
    }

    suspend fun removeFromHistory() = documents.remove(uri)

    override fun onCleared() {
        (_state.value as? PptxUiState.Ready)?.pkg?.close()
        imageCache.evictAll()
    }

    private companion object { const val MAX_OOXML_BYTES = 120L * 1024 * 1024 }
}
