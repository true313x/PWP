package com.pwp.reader.feature.powerpoint

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import com.pwp.reader.R
import kotlin.math.roundToInt

private const val EMU_PER_PT = 12700f

/**
 * Draws one slide with Compose primitives (vector text, no big bitmaps): every EMU coordinate is scaled by
 * `width in px / slide width`. The same composable renders the full slide and the thumbnails.
 * The caller must give [modifier] a bounded width.
 */
@Composable
fun SlideView(
    slide: SlideContent,
    size: SlideSize,
    loadImage: suspend (String, Int) -> ImageBitmap?,
    modifier: Modifier = Modifier,
) {
    BoxWithConstraints(
        modifier
            .aspectRatio(size.width / size.height)
            .clipToBounds()
            .background(Color(slide.background)),
    ) {
        val scale = constraints.maxWidth / size.width
        slide.shapes.forEach { shape -> ShapeLayer(shape, scale, loadImage) }
    }
}

@Composable
private fun ShapeLayer(shape: SlideShape, scale: Float, loadImage: suspend (String, Int) -> ImageBitmap?) {
    val density = LocalDensity.current
    val r = shape.rect
    val wPx = r.w * scale
    val hPx = r.h * scale
    Box(
        Modifier
            .offset { IntOffset((r.x * scale).roundToInt(), (r.y * scale).roundToInt()) }
            .size(with(density) { wPx.toDp() }, with(density) { hPx.toDp() })
            .graphicsLayer { rotationZ = shape.rotation },
    ) {
        when (shape) {
            is BoxShape -> BoxContent(shape, scale)
            is PictureShape -> PictureContent(shape, wPx.roundToInt(), loadImage)
            is LineShape -> LineContent(shape, scale)
            is TableShape -> TableContent(shape, scale)
            is UnsupportedShape -> UnsupportedContent(shape)
        }
    }
}

@Composable
private fun BoxContent(shape: BoxShape, scale: Float) {
    val fill = shape.fill?.let { Color(it) }
    val line = shape.line?.let { Color(it) }
    val strokePx = (shape.lineWidth * scale).coerceAtLeast(1f)
    Box(
        Modifier
            .fillMaxSize()
            .drawBehind {
                when (shape.geometry) {
                    Geometry.RECT -> {
                        fill?.let { drawRect(it) }
                        line?.let { drawRect(it, style = Stroke(strokePx)) }
                    }
                    Geometry.ROUND_RECT -> {
                        val radius = CornerRadius(minOf(size.width, size.height) * 0.1667f)
                        fill?.let { drawRoundRect(it, cornerRadius = radius) }
                        line?.let { drawRoundRect(it, cornerRadius = radius, style = Stroke(strokePx)) }
                    }
                    Geometry.ELLIPSE -> {
                        fill?.let { drawOval(it) }
                        line?.let { drawOval(it, style = Stroke(strokePx)) }
                    }
                }
            }
            .clipToBounds(),
    ) {
        shape.text?.let { TextBodyView(it, scale) }
    }
}

@Composable
private fun PictureContent(shape: PictureShape, widthPx: Int, loadImage: suspend (String, Int) -> ImageBitmap?) {
    val image by produceState<ImageBitmap?>(null, shape.entry, widthPx) { value = loadImage(shape.entry, widthPx) }
    image?.let {
        Image(it, contentDescription = shape.alt, contentScale = ContentScale.FillBounds, modifier = Modifier.fillMaxSize())
    }
}

@Composable
private fun LineContent(shape: LineShape, scale: Float) {
    val color = Color(shape.color)
    val width = (shape.width * scale).coerceAtLeast(1f)
    Canvas(Modifier.fillMaxSize()) {
        val start = Offset(if (shape.flipH) size.width else 0f, if (shape.flipV) size.height else 0f)
        val end = Offset(if (shape.flipH) 0f else size.width, if (shape.flipV) 0f else size.height)
        drawLine(color, start, end, strokeWidth = width)
    }
}

@Composable
private fun TableContent(shape: TableShape, scale: Float) {
    val density = LocalDensity.current
    val border = Color.Gray.copy(alpha = 0.5f)
    Column(Modifier.fillMaxSize()) {
        shape.rows.forEach { row ->
            Row(Modifier.fillMaxWidth().height(with(density) { (row.height * scale).toDp() })) {
                row.cells.forEachIndexed { ci, cell ->
                    val w = shape.columns.getOrNull(ci) ?: 0f
                    Box(
                        Modifier
                            .width(with(density) { (w * scale).toDp() })
                            .fillMaxHeight()
                            .then(if (cell.fill != null) Modifier.background(Color(cell.fill)) else Modifier)
                            .border(0.5.dp, border)
                            .clipToBounds(),
                    ) {
                        cell.text?.let { TextBodyView(it, scale) }
                    }
                }
            }
        }
    }
}

@Composable
private fun UnsupportedContent(shape: UnsupportedShape) {
    val label = stringResource(
        when (shape.kind) {
            UnsupportedKind.CHART -> R.string.slide_unsupported_chart
            UnsupportedKind.SMART_ART -> R.string.slide_unsupported_smartart
            UnsupportedKind.OTHER -> R.string.slide_unsupported_other
        },
    )
    Box(
        Modifier.fillMaxSize().border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)).padding(4.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
    }
}

@Composable
private fun TextBodyView(body: TextBody, scale: Float) {
    val density = LocalDensity.current
    fun emu(v: Float) = with(density) { (v * scale).toDp() }
    Column(
        Modifier
            .fillMaxSize()
            .padding(start = emu(body.insetL), top = emu(body.insetT), end = emu(body.insetR), bottom = emu(body.insetB)),
        verticalArrangement = when (body.anchor) {
            TextAnchor.TOP -> Arrangement.Top
            TextAnchor.CENTER -> Arrangement.Center
            TextAnchor.BOTTOM -> Arrangement.Bottom
        },
    ) {
        body.paragraphs.forEach { SlideParagraphView(it, body.fontScale, scale) }
    }
}

private fun Density.pointsToSp(pt: Float, scale: Float, fontScale: Float) =
    (pt * EMU_PER_PT * scale * fontScale).toSp()

@Composable
private fun SlideParagraphView(p: SlideParagraph, fontScale: Float, scale: Float) {
    val density = LocalDensity.current
    val text = remember(p, scale, fontScale, density) {
        buildAnnotatedString {
            for (run in p.runs) {
                val decorations = listOfNotNull(
                    if (run.underline) TextDecoration.Underline else null,
                    if (run.strike) TextDecoration.LineThrough else null,
                )
                withStyle(
                    SpanStyle(
                        fontSize = density.pointsToSp(run.sizePt, scale, fontScale),
                        fontWeight = if (run.bold) FontWeight.Bold else null,
                        fontStyle = if (run.italic) FontStyle.Italic else null,
                        textDecoration = if (decorations.isEmpty()) null else TextDecoration.combine(decorations),
                        color = Color(run.color),
                    ),
                ) { append(run.text.ifEmpty { " " }) }
            }
        }
    }
    val style = TextStyle(
        textAlign = when (p.align) {
            PptAlign.LEFT -> TextAlign.Left
            PptAlign.CENTER -> TextAlign.Center
            PptAlign.RIGHT -> TextAlign.Right
            PptAlign.JUSTIFY -> TextAlign.Justify
        },
        textDirection = if (p.rtl) TextDirection.Rtl else TextDirection.Content,
    )
    val indent = with(density) { (p.level * 342900f * scale).toDp() }
    val direction = if (p.rtl) LayoutDirection.Rtl else LocalLayoutDirection.current
    CompositionLocalProvider(LocalLayoutDirection provides direction) {
        Row(Modifier.fillMaxWidth().padding(start = indent)) {
            p.bullet?.let { bullet ->
                val first = p.runs.first()
                Text(
                    bullet,
                    style = style,
                    color = Color(first.color),
                    fontSize = density.pointsToSp(first.sizePt, scale, fontScale),
                    modifier = Modifier.padding(end = with(density) { (91440f * scale).toDp() }),
                )
            }
            Text(text, style = style, modifier = Modifier.weight(1f))
        }
    }
}
