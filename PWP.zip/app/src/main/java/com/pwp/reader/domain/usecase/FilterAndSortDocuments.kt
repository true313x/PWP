package com.pwp.reader.domain.usecase

import com.pwp.reader.core.common.TextNormalizer
import com.pwp.reader.domain.model.DocumentFormat
import com.pwp.reader.domain.model.PwpDocument
import com.pwp.reader.domain.model.SortField
import com.pwp.reader.domain.model.SortOrder
import javax.inject.Inject

/** Filename search (script-aware), format filter and sorting for document lists. */
class FilterAndSortDocuments @Inject constructor() {
    operator fun invoke(
        documents: List<PwpDocument>,
        query: String = "",
        format: DocumentFormat? = null,
        order: SortOrder = SortOrder(),
    ): List<PwpDocument> {
        val q = TextNormalizer.normalize(query).trim()
        val filtered = documents.filter { d ->
            (format == null || d.format == format) &&
                (q.isEmpty() || TextNormalizer.normalize(d.name).contains(q))
        }
        val comparator: Comparator<PwpDocument> = when (order.field) {
            SortField.NAME -> compareBy(String.CASE_INSENSITIVE_ORDER) { it.name }
            SortField.DATE -> compareBy<PwpDocument> { it.lastOpenedAt }
            SortField.SIZE -> compareBy<PwpDocument> { it.sizeBytes ?: -1L }
            SortField.TYPE -> compareBy<PwpDocument> { it.format.ordinal }
                .thenBy(String.CASE_INSENSITIVE_ORDER) { it.name }
        }
        return filtered.sortedWith(if (order.ascending) comparator else comparator.reversed())
    }
}
