package com.pwp.reader.feature.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pwp.reader.core.storage.CacheManager
import com.pwp.reader.domain.model.UserSettings
import com.pwp.reader.domain.repository.DocumentRepository
import com.pwp.reader.domain.repository.SearchHistoryRepository
import com.pwp.reader.domain.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val documents: DocumentRepository,
    private val searchHistory: SearchHistoryRepository,
    private val cache: CacheManager,
) : ViewModel() {

    val settings: StateFlow<UserSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UserSettings())

    private val _cacheBytes = MutableStateFlow<Long?>(null)
    val cacheBytes: StateFlow<Long?> = _cacheBytes

    init { refreshCache() }

    fun update(transform: (UserSettings) -> UserSettings) {
        viewModelScope.launch { settingsRepository.update(transform) }
    }

    /** Clears recent documents, positions, bookmarks, favorites, content index and recent searches. */
    suspend fun clearHistory() {
        documents.clearAll()
        searchHistory.clear()
    }

    suspend fun clearCache() {
        cache.clear()
        refreshCache()
    }

    private fun refreshCache() {
        viewModelScope.launch { _cacheBytes.value = cache.sizeBytes() }
    }
}
