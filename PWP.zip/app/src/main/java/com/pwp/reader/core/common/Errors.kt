package com.pwp.reader.core.common

import org.xmlpull.v1.XmlPullParserException
import java.io.FileNotFoundException
import java.io.IOException

class DocumentTooLargeException : IOException("Document too large")
class UnsupportedDocumentException : IOException("Unsupported document")
class PasswordRequiredException(val wrong: Boolean, val supported: Boolean) : IOException("Password required")

enum class ViewerError { NOT_FOUND, PERMISSION, CORRUPT, TOO_LARGE, UNSUPPORTED, GENERIC }

fun Throwable.toViewerError(): ViewerError = when (this) {
    is DocumentTooLargeException -> ViewerError.TOO_LARGE
    is OutOfMemoryError -> ViewerError.TOO_LARGE
    is UnsupportedDocumentException -> ViewerError.UNSUPPORTED
    is FileNotFoundException -> ViewerError.NOT_FOUND
    is SecurityException -> ViewerError.PERMISSION
    is IOException, is XmlPullParserException, is IllegalArgumentException,
    is IndexOutOfBoundsException, is NumberFormatException -> ViewerError.CORRUPT
    else -> ViewerError.GENERIC
}
