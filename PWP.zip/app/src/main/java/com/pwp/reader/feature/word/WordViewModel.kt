package com.pwp.reader.feature.word

import android.content.Context
import android.net.Uri
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pwp.reader.core.common.ViewerError
import com.pwp.reader.core.common.toViewerError
import com.pwp.reader.core.storage.AvailabilityTracker
import com.pwp.reader.core.storage.DocumentAccess
import com.pwp.reader.domain.model.Bookmark
import com.pwp.reader.domain.model.PwpDocument
import com.pwp.reader.domain.model.UserSettings
import com.pwp.reader.domain.repository.DocumentRepository
import com.pwp.reader.domain.repository.SettingsRepository
import com.pwp.reader.domain.usecase.SaveReadingPosition
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject

sealed interface WordUiState {
    data object Loading : WordUiState
    data class Failed(val error: ViewerError) : WordUiState
    data class Ready(val document: DocxDocument, val startIndex: Int, val startOffset: Int) : WordUiState
}

@HiltViewModel
class WordViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    @ApplicationContext private val context: Context,
    private val access: DocumentAccess,
    private val documents: DocumentRepository,
    private val settingsRepository: SettingsRepository,
    private val saveReadingPosition: SaveReadingPosition,
    private val tracker: AvailabilityTracker,
) : ViewModel() {

    val uri: String = savedStateHandle.get<String>("uri").orEmpty()

    private val _state = MutableStateFlow<WordUiState>(WordUiState.Loading)
    val state: StateFlow<WordUiState> = _state

    val document: StateFlow<PwpDocument?> = (if (uri.isEmpty()) emptyFlow<PwpDocument?>() else documents.observe(uri))
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    val bookmarks: StateFlow<List<Bookmark>> = (if (uri.isEmpty()) emptyFlow<List<Bookmark>>() else documents.observeBookmarks(uri))
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val settings: StateFlow<UserSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UserSettings())

    private val imageDir = File(context.cacheDir, "docx-img/${System.nanoTime()}")

    init { load() }

    fun load() {
        if (uri.isEmpty()) {
            _state.value = WordUiState.Failed(ViewerError.NOT_FOUND)
            return
        }
        _state.value = WordUiState.Loading
        viewModelScope.launch {
            try {
                val file = access.copyToCache(Uri.parse(uri), "docx", MAX_OOXML_BYTES)
                val parsed = withContext(Dispatchers.Default) {
                    try { DocxParser.parse(file, imageDir) } finally { file.delete() }
                }
                val settings = settingsRepository.settings.first()
                documents.touch(uri)
                tracker.markAvailable(uri)
                val saved = documents.get(uri)
                val remembered = settings.rememberPosition && saved != null
                _state.value = WordUiState.Ready(
                    document = parsed,
                    startIndex = if (remembered) saved!!.lastPosition.coerceIn(0, (parsed.blocks.size - 1).coerceAtLeast(0)) else 0,
                    startOffset = if (remembered) saved!!.lastOffset else 0,
                )
                // Content index for full-text search from the library; runs off the main thread.
                launch(Dispatchers.Default) { documents.indexText(uri, parsed.plainText()) }
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                val error = t.toViewerError()
                if (error == ViewerError.NOT_FOUND || error == ViewerError.PERMISSION) tracker.markUnavailable(uri)
                _state.value = WordUiState.Failed(error)
            }
        }
    }

    fun savePosition(index: Int, offset: Int) {
        viewModelScope.launch { withContext(NonCancellable) { saveReadingPosition(uri, index, offset) } }
    }

    fun toggleBookmark(blockIndex: Int, snippet: String?) {
        viewModelScope.launch {
            val existing = bookmarks.value.firstOrNull { it.position == blockIndex }
            if (existing != null) documents.removeBookmark(existing.id)
            else documents.addBookmark(uri, blockIndex, snippet?.trim()?.take(80)?.ifBlank { null })
        }
    }

    fun removeBookmark(id: Long) { viewModelScope.launch { documents.removeBookmark(id) } }

    fun updateSettings(transform: (UserSettings) -> UserSettings) {
        viewModelScope.launch { settingsRepository.update(transform) }
    }

    suspend fun removeFromHistory() = documents.remove(uri)

    override fun onCleared() {
        imageDir.deleteRecursively()
    }

    private companion object { const val MAX_OOXML_BYTES = 80L * 1024 * 1024 }
}
