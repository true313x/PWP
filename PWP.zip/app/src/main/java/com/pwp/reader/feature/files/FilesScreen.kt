package com.pwp.reader.feature.files

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pwp.reader.R
import com.pwp.reader.core.designsystem.DocumentCollection
import com.pwp.reader.core.designsystem.EmptyState
import com.pwp.reader.core.designsystem.LoadingState
import com.pwp.reader.core.designsystem.LocalSnackbarHostState
import com.pwp.reader.core.designsystem.PwpIcons
import com.pwp.reader.core.designsystem.PwpScreen
import com.pwp.reader.core.designsystem.PwpSearchField
import com.pwp.reader.core.designsystem.ScreenTitle
import com.pwp.reader.core.designsystem.labelRes
import com.pwp.reader.domain.model.DocumentFormat
import com.pwp.reader.domain.model.SortField
import com.pwp.reader.domain.model.ViewMode
import com.pwp.reader.feature.viewer.rememberDocumentLauncher
import kotlinx.coroutines.launch

@Composable
fun FilesScreen(
    onOpenDocument: (DocumentFormat, String) -> Unit,
    onOpenSearch: () -> Unit,
    viewModel: FilesViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val unavailable by viewModel.unavailable.collectAsStateWithLifecycle()
    val launcher = rememberDocumentLauncher(onOpenDocument)
    val snackbar = LocalSnackbarHostState.current
    val scope = rememberCoroutineScope()
    val removedMessage = stringResource(R.string.removed_from_history)
    var sortMenu by remember { mutableStateOf(false) }

    PwpScreen {
        ScreenTitle(stringResource(R.string.files_title)) {
            IconButton(onClick = viewModel::refresh) {
                Icon(PwpIcons.Refresh, contentDescription = stringResource(R.string.refresh))
            }
            val grid = state.viewMode == ViewMode.GRID
            IconButton(onClick = { viewModel.setViewMode(if (grid) ViewMode.LIST else ViewMode.GRID) }) {
                Icon(
                    if (grid) PwpIcons.List else PwpIcons.Grid,
                    contentDescription = stringResource(if (grid) R.string.view_list else R.string.view_grid),
                )
            }
            Box {
                IconButton(onClick = { sortMenu = true }) {
                    Icon(PwpIcons.Sort, contentDescription = stringResource(R.string.sort_by))
                }
                DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                    val current = state.criteria.order.field
                    listOf(
                        SortField.NAME to R.string.sort_name,
                        SortField.DATE to R.string.sort_date,
                        SortField.SIZE to R.string.sort_size,
                        SortField.TYPE to R.string.sort_type,
                    ).forEach { (field, label) ->
                        DropdownMenuItem(
                            text = { Text(stringResource(label)) },
                            leadingIcon = { if (field == current) Icon(PwpIcons.Check, contentDescription = null) },
                            onClick = { viewModel.setSortField(field); sortMenu = false },
                        )
                    }
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.sort_reverse)) },
                        leadingIcon = { Icon(PwpIcons.Sort, contentDescription = null) },
                        onClick = { viewModel.reverseOrder(); sortMenu = false },
                    )
                }
            }
        }
        PwpSearchField(
            value = state.criteria.query,
            onValueChange = viewModel::setQuery,
            hint = stringResource(R.string.search_hint),
            modifier = Modifier.padding(horizontal = 20.dp),
        )
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FilterChip(
                selected = state.criteria.format == null,
                onClick = { viewModel.setFormat(null) },
                label = { Text(stringResource(R.string.filter_all)) },
            )
            DocumentFormat.entries.forEach { f ->
                FilterChip(
                    selected = state.criteria.format == f,
                    onClick = { viewModel.setFormat(f) },
                    label = { Text(stringResource(f.labelRes())) },
                )
            }
        }
        if (state.isRefreshing) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 20.dp))

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                state.isLoading -> LoadingState()
                state.totalCount == 0 -> EmptyState(
                    title = stringResource(R.string.files_empty_title),
                    body = stringResource(R.string.files_empty_body),
                    actionLabel = stringResource(R.string.action_open_document),
                    onAction = launcher::browse,
                )
                state.documents.isEmpty() -> EmptyState(
                    title = stringResource(R.string.search_no_results),
                    body = stringResource(R.string.search_no_results_body),
                )
                else -> DocumentCollection(
                    documents = state.documents,
                    viewMode = state.viewMode,
                    unavailable = unavailable,
                    onOpen = { onOpenDocument(it.format, it.uri) },
                    onToggleFavorite = viewModel::toggleFavorite,
                    onRemove = { d -> scope.launch { viewModel.remove(d); snackbar.showSnackbar(removedMessage) } },
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 96.dp),
                )
            }
            ExtendedFloatingActionButton(
                onClick = launcher::browse,
                icon = { Icon(PwpIcons.Add, contentDescription = null) },
                text = { Text(stringResource(R.string.action_open_document)) },
                modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
            )
        }
    }
}
