package com.pwp.reader.feature.powerpoint

/** All geometry is in EMU (914400 per inch), exactly as stored in the file. */
data class EmuRect(val x: Float, val y: Float, val w: Float, val h: Float)
data class SlideSize(val width: Float, val height: Float)

enum class PptAlign { LEFT, CENTER, RIGHT, JUSTIFY }
enum class TextAnchor { TOP, CENTER, BOTTOM }

data class SlideRun(
    val text: String,
    val sizePt: Float,
    val bold: Boolean,
    val italic: Boolean,
    val underline: Boolean,
    val strike: Boolean,
    /** ARGB. */
    val color: Int,
)

data class SlideParagraph(val runs: List<SlideRun>, val align: PptAlign, val level: Int, val bullet: String?, val rtl: Boolean) {
    val text: String get() = runs.joinToString("") { it.text }
}

data class TextBody(
    val paragraphs: List<SlideParagraph>,
    val anchor: TextAnchor,
    val insetL: Float,
    val insetT: Float,
    val insetR: Float,
    val insetB: Float,
    val fontScale: Float,
)

enum class Geometry { RECT, ROUND_RECT, ELLIPSE }
enum class UnsupportedKind { CHART, SMART_ART, OTHER }

sealed interface SlideShape {
    val rect: EmuRect
    val rotation: Float
}

data class BoxShape(
    override val rect: EmuRect,
    override val rotation: Float,
    val geometry: Geometry,
    val fill: Int?,
    val line: Int?,
    val lineWidth: Float,
    val text: TextBody?,
) : SlideShape

data class PictureShape(override val rect: EmuRect, override val rotation: Float, val entry: String, val alt: String?) : SlideShape

data class LineShape(
    override val rect: EmuRect,
    override val rotation: Float,
    val flipH: Boolean,
    val flipV: Boolean,
    val color: Int,
    val width: Float,
) : SlideShape

data class TableCell(val text: TextBody?, val fill: Int?)
data class TableRow(val height: Float, val cells: List<TableCell>)
data class TableShape(override val rect: EmuRect, override val rotation: Float, val columns: List<Float>, val rows: List<TableRow>) : SlideShape
data class UnsupportedShape(override val rect: EmuRect, override val rotation: Float, val kind: UnsupportedKind) : SlideShape

/** [partial] is true when something on the slide could not be rendered (charts, SmartArt, odd shapes, media...). */
data class SlideContent(val shapes: List<SlideShape>, val background: Int, val partial: Boolean, val text: String)
