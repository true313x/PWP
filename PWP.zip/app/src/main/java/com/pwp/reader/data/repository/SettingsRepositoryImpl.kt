package com.pwp.reader.data.repository

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.pwp.reader.domain.model.AccentColor
import com.pwp.reader.domain.model.PdfZoomMode
import com.pwp.reader.domain.model.ReadingTheme
import com.pwp.reader.domain.model.ThemeMode
import com.pwp.reader.domain.model.UserSettings
import com.pwp.reader.domain.model.ViewMode
import com.pwp.reader.domain.repository.SettingsRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

private val Context.settingsDataStore by preferencesDataStore(name = "pwp_settings")

@Singleton
class SettingsRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context,
) : SettingsRepository {

    override val settings: Flow<UserSettings> = context.settingsDataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { it.toSettings() }

    override suspend fun update(transform: (UserSettings) -> UserSettings) {
        context.settingsDataStore.edit { prefs -> prefs.write(transform(prefs.toSettings())) }
    }

    private object Keys {
        val theme = stringPreferencesKey("theme")
        val accent = stringPreferencesKey("accent")
        val viewMode = stringPreferencesKey("view_mode")
        val pdfZoom = stringPreferencesKey("pdf_zoom")
        val remember = booleanPreferencesKey("remember_position")
        val pageControls = booleanPreferencesKey("page_controls")
        val keepOn = booleanPreferencesKey("keep_screen_on")
        val wordSize = floatPreferencesKey("word_size")
        val wordSpacing = floatPreferencesKey("word_spacing")
        val wordMargin = intPreferencesKey("word_margin")
        val wordTheme = stringPreferencesKey("word_theme")
        val thumbs = booleanPreferencesKey("slide_thumbs")
    }

    private inline fun <reified T : Enum<T>> Preferences.enum(key: Preferences.Key<String>, default: T): T =
        this[key]?.let { name -> enumValues<T>().firstOrNull { it.name == name } } ?: default

    private fun Preferences.toSettings(): UserSettings {
        val d = UserSettings()
        return UserSettings(
            themeMode = enum(Keys.theme, d.themeMode),
            accent = enum(Keys.accent, d.accent),
            defaultViewMode = enum(Keys.viewMode, d.defaultViewMode),
            pdfZoomMode = enum(Keys.pdfZoom, d.pdfZoomMode),
            rememberPosition = this[Keys.remember] ?: d.rememberPosition,
            showPageControls = this[Keys.pageControls] ?: d.showPageControls,
            keepScreenOn = this[Keys.keepOn] ?: d.keepScreenOn,
            wordFontSizeSp = this[Keys.wordSize] ?: d.wordFontSizeSp,
            wordLineSpacing = this[Keys.wordSpacing] ?: d.wordLineSpacing,
            wordMarginDp = this[Keys.wordMargin] ?: d.wordMarginDp,
            wordTheme = enum(Keys.wordTheme, d.wordTheme),
            showSlideThumbnails = this[Keys.thumbs] ?: d.showSlideThumbnails,
        )
    }

    private fun androidx.datastore.preferences.core.MutablePreferences.write(s: UserSettings) {
        this[Keys.theme] = s.themeMode.name
        this[Keys.accent] = s.accent.name
        this[Keys.viewMode] = s.defaultViewMode.name
        this[Keys.pdfZoom] = s.pdfZoomMode.name
        this[Keys.remember] = s.rememberPosition
        this[Keys.pageControls] = s.showPageControls
        this[Keys.keepOn] = s.keepScreenOn
        this[Keys.wordSize] = s.wordFontSizeSp
        this[Keys.wordSpacing] = s.wordLineSpacing
        this[Keys.wordMargin] = s.wordMarginDp
        this[Keys.wordTheme] = s.wordTheme.name
        this[Keys.thumbs] = s.showSlideThumbnails
    }
}
