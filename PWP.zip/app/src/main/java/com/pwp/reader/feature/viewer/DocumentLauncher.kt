package com.pwp.reader.feature.viewer

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalContext
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import com.pwp.reader.R
import com.pwp.reader.core.designsystem.LocalSnackbarHostState
import com.pwp.reader.domain.model.DocumentFormat
import com.pwp.reader.domain.model.OpenResult
import com.pwp.reader.domain.repository.DocumentRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PickerViewModel @Inject constructor(private val documents: DocumentRepository) : ViewModel() {
    suspend fun open(uri: String): OpenResult = documents.open(uri)
}

class DocumentLauncher(
    private val pick: (Array<String>) -> Unit,
    val openUri: (String) -> Unit,
) {
    fun openPdf() = pick(arrayOf(DocumentFormat.PDF.mimeType))
    fun openWord() = pick(arrayOf(DocumentFormat.DOCX.mimeType))
    fun openPowerPoint() = pick(arrayOf(DocumentFormat.PPTX.mimeType))

    /** Some file managers label Office files as octet-stream, so "browse all" also lists those. */
    fun browse() = pick(DocumentFormat.entries.map { it.mimeType }.toTypedArray() + "application/octet-stream")
}

/**
 * Storage Access Framework picker. Registers the chosen file in history, then calls [onOpen];
 * unsupported or missing files are reported in a snackbar instead of opening a blank viewer.
 */
@Composable
fun rememberDocumentLauncher(onOpen: (DocumentFormat, String) -> Unit): DocumentLauncher {
    val viewModel: PickerViewModel = hiltViewModel()
    val snackbar = LocalSnackbarHostState.current
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val currentOnOpen by rememberUpdatedState(onOpen)

    val handleUri: (String) -> Unit = { uri ->
        scope.launch {
            when (val result = viewModel.open(uri)) {
                is OpenResult.Opened -> currentOnOpen(result.document.format, result.document.uri)
                OpenResult.Unsupported -> snackbar.showSnackbar(context.getString(R.string.error_unsupported))
                OpenResult.Unavailable -> snackbar.showSnackbar(context.getString(R.string.error_not_found))
            }
        }
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) handleUri(uri.toString())
    }
    return remember(launcher) { DocumentLauncher(pick = { types -> launcher.launch(types) }, openUri = handleUri) }
}
