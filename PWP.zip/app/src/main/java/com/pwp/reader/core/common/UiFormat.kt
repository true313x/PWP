package com.pwp.reader.core.common

import android.content.Context
import android.text.format.DateUtils
import android.text.format.Formatter

fun formatFileSize(context: Context, bytes: Long): String = Formatter.formatShortFileSize(context, bytes)

fun formatLastOpened(context: Context, millis: Long): String =
    DateUtils.getRelativeDateTimeString(
        context, millis, DateUtils.MINUTE_IN_MILLIS, DateUtils.WEEK_IN_MILLIS, 0,
    ).toString()
