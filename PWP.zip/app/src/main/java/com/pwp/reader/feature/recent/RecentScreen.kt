package com.pwp.reader.feature.recent

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.pwp.reader.R
import com.pwp.reader.core.designsystem.DocumentCollection
import com.pwp.reader.core.designsystem.EmptyState
import com.pwp.reader.core.designsystem.LoadingState
import com.pwp.reader.core.designsystem.LocalSnackbarHostState
import com.pwp.reader.core.designsystem.PwpScreen
import com.pwp.reader.core.designsystem.ScreenTitle
import com.pwp.reader.core.storage.AvailabilityTracker
import com.pwp.reader.domain.model.DocumentFormat
import com.pwp.reader.domain.model.PwpDocument
import com.pwp.reader.domain.model.ViewMode
import com.pwp.reader.domain.repository.DocumentRepository
import com.pwp.reader.domain.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class RecentState(
    val isLoading: Boolean = true,
    val documents: List<PwpDocument> = emptyList(),
    val viewMode: ViewMode = ViewMode.LIST,
)

@HiltViewModel
class RecentViewModel @Inject constructor(
    private val documents: DocumentRepository,
    settings: SettingsRepository,
    tracker: AvailabilityTracker,
) : ViewModel() {
    val unavailable = tracker.unavailable

    val state: StateFlow<RecentState> = combine(documents.observeAll(), settings.settings) { all, s ->
        RecentState(false, all.take(LIMIT), s.defaultViewMode)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), RecentState())

    init {
        viewModelScope.launch { tracker.check(documents.observeAll().first().take(LIMIT).map { it.uri }) }
    }

    fun toggleFavorite(d: PwpDocument) { viewModelScope.launch { documents.setFavorite(d.uri, !d.isFavorite) } }
    suspend fun remove(d: PwpDocument) = documents.remove(d.uri)

    private companion object { const val LIMIT = 50 }
}

@Composable
fun RecentScreen(
    onOpenDocument: (DocumentFormat, String) -> Unit,
    viewModel: RecentViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val unavailable by viewModel.unavailable.collectAsStateWithLifecycle()
    val snackbar = LocalSnackbarHostState.current
    val scope = rememberCoroutineScope()
    val removedMessage = stringResource(R.string.removed_from_history)

    PwpScreen {
        ScreenTitle(stringResource(R.string.recent_title))
        Box(Modifier.weight(1f)) {
            when {
                state.isLoading -> LoadingState()
                state.documents.isEmpty() -> EmptyState(
                    title = stringResource(R.string.recent_empty_title),
                    body = stringResource(R.string.recent_empty_body),
                )
                else -> DocumentCollection(
                    documents = state.documents,
                    viewMode = state.viewMode,
                    unavailable = unavailable,
                    onOpen = { onOpenDocument(it.format, it.uri) },
                    onToggleFavorite = viewModel::toggleFavorite,
                    onRemove = { d -> scope.launch { viewModel.remove(d); snackbar.showSnackbar(removedMessage) } },
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
    }
}
