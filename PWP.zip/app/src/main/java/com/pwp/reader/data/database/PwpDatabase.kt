package com.pwp.reader.data.database

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [DocumentEntity::class, BookmarkEntity::class, DocumentTextEntity::class, SearchHistoryEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class PwpDatabase : RoomDatabase() {
    abstract fun documentDao(): DocumentDao
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun textIndexDao(): TextIndexDao
    abstract fun searchHistoryDao(): SearchHistoryDao
}
