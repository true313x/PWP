package com.pwp.reader.feature.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pwp.reader.domain.model.DocumentFormat
import com.pwp.reader.domain.model.PwpDocument
import com.pwp.reader.domain.model.SortField
import com.pwp.reader.domain.model.SortOrder
import com.pwp.reader.domain.repository.DocumentRepository
import com.pwp.reader.domain.repository.SearchHistoryRepository
import com.pwp.reader.domain.usecase.FilterAndSortDocuments
import com.pwp.reader.core.storage.AvailabilityTracker
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.mapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class SearchMode { FILENAME, CONTENT }

data class SearchUiState(
    val query: String = "",
    val mode: SearchMode = SearchMode.FILENAME,
    val format: DocumentFormat? = null,
    val results: List<PwpDocument> = emptyList(),
    val recentSearches: List<String> = emptyList(),
)

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
@HiltViewModel
class SearchViewModel @Inject constructor(
    private val documents: DocumentRepository,
    private val history: SearchHistoryRepository,
    private val filterAndSort: FilterAndSortDocuments,
    tracker: AvailabilityTracker,
) : ViewModel() {

    private val query = MutableStateFlow("")
    private val mode = MutableStateFlow(SearchMode.FILENAME)
    private val format = MutableStateFlow<DocumentFormat?>(null)
    val unavailable = tracker.unavailable

    private class Request(val query: String, val mode: SearchMode, val format: DocumentFormat?, val all: List<PwpDocument>)

    private val results = combine(query.debounce(200), mode, format, documents.observeAll()) { q, m, f, all ->
        Request(q, m, f, all)
    }.mapLatest { r ->
        when {
            r.query.isBlank() -> emptyList()
            r.mode == SearchMode.FILENAME ->
                filterAndSort(r.all, r.query, r.format, SortOrder(SortField.DATE, ascending = false))
            else -> documents.searchContent(r.query).filter { r.format == null || it.format == r.format }
        }
    }

    val state: StateFlow<SearchUiState> = combine(query, mode, format, results, history.observeRecent()) { q, m, f, res, recent ->
        SearchUiState(q, m, f, res, recent)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SearchUiState())

    fun setQuery(value: String) { query.value = value }
    fun setMode(value: SearchMode) { mode.value = value }
    fun setFormat(value: DocumentFormat?) { format.value = value }
    fun remember() { viewModelScope.launch { history.add(query.value) } }
    fun clearHistory() { viewModelScope.launch { history.clear() } }
    fun toggleFavorite(d: PwpDocument) { viewModelScope.launch { documents.setFavorite(d.uri, !d.isFavorite) } }
}
