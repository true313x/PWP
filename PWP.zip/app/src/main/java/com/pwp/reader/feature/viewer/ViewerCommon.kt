package com.pwp.reader.feature.viewer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.pwp.reader.R
import com.pwp.reader.core.common.ViewerError
import com.pwp.reader.core.common.bidiIsolated
import com.pwp.reader.core.common.formatFileSize
import com.pwp.reader.core.common.formatLastOpened
import com.pwp.reader.core.designsystem.ErrorState
import com.pwp.reader.core.designsystem.PwpIcons
import com.pwp.reader.core.designsystem.labelRes
import com.pwp.reader.core.designsystem.viewerErrorMessage
import com.pwp.reader.domain.model.DocumentFormat
import com.pwp.reader.domain.model.PwpDocument

@Composable
fun ViewerTopBar(
    title: String,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    actions: @Composable RowScope.() -> Unit = {},
) {
    Surface(modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.97f), tonalElevation = 0.dp, shadowElevation = 1.dp) {
        Row(
            Modifier.statusBarsPadding().height(56.dp).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) { Icon(PwpIcons.Back, contentDescription = stringResource(R.string.cd_back)) }
            Text(
                bidiIsolated(title),
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f).padding(horizontal = 4.dp),
            )
            actions()
        }
    }
}

@Composable
fun ViewerErrorScreen(error: ViewerError, onBack: () -> Unit, onRemove: (() -> Unit)?) {
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        ErrorState(
            message = viewerErrorMessage(error),
            modifier = Modifier.statusBarsPadding(),
            primaryLabel = if (onRemove != null) stringResource(R.string.remove_from_history) else null,
            onPrimary = onRemove,
            secondaryLabel = stringResource(R.string.action_back),
            onSecondary = onBack,
        )
    }
}

@Composable
fun DocumentInfoDialog(document: PwpDocument?, fallbackName: String, onDismiss: () -> Unit) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_ok)) } },
        title = { Text(stringResource(R.string.document_info)) },
        text = {
            Column {
                InfoRow(stringResource(R.string.info_name), bidiIsolated(document?.name ?: fallbackName))
                if (document != null) {
                    InfoRow(stringResource(R.string.info_format), stringResource(document.format.labelRes()))
                    document.sizeBytes?.let { InfoRow(stringResource(R.string.info_size), formatFileSize(context, it)) }
                    document.pageCount?.let {
                        val label = if (document.format == DocumentFormat.PPTX) R.string.info_slides else R.string.info_pages
                        InfoRow(stringResource(label), it.toString())
                    }
                    InfoRow(stringResource(R.string.info_last_opened), formatLastOpened(context, document.lastOpenedAt))
                }
            }
        },
    )
}

@Composable
private fun InfoRow(label: String, value: String) {
    Column(Modifier.padding(vertical = 6.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}
