package com.pwp.reader.core.common

import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserException
import org.xmlpull.v1.XmlPullParserFactory
import java.io.IOException
import java.io.InputStream
import java.util.zip.ZipFile

/** Tiny DOM node. Parts are read one element at a time so that large documents stay streamable. */
class XNode(val name: String, val attrs: Map<String, String>) {
    val children = ArrayList<XNode>()
    var text: String = ""

    fun attr(key: String): String? = attrs[key]
    fun child(name: String): XNode? = children.firstOrNull { it.name == name }
    fun childrenNamed(name: String): List<XNode> = children.filter { it.name == name }

    fun descendant(name: String): XNode? {
        for (c in children) {
            if (c.name == name) return c
            c.descendant(name)?.let { return it }
        }
        return null
    }
}

object Xml {
    private const val MAX_DEPTH = 256

    fun parser(input: InputStream): XmlPullParser = try {
        XmlPullParserFactory.newInstance().newPullParser().apply {
            // Names keep their prefix ("w:p"); DTDs and external entities are never resolved.
            setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            setInput(input, null)
        }
    } catch (e: XmlPullParserException) {
        throw IOException("Malformed XML", e)
    }

    /** Reads the element the parser is positioned on (START_TAG) up to and including its END_TAG. */
    fun readNode(p: XmlPullParser, depth: Int = 0): XNode {
        if (depth > MAX_DEPTH) throw IOException("XML nested too deeply")
        try {
            val attrs = HashMap<String, String>(p.attributeCount)
            for (i in 0 until p.attributeCount) attrs[p.getAttributeName(i)] = p.getAttributeValue(i)
            val node = XNode(p.name, attrs)
            var text: StringBuilder? = null
            while (true) {
                when (p.next()) {
                    XmlPullParser.START_TAG -> node.children += readNode(p, depth + 1)
                    XmlPullParser.TEXT -> (text ?: StringBuilder().also { text = it }).append(p.text)
                    XmlPullParser.END_TAG, XmlPullParser.END_DOCUMENT -> {
                        node.text = text?.toString().orEmpty()
                        return node
                    }
                }
            }
        } catch (e: XmlPullParserException) {
            throw IOException("Malformed XML", e)
        }
    }

    fun readRoot(input: InputStream): XNode {
        val p = parser(input)
        try {
            var e = p.eventType
            while (e != XmlPullParser.START_TAG && e != XmlPullParser.END_DOCUMENT) e = p.next()
            if (e == XmlPullParser.END_DOCUMENT) throw IOException("Empty XML part")
        } catch (e: XmlPullParserException) {
            throw IOException("Malformed XML", e)
        }
        return readNode(p)
    }
}

data class Relationship(val id: String, val type: String, val target: String, val external: Boolean)

/** Helpers for Open Packaging Convention (DOCX / PPTX) archives. */
object Opc {
    const val MAX_XML_BYTES = 48L * 1024 * 1024

    fun readXml(zip: ZipFile, path: String): XNode? {
        val entry = zip.getEntry(path) ?: return null
        return zip.getInputStream(entry).use { Xml.readRoot(LimitedInputStream(it, MAX_XML_BYTES)) }
    }

    fun relsPathFor(partPath: String): String {
        val slash = partPath.lastIndexOf('/')
        val dir = if (slash >= 0) partPath.substring(0, slash + 1) else ""
        return "${dir}_rels/${partPath.substring(slash + 1)}.rels"
    }

    fun readRelationships(zip: ZipFile, partPath: String): Map<String, Relationship> {
        val root = readXml(zip, relsPathFor(partPath)) ?: return emptyMap()
        val out = LinkedHashMap<String, Relationship>()
        for (n in root.childrenNamed("Relationship")) {
            val id = n.attr("Id") ?: continue
            val target = n.attr("Target") ?: continue
            out[id] = Relationship(id, n.attr("Type").orEmpty(), target, n.attr("TargetMode") == "External")
        }
        return out
    }

    /** Resolves a relationship [target] relative to the part that declares it. */
    fun resolve(partPath: String, target: String): String {
        if (target.startsWith("/")) return target.trimStart('/')
        val segments = ArrayList<String>()
        val baseDir = partPath.substringBeforeLast('/', "")
        if (baseDir.isNotEmpty()) segments.addAll(baseDir.split('/'))
        for (s in target.split('/')) {
            when (s) {
                "", "." -> Unit
                ".." -> if (segments.isNotEmpty()) segments.removeAt(segments.lastIndex)
                else -> segments.add(s)
            }
        }
        return segments.joinToString("/")
    }
}
