package com.pwp.reader.feature.pdf

import android.net.Uri
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pwp.reader.core.common.PasswordRequiredException
import com.pwp.reader.core.common.ViewerError
import com.pwp.reader.core.common.toViewerError
import com.pwp.reader.core.storage.AvailabilityTracker
import com.pwp.reader.core.storage.DocumentAccess
import com.pwp.reader.domain.model.Bookmark
import com.pwp.reader.domain.model.PdfZoomMode
import com.pwp.reader.domain.model.PwpDocument
import com.pwp.reader.domain.model.UserSettings
import com.pwp.reader.domain.repository.DocumentRepository
import com.pwp.reader.domain.repository.SettingsRepository
import com.pwp.reader.domain.usecase.SaveReadingPosition
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

sealed interface PdfUiState {
    data object Loading : PdfUiState
    data class NeedsPassword(val wrong: Boolean, val supported: Boolean) : PdfUiState
    data class Failed(val error: ViewerError) : PdfUiState
    data class Ready(val session: PdfSession, val startPage: Int, val startOffset: Int, val zoomMode: PdfZoomMode) : PdfUiState
}

@HiltViewModel
class PdfViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val access: DocumentAccess,
    private val documents: DocumentRepository,
    private val settingsRepository: SettingsRepository,
    private val saveReadingPosition: SaveReadingPosition,
    private val tracker: AvailabilityTracker,
) : ViewModel() {

    val uri: String = savedStateHandle.get<String>("uri").orEmpty()

    private val _state = MutableStateFlow<PdfUiState>(PdfUiState.Loading)
    val state: StateFlow<PdfUiState> = _state

    val document: StateFlow<PwpDocument?> = (if (uri.isEmpty()) emptyFlow<PwpDocument?>() else documents.observe(uri))
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    val bookmarks: StateFlow<List<Bookmark>> = (if (uri.isEmpty()) emptyFlow<List<Bookmark>>() else documents.observeBookmarks(uri))
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val settings: StateFlow<UserSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UserSettings())

    init { load() }

    fun load(password: String? = null) {
        if (uri.isEmpty()) {
            _state.value = PdfUiState.Failed(ViewerError.NOT_FOUND)
            return
        }
        (_state.value as? PdfUiState.Ready)?.session?.close()
        _state.value = PdfUiState.Loading
        viewModelScope.launch {
            try {
                val session = PdfSession.open(access, Uri.parse(uri), password)
                val settings = settingsRepository.settings.first()
                documents.touch(uri)
                documents.updatePageCount(uri, session.pageCount)
                tracker.markAvailable(uri)
                val saved = documents.get(uri)
                val remembered = settings.rememberPosition && saved != null
                _state.value = PdfUiState.Ready(
                    session = session,
                    startPage = if (remembered) saved!!.lastPosition.coerceIn(0, (session.pageCount - 1).coerceAtLeast(0)) else 0,
                    startOffset = if (remembered) saved!!.lastOffset else 0,
                    zoomMode = settings.pdfZoomMode,
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: PasswordRequiredException) {
                _state.value = PdfUiState.NeedsPassword(e.wrong, e.supported)
            } catch (t: Throwable) {
                val error = t.toViewerError()
                if (error == ViewerError.NOT_FOUND || error == ViewerError.PERMISSION) tracker.markUnavailable(uri)
                _state.value = PdfUiState.Failed(error)
            }
        }
    }

    fun savePosition(page: Int, offset: Int) {
        viewModelScope.launch { withContext(NonCancellable) { saveReadingPosition(uri, page, offset) } }
    }

    fun toggleBookmark(page: Int) {
        viewModelScope.launch {
            val existing = bookmarks.value.firstOrNull { it.position == page }
            if (existing != null) documents.removeBookmark(existing.id) else documents.addBookmark(uri, page, null)
        }
    }

    fun removeBookmark(id: Long) { viewModelScope.launch { documents.removeBookmark(id) } }

    suspend fun removeFromHistory() = documents.remove(uri)

    override fun onCleared() {
        (_state.value as? PdfUiState.Ready)?.session?.close()
    }
}
