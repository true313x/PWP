package com.pwp.reader.core.di

import android.content.Context
import androidx.room.Room
import com.pwp.reader.core.storage.DocumentAccess
import com.pwp.reader.core.storage.DocumentSource
import com.pwp.reader.data.database.BookmarkDao
import com.pwp.reader.data.database.DocumentDao
import com.pwp.reader.data.database.PwpDatabase
import com.pwp.reader.data.database.SearchHistoryDao
import com.pwp.reader.data.database.TextIndexDao
import com.pwp.reader.data.repository.DocumentRepositoryImpl
import com.pwp.reader.data.repository.SearchHistoryRepositoryImpl
import com.pwp.reader.data.repository.SettingsRepositoryImpl
import com.pwp.reader.domain.repository.DocumentRepository
import com.pwp.reader.domain.repository.SearchHistoryRepository
import com.pwp.reader.domain.repository.SettingsRepository
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides @Singleton
    fun database(@ApplicationContext context: Context): PwpDatabase =
        Room.databaseBuilder(context, PwpDatabase::class.java, "pwp.db").build()

    @Provides fun documentDao(db: PwpDatabase): DocumentDao = db.documentDao()
    @Provides fun bookmarkDao(db: PwpDatabase): BookmarkDao = db.bookmarkDao()
    @Provides fun textIndexDao(db: PwpDatabase): TextIndexDao = db.textIndexDao()
    @Provides fun searchHistoryDao(db: PwpDatabase): SearchHistoryDao = db.searchHistoryDao()
}

@Module
@InstallIn(SingletonComponent::class)
abstract class BindingModule {
    @Binds @Singleton abstract fun documents(impl: DocumentRepositoryImpl): DocumentRepository
    @Binds @Singleton abstract fun settings(impl: SettingsRepositoryImpl): SettingsRepository
    @Binds @Singleton abstract fun searchHistory(impl: SearchHistoryRepositoryImpl): SearchHistoryRepository
    @Binds @Singleton abstract fun source(impl: DocumentAccess): DocumentSource
}
