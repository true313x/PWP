package com.pwp.reader.core.common

import android.app.Activity
import android.content.ClipData
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.text.BidiFormatter

tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/** Shares the original document through its content URI (read access granted to the receiver). */
fun Context.shareDocument(uri: String, mimeType: String, title: String) {
    runCatching {
        val parsed = Uri.parse(uri)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, parsed)
            clipData = ClipData.newRawUri(title, parsed)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, title))
    }
}

/** Opens http(s), mailto and tel links only; any other scheme found in a document is ignored. */
fun Context.openExternalLink(url: String): Boolean {
    val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return false
    if (uri.scheme?.lowercase() !in setOf("http", "https", "mailto", "tel")) return false
    return runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)); true }.getOrDefault(false)
}

/** True when the user disabled animations system-wide (animator duration scale 0). */
@Composable
fun rememberReducedMotion(): Boolean {
    val context = LocalContext.current
    return remember {
        Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    }
}

/** Wraps mixed-direction text (e.g. Arabic filename + Latin extension) so it renders in the right order. */
@Composable
fun bidiIsolated(text: String): String {
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    return remember(text, rtl) { BidiFormatter.getInstance(rtl).unicodeWrap(text) }
}
