package com.pwp.reader.core.designsystem

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp
import com.pwp.reader.R
import com.pwp.reader.domain.model.AccentColor
import com.pwp.reader.domain.model.DocumentFormat

/** 4dp spacing grid. */
object Spacing {
    val xs = 4.dp
    val sm = 8.dp
    val md = 12.dp
    val lg = 16.dp
    val xl = 24.dp
    val xxl = 32.dp
    val screenHorizontal = 20.dp
}

val PwpShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun PwpTheme(darkTheme: Boolean, accent: AccentColor, content: @Composable () -> Unit) {
    val scheme = remember(darkTheme, accent) { if (darkTheme) darkScheme(accent) else lightScheme(accent) }
    MaterialTheme(colorScheme = scheme, typography = PwpTypography, shapes = PwpShapes, content = content)
}

@Composable
fun isDarkSurface(): Boolean = MaterialTheme.colorScheme.background.luminance() < 0.5f

/** Restrained, recognisable file-type accents. */
@Composable
fun DocumentFormat.accent(): Color {
    val dark = isDarkSurface()
    return when (this) {
        DocumentFormat.PDF -> if (dark) Color(0xFFFF6B5E) else Color(0xFFE5483D)
        DocumentFormat.DOCX -> if (dark) Color(0xFF6EA3FF) else Color(0xFF2B6CD9)
        DocumentFormat.PPTX -> if (dark) Color(0xFFFF9A55) else Color(0xFFE8742A)
    }
}

fun DocumentFormat.labelRes(): Int = when (this) {
    DocumentFormat.PDF -> R.string.format_pdf
    DocumentFormat.DOCX -> R.string.format_word
    DocumentFormat.PPTX -> R.string.format_powerpoint
}
