package com.pwp.reader.feature.files

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pwp.reader.core.storage.AvailabilityTracker
import com.pwp.reader.domain.model.DocumentFormat
import com.pwp.reader.domain.model.PwpDocument
import com.pwp.reader.domain.model.SortField
import com.pwp.reader.domain.model.SortOrder
import com.pwp.reader.domain.model.ViewMode
import com.pwp.reader.domain.repository.DocumentRepository
import com.pwp.reader.domain.repository.SettingsRepository
import com.pwp.reader.domain.usecase.FilterAndSortDocuments
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class FilesCriteria(
    val query: String = "",
    val format: DocumentFormat? = null,
    val order: SortOrder = SortOrder(),
    val viewOverride: ViewMode? = null,
)

data class FilesUiState(
    val isLoading: Boolean = true,
    val isRefreshing: Boolean = false,
    val documents: List<PwpDocument> = emptyList(),
    val totalCount: Int = 0,
    val criteria: FilesCriteria = FilesCriteria(),
    val viewMode: ViewMode = ViewMode.LIST,
)

@HiltViewModel
class FilesViewModel @Inject constructor(
    private val documents: DocumentRepository,
    settings: SettingsRepository,
    private val tracker: AvailabilityTracker,
    private val filterAndSort: FilterAndSortDocuments,
) : ViewModel() {

    private val criteria = MutableStateFlow(FilesCriteria())
    private val refreshing = MutableStateFlow(false)
    val unavailable = tracker.unavailable

    val state: StateFlow<FilesUiState> =
        combine(documents.observeAll(), criteria, settings.settings, refreshing) { all, c, s, r ->
            FilesUiState(
                isLoading = false,
                isRefreshing = r,
                documents = filterAndSort(all, c.query, c.format, c.order),
                totalCount = all.size,
                criteria = c,
                viewMode = c.viewOverride ?: s.defaultViewMode,
            )
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), FilesUiState())

    init { refresh() }

    fun setQuery(query: String) = criteria.update { it.copy(query = query) }
    fun setFormat(format: DocumentFormat?) = criteria.update { it.copy(format = format) }
    fun setViewMode(mode: ViewMode) = criteria.update { it.copy(viewOverride = mode) }

    fun setSortField(field: SortField) = criteria.update {
        if (it.order.field == field) it else it.copy(order = SortOrder(field, ascending = field == SortField.NAME || field == SortField.TYPE))
    }

    fun reverseOrder() = criteria.update { it.copy(order = it.order.copy(ascending = !it.order.ascending)) }

    /** Re-checks that every history entry can still be opened. */
    fun refresh() {
        viewModelScope.launch {
            refreshing.value = true
            tracker.check(documents.observeAll().first().map { it.uri })
            refreshing.value = false
        }
    }

    fun toggleFavorite(d: PwpDocument) { viewModelScope.launch { documents.setFavorite(d.uri, !d.isFavorite) } }
    suspend fun remove(d: PwpDocument) = documents.remove(d.uri)
}
