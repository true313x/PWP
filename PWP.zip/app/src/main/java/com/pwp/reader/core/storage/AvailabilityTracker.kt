package com.pwp.reader.core.storage

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/** Remembers which history entries can no longer be opened (moved, deleted, access revoked). */
@Singleton
class AvailabilityTracker @Inject constructor(private val access: DocumentAccess) {
    private val _unavailable = MutableStateFlow<Set<String>>(emptySet())
    val unavailable: StateFlow<Set<String>> = _unavailable

    suspend fun check(uris: Collection<String>) {
        val checked = uris.take(300)
        val bad = withContext(Dispatchers.IO) {
            checked.filterNot { access.isAccessible(Uri.parse(it)) }.toSet()
        }
        _unavailable.value = (_unavailable.value - checked.toSet()) + bad
    }

    fun markUnavailable(uri: String) { _unavailable.value = _unavailable.value + uri }
    fun markAvailable(uri: String) { _unavailable.value = _unavailable.value - uri }
}
