package com.pwp.reader.data.repository

import com.pwp.reader.data.database.SearchHistoryDao
import com.pwp.reader.data.database.SearchHistoryEntity
import com.pwp.reader.domain.repository.SearchHistoryRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SearchHistoryRepositoryImpl @Inject constructor(private val dao: SearchHistoryDao) : SearchHistoryRepository {
    override fun observeRecent(): Flow<List<String>> = dao.observeRecent()

    override suspend fun add(query: String) {
        val term = query.trim()
        if (term.length >= 2) dao.upsert(SearchHistoryEntity(term, System.currentTimeMillis()))
    }

    override suspend fun clear() = dao.clear()
}
