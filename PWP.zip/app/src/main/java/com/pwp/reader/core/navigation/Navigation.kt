package com.pwp.reader.core.navigation

import android.net.Uri
import androidx.annotation.StringRes
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.pwp.reader.R
import com.pwp.reader.core.common.rememberReducedMotion
import com.pwp.reader.core.designsystem.PwpIcons
import com.pwp.reader.domain.model.DocumentFormat
import com.pwp.reader.feature.favorites.FavoritesScreen
import com.pwp.reader.feature.files.FilesScreen
import com.pwp.reader.feature.home.HomeScreen
import com.pwp.reader.feature.pdf.PdfReaderScreen
import com.pwp.reader.feature.powerpoint.PowerPointReaderScreen
import com.pwp.reader.feature.recent.RecentScreen
import com.pwp.reader.feature.search.SearchScreen
import com.pwp.reader.feature.settings.SettingsScreen
import com.pwp.reader.feature.word.WordReaderScreen

object Routes {
    const val HOME = "home"
    const val FILES = "files"
    const val FAVORITES = "favorites"
    const val RECENT = "recent"
    const val SETTINGS = "settings"
    const val SEARCH = "search"
    const val VIEWER = "viewer/{format}?uri={uri}"

    fun viewer(format: DocumentFormat, uri: String) = "viewer/${format.name}?uri=${Uri.encode(uri)}"
}

enum class TopLevelDestination(val route: String, @StringRes val label: Int, val icon: ImageVector) {
    HOME(Routes.HOME, R.string.nav_home, PwpIcons.Home),
    FILES(Routes.FILES, R.string.nav_files, PwpIcons.Files),
    FAVORITES(Routes.FAVORITES, R.string.nav_favorites, PwpIcons.Favorite),
    RECENT(Routes.RECENT, R.string.nav_recent, PwpIcons.Recent),
    SETTINGS(Routes.SETTINGS, R.string.nav_settings, PwpIcons.Settings),
}

/** Switches tab while saving and restoring each tab's own state. */
fun NavController.navigateTopLevel(destination: TopLevelDestination) {
    navigate(destination.route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun PwpNavigationBar(
    currentRoute: String?,
    onNavigate: (TopLevelDestination) -> Unit,
    modifier: Modifier = Modifier,
) {
    val divider = MaterialTheme.colorScheme.outlineVariant
    NavigationBar(
        modifier = modifier.drawBehind { drawLine(divider, androidx.compose.ui.geometry.Offset(0f, 0f), androidx.compose.ui.geometry.Offset(size.width, 0f), 1f) },
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
    ) {
        TopLevelDestination.entries.forEach { d ->
            NavigationBarItem(
                selected = currentRoute == d.route,
                onClick = { onNavigate(d) },
                icon = { Icon(d.icon, contentDescription = null) },
                label = { Text(stringResource(d.label), maxLines = 1) },
                alwaysShowLabel = true,
            )
        }
    }
}

@Composable
fun PwpNavigationRail(
    currentRoute: String?,
    onNavigate: (TopLevelDestination) -> Unit,
    modifier: Modifier = Modifier,
) {
    NavigationRail(modifier = modifier.fillMaxHeight(), containerColor = MaterialTheme.colorScheme.surface) {
        Spacer(Modifier.weight(1f))
        TopLevelDestination.entries.forEach { d ->
            NavigationRailItem(
                selected = currentRoute == d.route,
                onClick = { onNavigate(d) },
                icon = { Icon(d.icon, contentDescription = null) },
                label = { Text(stringResource(d.label), maxLines = 1) },
                alwaysShowLabel = true,
            )
        }
        Spacer(Modifier.weight(1f))
    }
}

@Composable
fun PwpNavHost(navController: NavHostController, modifier: Modifier = Modifier) {
    val reduceMotion = rememberReducedMotion()
    val openDocument: (DocumentFormat, String) -> Unit = { format, uri ->
        navController.navigate(Routes.viewer(format, uri))
    }
    val toTab: (TopLevelDestination) -> Unit = navController::navigateTopLevel

    NavHost(
        navController = navController,
        startDestination = Routes.HOME,
        modifier = modifier,
        enterTransition = { if (reduceMotion) EnterTransition.None else fadeIn(tween(220)) },
        exitTransition = { if (reduceMotion) ExitTransition.None else fadeOut(tween(160)) },
        popEnterTransition = { if (reduceMotion) EnterTransition.None else fadeIn(tween(220)) },
        popExitTransition = { if (reduceMotion) ExitTransition.None else fadeOut(tween(160)) },
    ) {
        composable(Routes.HOME) {
            HomeScreen(
                onOpenDocument = openDocument,
                onOpenSearch = { navController.navigate(Routes.SEARCH) },
                onOpenSettings = { toTab(TopLevelDestination.SETTINGS) },
                onBrowseFiles = { toTab(TopLevelDestination.FILES) },
                onSeeAllRecent = { toTab(TopLevelDestination.RECENT) },
            )
        }
        composable(Routes.FILES) { FilesScreen(onOpenDocument = openDocument, onOpenSearch = { navController.navigate(Routes.SEARCH) }) }
        composable(Routes.FAVORITES) { FavoritesScreen(onOpenDocument = openDocument) }
        composable(Routes.RECENT) { RecentScreen(onOpenDocument = openDocument) }
        composable(Routes.SETTINGS) { SettingsScreen() }
        composable(Routes.SEARCH) {
            SearchScreen(onBack = { navController.popBackStack() }, onOpenDocument = openDocument)
        }
        composable(
            route = Routes.VIEWER,
            arguments = listOf(
                navArgument("format") { type = NavType.StringType },
                navArgument("uri") { type = NavType.StringType; nullable = true },
            ),
            enterTransition = { if (reduceMotion) EnterTransition.None else slideInVertically(tween(260)) { it / 14 } + fadeIn(tween(240)) },
            popExitTransition = { if (reduceMotion) ExitTransition.None else slideOutVertically(tween(220)) { it / 14 } + fadeOut(tween(200)) },
        ) { entry ->
            val format = entry.arguments?.getString("format")?.let { name -> DocumentFormat.entries.firstOrNull { it.name == name } }
            val back: () -> Unit = { navController.popBackStack() }
            when (format) {
                DocumentFormat.PDF -> PdfReaderScreen(onBack = back)
                DocumentFormat.DOCX -> WordReaderScreen(onBack = back)
                DocumentFormat.PPTX -> PowerPointReaderScreen(onBack = back)
                null -> LaunchedEffect(Unit) { navController.popBackStack() }
            }
        }
    }
}
