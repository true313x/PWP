package com.pwp.reader.core.designsystem

import android.app.Activity
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.pwp.reader.R
import com.pwp.reader.core.common.ViewerError
import com.pwp.reader.core.common.bidiIsolated
import com.pwp.reader.core.common.findActivity
import com.pwp.reader.core.common.formatFileSize
import com.pwp.reader.core.common.formatLastOpened
import com.pwp.reader.domain.model.DocumentFormat
import com.pwp.reader.domain.model.PwpDocument
import com.pwp.reader.domain.model.ViewMode

val LocalSnackbarHostState = staticCompositionLocalOf<SnackbarHostState> { error("SnackbarHostState not provided") }

private val FavoriteAmber = Color(0xFFF5B301)

/** Top-level screen frame: status-bar inset, themed background and a readable max width on tablets. */
@Composable
fun PwpScreen(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Box(
        modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding(),
        contentAlignment = Alignment.TopCenter,
    ) {
        Column(Modifier.widthIn(max = 840.dp).fillMaxSize(), content = content)
    }
}

@Composable
fun ScreenTitle(text: String, modifier: Modifier = Modifier, actions: @Composable () -> Unit = {}) {
    Row(
        modifier.fillMaxWidth().padding(start = Spacing.screenHorizontal, end = Spacing.sm, top = Spacing.lg, bottom = Spacing.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.weight(1f))
        actions()
    }
}

@Composable
fun SectionHeader(text: String, modifier: Modifier = Modifier, trailing: @Composable () -> Unit = {}) {
    Row(modifier.fillMaxWidth().padding(top = Spacing.sm), verticalAlignment = Alignment.CenterVertically) {
        Text(text, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.weight(1f))
        trailing()
    }
}

@Composable
fun FileTypeBadge(format: DocumentFormat, modifier: Modifier = Modifier, size: Dp = 44.dp) {
    val accent = format.accent()
    Box(
        modifier.size(size).clip(RoundedCornerShape(size * 0.28f)).background(accent.copy(alpha = 0.14f)),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            format.extension.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            color = accent,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
        )
    }
}

@Composable
fun PwpLogo(modifier: Modifier = Modifier, size: Dp = 40.dp) {
    Box(
        modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.26f))
            .background(Brush.linearGradient(listOf(Color(0xFF66B0FF), Color(0xFF3E7EF2))))
            .semantics { contentDescription = "PWP" },
    ) {
        Image(
            painter = painterResource(R.drawable.ic_launcher_foreground),
            contentDescription = null,
            modifier = Modifier.fillMaxSize().graphicsLayer(scaleX = 1.55f, scaleY = 1.55f),
        )
    }
}

@Composable
fun DocIllustration(modifier: Modifier = Modifier) {
    val primary = MaterialTheme.colorScheme.primary
    val surface = MaterialTheme.colorScheme.surface
    val outline = MaterialTheme.colorScheme.outlineVariant
    Canvas(modifier.size(168.dp)) {
        val w = size.width
        val corner = CornerRadius(w * 0.07f)
        rotate(-9f) {
            drawRoundRect(primary.copy(alpha = 0.10f), Offset(w * 0.18f, w * 0.14f), Size(w * 0.52f, w * 0.68f), corner)
        }
        rotate(7f) {
            drawRoundRect(primary.copy(alpha = 0.18f), Offset(w * 0.30f, w * 0.16f), Size(w * 0.52f, w * 0.68f), corner)
        }
        val left = w * 0.24f
        val top = w * 0.12f
        drawRoundRect(surface, Offset(left, top), Size(w * 0.52f, w * 0.72f), corner)
        drawRoundRect(outline, Offset(left, top), Size(w * 0.52f, w * 0.72f), corner, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f))
        drawRoundRect(primary, Offset(left + w * 0.06f, top + w * 0.08f), Size(w * 0.20f, w * 0.045f), CornerRadius(w * 0.02f))
        for (i in 0..3) {
            val lw = if (i == 3) 0.20f else 0.40f
            drawRoundRect(outline, Offset(left + w * 0.06f, top + w * (0.20f + i * 0.095f)), Size(w * lw, w * 0.032f), CornerRadius(w * 0.016f))
        }
    }
}

@Composable
fun EmptyState(
    title: String,
    body: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
) {
    Column(
        modifier.fillMaxWidth().padding(horizontal = Spacing.xl, vertical = Spacing.xxl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(Spacing.sm),
    ) {
        DocIllustration()
        Spacer(Modifier.height(Spacing.sm))
        Text(title, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onBackground)
        Text(body, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (actionLabel != null && onAction != null) {
            Spacer(Modifier.height(Spacing.md))
            Button(onClick = onAction) { Text(actionLabel) }
        }
    }
}

@Composable
fun LoadingState(modifier: Modifier = Modifier) {
    val label = stringResource(R.string.loading)
    Box(modifier.fillMaxSize().semantics { contentDescription = label }, contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
    }
}

@Composable
fun viewerErrorMessage(error: ViewerError): String = stringResource(
    when (error) {
        ViewerError.NOT_FOUND -> R.string.error_not_found
        ViewerError.PERMISSION -> R.string.error_permission
        ViewerError.CORRUPT -> R.string.error_corrupt
        ViewerError.TOO_LARGE -> R.string.error_too_large
        ViewerError.UNSUPPORTED -> R.string.error_unsupported
        ViewerError.GENERIC -> R.string.error_generic
    },
)

@Composable
fun ErrorState(
    message: String,
    modifier: Modifier = Modifier,
    primaryLabel: String? = null,
    onPrimary: (() -> Unit)? = null,
    secondaryLabel: String? = null,
    onSecondary: (() -> Unit)? = null,
) {
    Column(
        modifier.fillMaxSize().padding(Spacing.xl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier.size(64.dp).clip(CircleShape).background(MaterialTheme.colorScheme.errorContainer),
            contentAlignment = Alignment.Center,
        ) {
            Icon(PwpIcons.Error, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(32.dp))
        }
        Spacer(Modifier.height(Spacing.lg))
        Text(stringResource(R.string.error_title), style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Spacer(Modifier.height(Spacing.sm))
        Text(message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        Spacer(Modifier.height(Spacing.xl))
        Row(horizontalArrangement = Arrangement.spacedBy(Spacing.md)) {
            if (secondaryLabel != null && onSecondary != null) OutlinedButton(onClick = onSecondary) { Text(secondaryLabel) }
            if (primaryLabel != null && onPrimary != null) Button(onClick = onPrimary) { Text(primaryLabel) }
        }
    }
}

@Composable
fun PwpSearchField(
    value: String,
    onValueChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier,
    onSearch: () -> Unit = {},
) {
    TextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.fillMaxWidth(),
        singleLine = true,
        placeholder = { Text(hint, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        leadingIcon = { Icon(PwpIcons.Search, contentDescription = null) },
        trailingIcon = {
            if (value.isNotEmpty()) {
                IconButton(onClick = { onValueChange("") }) {
                    Icon(PwpIcons.Close, contentDescription = stringResource(R.string.search_clear))
                }
            }
        },
        shape = RoundedCornerShape(16.dp),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        colors = TextFieldDefaults.colors(
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            disabledIndicatorColor = Color.Transparent,
            focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
        ),
    )
}

/** Hides the system bars while [enabled]; they come back on disposal. */
@Composable
fun FullscreenEffect(enabled: Boolean) {
    val view = LocalView.current
    DisposableEffect(enabled) {
        val window = (view.context.findActivity() as? Activity)?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        if (enabled) {
            controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller?.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller?.show(WindowInsetsCompat.Type.systemBars())
        }
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }
}

@Composable
fun documentMeta(d: PwpDocument): String {
    val context = LocalContext.current
    val formatLabel = stringResource(d.format.labelRes())
    val pages = d.pageCount?.let {
        stringResource(if (d.format == DocumentFormat.PPTX) R.string.meta_slides else R.string.meta_pages, it)
    }
    val size = d.sizeBytes?.let { formatFileSize(context, it) }
    val opened = remember(d.lastOpenedAt) { formatLastOpened(context, d.lastOpenedAt) }
    return listOfNotNull(formatLabel, size, pages, opened).joinToString(" · ")
}

@Composable
private fun FavoriteButton(favorite: Boolean, onClick: () -> Unit) {
    IconButton(onClick = onClick) {
        Icon(
            if (favorite) PwpIcons.Favorite else PwpIcons.FavoriteOutline,
            contentDescription = stringResource(if (favorite) R.string.favorite_remove else R.string.favorite_add),
            tint = if (favorite) FavoriteAmber else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun DocumentRow(
    document: PwpDocument,
    unavailable: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onRemove: (() -> Unit)?,
    modifier: Modifier = Modifier,
) {
    val scheme = MaterialTheme.colorScheme
    var menuOpen by remember { mutableStateOf(false) }
    Surface(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = scheme.surface,
        border = BorderStroke(1.dp, scheme.outlineVariant),
    ) {
        Row(
            Modifier.padding(start = Spacing.md, top = 10.dp, bottom = 10.dp, end = Spacing.xs),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            FileTypeBadge(document.format, Modifier.alpha(if (unavailable) 0.5f else 1f))
            Spacer(Modifier.width(Spacing.md))
            Column(Modifier.weight(1f)) {
                Text(bidiIsolated(document.name), style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(documentMeta(document), style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (unavailable) {
                    Text(stringResource(R.string.file_unavailable), style = MaterialTheme.typography.labelSmall, color = scheme.error)
                }
            }
            FavoriteButton(document.isFavorite, onToggleFavorite)
            if (onRemove != null) {
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(PwpIcons.More, contentDescription = stringResource(R.string.more_options))
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.remove_from_history)) },
                            leadingIcon = { Icon(PwpIcons.Delete, contentDescription = null) },
                            onClick = { menuOpen = false; onRemove() },
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DocumentCard(
    document: PwpDocument,
    unavailable: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier,
    onRemove: (() -> Unit)? = null,
) {
    val scheme = MaterialTheme.colorScheme
    var menuOpen by remember { mutableStateOf(false) }
    Surface(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = scheme.surface,
        border = BorderStroke(1.dp, scheme.outlineVariant),
    ) {
        Column(Modifier.padding(Spacing.md)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                FileTypeBadge(document.format, Modifier.alpha(if (unavailable) 0.5f else 1f), size = 52.dp)
                Spacer(Modifier.weight(1f))
                FavoriteButton(document.isFavorite, onToggleFavorite)
                if (onRemove != null) {
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(PwpIcons.More, contentDescription = stringResource(R.string.more_options))
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.remove_from_history)) },
                                leadingIcon = { Icon(PwpIcons.Delete, contentDescription = null) },
                                onClick = { menuOpen = false; onRemove() },
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(Spacing.sm))
            Text(bidiIsolated(document.name), style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(documentMeta(document), style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (unavailable) {
                Text(stringResource(R.string.file_unavailable), style = MaterialTheme.typography.labelSmall, color = scheme.error)
            }
        }
    }
}

@Composable
fun DocumentCollection(
    documents: List<PwpDocument>,
    viewMode: ViewMode,
    unavailable: Set<String>,
    onOpen: (PwpDocument) -> Unit,
    onToggleFavorite: (PwpDocument) -> Unit,
    onRemove: (PwpDocument) -> Unit,
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(horizontal = Spacing.screenHorizontal, vertical = Spacing.sm),
) {
    if (viewMode == ViewMode.GRID) {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(168.dp),
            modifier = modifier,
            contentPadding = contentPadding,
            horizontalArrangement = Arrangement.spacedBy(Spacing.md),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            gridItems(documents, key = { it.uri }) { d ->
                DocumentCard(d, d.uri in unavailable, { onOpen(d) }, { onToggleFavorite(d) }, onRemove = { onRemove(d) })
            }
        }
    } else {
        LazyColumn(modifier = modifier, contentPadding = contentPadding, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(documents, key = { it.uri }) { d ->
                DocumentRow(d, d.uri in unavailable, { onOpen(d) }, { onToggleFavorite(d) }, { onRemove(d) })
            }
        }
    }
}
