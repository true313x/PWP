package com.pwp.reader.app

import android.app.Application
import com.pwp.reader.core.storage.DocumentAccess
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class PwpApplication : Application() {
    @Inject lateinit var documentAccess: DocumentAccess

    override fun onCreate() {
        super.onCreate()
        // Temporary copies of documents never outlive a process.
        Thread { documentAccess.cleanTempFiles() }.start()
    }
}
