package com.pwp.reader.app

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.windowsizeclass.WindowSizeClass
import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.pwp.reader.core.designsystem.LocalSnackbarHostState
import com.pwp.reader.core.navigation.PwpNavHost
import com.pwp.reader.core.navigation.PwpNavigationBar
import com.pwp.reader.core.navigation.PwpNavigationRail
import com.pwp.reader.core.navigation.Routes
import com.pwp.reader.core.navigation.TopLevelDestination
import com.pwp.reader.core.navigation.navigateTopLevel
import com.pwp.reader.feature.viewer.rememberDocumentLauncher

@Composable
fun PwpApp(windowSizeClass: WindowSizeClass, incomingUri: Uri?, onIncomingConsumed: () -> Unit) {
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val entry by navController.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val showNavigation = TopLevelDestination.entries.any { it.route == route }
    val compact = windowSizeClass.widthSizeClass == WindowWidthSizeClass.Compact

    CompositionLocalProvider(LocalSnackbarHostState provides snackbarHostState) {
        val launcher = rememberDocumentLauncher { format, uri -> navController.navigate(Routes.viewer(format, uri)) }
        LaunchedEffect(incomingUri) {
            if (incomingUri != null) {
                launcher.openUri(incomingUri.toString())
                onIncomingConsumed()
            }
        }
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                if (showNavigation && compact) {
                    PwpNavigationBar(currentRoute = route, onNavigate = navController::navigateTopLevel)
                }
            },
            contentWindowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp),
            containerColor = MaterialTheme.colorScheme.background,
        ) { padding ->
            Row(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(padding)) {
                if (showNavigation && !compact) {
                    PwpNavigationRail(currentRoute = route, onNavigate = navController::navigateTopLevel)
                }
                PwpNavHost(navController, Modifier.weight(1f).fillMaxHeight())
            }
        }
    }
}
