@file:OptIn(ExperimentalMaterial3Api::class)

package com.pwp.reader.feature.search

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pwp.reader.R
import com.pwp.reader.core.common.bidiIsolated
import com.pwp.reader.core.designsystem.DocumentRow
import com.pwp.reader.core.designsystem.EmptyState
import com.pwp.reader.core.designsystem.PwpIcons
import com.pwp.reader.core.designsystem.PwpScreen
import com.pwp.reader.core.designsystem.PwpSearchField
import com.pwp.reader.core.designsystem.labelRes
import com.pwp.reader.domain.model.DocumentFormat

@Composable
fun SearchScreen(
    onBack: () -> Unit,
    onOpenDocument: (DocumentFormat, String) -> Unit,
    viewModel: SearchViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val unavailable by viewModel.unavailable.collectAsStateWithLifecycle()
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }

    PwpScreen {
        Row(Modifier.padding(start = 4.dp, end = 20.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(PwpIcons.Back, contentDescription = stringResource(R.string.cd_back)) }
            PwpSearchField(
                value = state.query,
                onValueChange = viewModel::setQuery,
                hint = stringResource(
                    if (state.mode == SearchMode.FILENAME) R.string.search_hint_filename else R.string.search_hint_content,
                ),
                modifier = Modifier.focusRequester(focus),
                onSearch = viewModel::remember,
            )
        }

        val modes = listOf(SearchMode.FILENAME to R.string.search_mode_filename, SearchMode.CONTENT to R.string.search_mode_content)
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp)) {
            modes.forEachIndexed { index, (mode, label) ->
                SegmentedButton(
                    selected = state.mode == mode,
                    onClick = { viewModel.setMode(mode) },
                    shape = SegmentedButtonDefaults.itemShape(index, modes.size),
                ) { Text(stringResource(label)) }
            }
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FilterChip(state.format == null, { viewModel.setFormat(null) }, { Text(stringResource(R.string.filter_all)) })
            DocumentFormat.entries.forEach { f ->
                FilterChip(state.format == f, { viewModel.setFormat(f) }, { Text(stringResource(f.labelRes())) })
            }
        }
        if (state.mode == SearchMode.CONTENT) {
            Text(
                stringResource(R.string.search_content_note),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
            )
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                state.query.isBlank() -> IdleContent(
                    recent = state.recentSearches,
                    onPick = viewModel::setQuery,
                    onClear = viewModel::clearHistory,
                )
                state.results.isEmpty() -> EmptyState(
                    title = stringResource(R.string.search_no_results),
                    body = stringResource(R.string.search_no_results_body),
                )
                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(state.results, key = { it.uri }) { d ->
                        DocumentRow(
                            document = d,
                            unavailable = d.uri in unavailable,
                            onClick = { viewModel.remember(); onOpenDocument(d.format, d.uri) },
                            onToggleFavorite = { viewModel.toggleFavorite(d) },
                            onRemove = null,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun IdleContent(recent: List<String>, onPick: (String) -> Unit, onClear: () -> Unit) {
    if (recent.isEmpty()) {
        Text(
            stringResource(R.string.search_idle_body),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(20.dp),
        )
        return
    }
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.search_recent), style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
            TextButton(onClick = onClear) { Text(stringResource(R.string.search_clear_recent)) }
        }
        recent.forEach { term ->
            Row(
                Modifier.fillMaxWidth().clickable { onPick(term) }.padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Icon(PwpIcons.Recent, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(bidiIsolated(term), style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}
