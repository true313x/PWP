package com.pwp.reader.feature.word

sealed interface DocBlock

data class DocRun(
    val text: String,
    val bold: Boolean,
    val italic: Boolean,
    val underline: Boolean,
    val strike: Boolean,
    val color: Int?,
    /** Size relative to the document's default size (1f = default); null when not specified. */
    val sizeRatio: Float?,
    val link: String?,
)

data class DocImage(val path: String, val widthDp: Float?, val heightDp: Float?, val alt: String?)

sealed interface DocSegment {
    data class Text(val runs: List<DocRun>) : DocSegment
    data class Image(val image: DocImage) : DocSegment
}

enum class ParaAlign { START, CENTER, END, JUSTIFY }

data class DocParagraph(
    val segments: List<DocSegment>,
    val headingLevel: Int = 0,
    val align: ParaAlign = ParaAlign.START,
    val rtl: Boolean = false,
    val listLabel: String? = null,
    val listLevel: Int = 0,
) : DocBlock {
    val plainText: String by lazy(LazyThreadSafetyMode.NONE) {
        segments.filterIsInstance<DocSegment.Text>().joinToString("") { seg -> seg.runs.joinToString("") { it.text } }
    }
}

data class DocCell(val blocks: List<DocBlock>, val span: Int, val fill: Int?)
data class DocRow(val cells: List<DocCell>, val header: Boolean)
data class DocTable(val rows: List<DocRow>, val rtl: Boolean) : DocBlock
data class DocBreak(val page: Boolean) : DocBlock

/** [partial] is true when some elements (text boxes, charts, unsupported images, ...) could not be shown. */
data class DocxDocument(val blocks: List<DocBlock>, val partial: Boolean) {
    fun plainText(limit: Int = 1_000_000): String {
        val sb = StringBuilder()
        for (b in blocks) {
            sb.append(b.searchableText()).append('\n')
            if (sb.length >= limit) break
        }
        return sb.toString()
    }
}

fun DocBlock.searchableText(): String = when (this) {
    is DocParagraph -> plainText
    is DocTable -> rows.joinToString("\n") { row ->
        row.cells.joinToString("\t") { cell -> cell.blocks.joinToString("\n") { it.searchableText() } }
    }
    is DocBreak -> ""
}
