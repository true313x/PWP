package com.pwp.reader.core.common

import java.io.FilterInputStream
import java.io.InputStream

/** Aborts with [DocumentTooLargeException] when more than [limit] bytes are read (zip-bomb guard). */
class LimitedInputStream(delegate: InputStream, limit: Long) : FilterInputStream(delegate) {
    private var remaining = limit

    override fun read(): Int {
        val r = super.read()
        if (r >= 0 && --remaining < 0) throw DocumentTooLargeException()
        return r
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        val n = super.read(b, off, len)
        if (n > 0) {
            remaining -= n
            if (remaining < 0) throw DocumentTooLargeException()
        }
        return n
    }
}
