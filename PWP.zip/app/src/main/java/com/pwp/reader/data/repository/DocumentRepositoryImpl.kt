package com.pwp.reader.data.repository

import com.pwp.reader.core.common.TextNormalizer
import com.pwp.reader.core.storage.DocumentSource
import com.pwp.reader.data.database.BookmarkDao
import com.pwp.reader.data.database.BookmarkEntity
import com.pwp.reader.data.database.DocumentDao
import com.pwp.reader.data.database.DocumentEntity
import com.pwp.reader.data.database.DocumentTextEntity
import com.pwp.reader.data.database.TextIndexDao
import com.pwp.reader.data.database.toDomain
import com.pwp.reader.domain.model.Bookmark
import com.pwp.reader.domain.model.DocumentFormat
import com.pwp.reader.domain.model.OpenResult
import com.pwp.reader.domain.model.PwpDocument
import com.pwp.reader.domain.repository.DocumentRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DocumentRepositoryImpl @Inject constructor(
    private val documents: DocumentDao,
    private val bookmarks: BookmarkDao,
    private val textIndex: TextIndexDao,
    private val source: DocumentSource,
) : DocumentRepository {

    override fun observeAll(): Flow<List<PwpDocument>> =
        documents.observeAll().map { list -> list.map { it.toDomain() } }

    override fun observe(uri: String): Flow<PwpDocument?> = documents.observe(uri).map { it?.toDomain() }

    override suspend fun get(uri: String): PwpDocument? = documents.get(uri)?.toDomain()

    override suspend fun open(uri: String): OpenResult = withContext(Dispatchers.IO) {
        val info = source.query(uri) ?: return@withContext OpenResult.Unavailable
        val format = DocumentFormat.detect(info.name, info.mimeType) ?: return@withContext OpenResult.Unsupported
        source.persistAccess(uri)
        val now = System.currentTimeMillis()
        val base = documents.get(uri)
            ?: DocumentEntity(uri = uri, displayName = info.name, format = format.name, lastOpenedAt = now)
        val entity = base.copy(
            displayName = info.name,
            format = format.name,
            sizeBytes = info.sizeBytes,
            lastOpenedAt = now,
        )
        documents.upsert(entity)
        OpenResult.Opened(entity.toDomain())
    }

    override suspend fun touch(uri: String) = documents.touch(uri, System.currentTimeMillis())
    override suspend fun setFavorite(uri: String, favorite: Boolean) = documents.setFavorite(uri, favorite)
    override suspend fun savePosition(uri: String, position: Int, offset: Int) =
        documents.setPosition(uri, position.coerceAtLeast(0), offset.coerceAtLeast(0))

    override suspend fun updatePageCount(uri: String, count: Int) = documents.setPageCount(uri, count)

    override suspend fun remove(uri: String) {
        documents.delete(uri)
        source.releaseAccess(uri)
    }

    override suspend fun clearAll() {
        val all = documents.allUris()
        documents.deleteAll()
        all.forEach { source.releaseAccess(it) }
    }

    override fun observeBookmarks(uri: String): Flow<List<Bookmark>> =
        bookmarks.observe(uri).map { list -> list.map { it.toDomain() } }

    override suspend fun addBookmark(uri: String, position: Int, label: String?) {
        bookmarks.upsert(BookmarkEntity(documentUri = uri, position = position, label = label, createdAt = System.currentTimeMillis()))
    }

    override suspend fun removeBookmark(id: Long) = bookmarks.delete(id)

    override suspend fun hasTextIndex(uri: String): Boolean = textIndex.has(uri)

    override suspend fun indexText(uri: String, text: String) {
        if (documents.get(uri) == null) return
        textIndex.upsert(DocumentTextEntity(uri, TextNormalizer.normalize(text.take(MAX_INDEXED_CHARS))))
    }

    override suspend fun searchContent(query: String): List<PwpDocument> {
        val q = TextNormalizer.normalize(query).trim()
        if (q.isEmpty()) return emptyList()
        val escaped = q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        return textIndex.search("%$escaped%").map { it.toDomain() }
    }

    private companion object {
        const val MAX_INDEXED_CHARS = 2_000_000
    }
}
