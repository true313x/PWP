package com.pwp.reader.feature.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pwp.reader.core.storage.AvailabilityTracker
import com.pwp.reader.domain.model.PwpDocument
import com.pwp.reader.domain.repository.DocumentRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeState(
    val isLoading: Boolean = true,
    val recent: List<PwpDocument> = emptyList(),
    val totalCount: Int = 0,
    val favoriteCount: Int = 0,
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val documents: DocumentRepository,
    tracker: AvailabilityTracker,
) : ViewModel() {

    val state: StateFlow<HomeState> = documents.observeAll()
        .map { all -> HomeState(false, all.take(RECENT_LIMIT), all.size, all.count { it.isFavorite }) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeState())

    val unavailable = tracker.unavailable

    init {
        viewModelScope.launch { tracker.check(documents.observeAll().first().take(RECENT_LIMIT).map { it.uri }) }
    }

    fun toggleFavorite(d: PwpDocument) {
        viewModelScope.launch { documents.setFavorite(d.uri, !d.isFavorite) }
    }

    suspend fun remove(d: PwpDocument) = documents.remove(d.uri)

    private companion object { const val RECENT_LIMIT = 6 }
}
