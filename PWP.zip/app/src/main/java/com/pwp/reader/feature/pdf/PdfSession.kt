package com.pwp.reader.feature.pdf

import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.LruCache
import com.pwp.reader.core.common.PasswordRequiredException
import com.pwp.reader.core.storage.DocumentAccess
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.roundToInt

/**
 * Wraps [PdfRenderer]. The renderer allows a single open page at a time, so access is serialised with a
 * mutex; rendering is lazy (only pages on screen), cancellable, and cached in a byte-bounded LRU.
 */
class PdfSession private constructor(
    private val pfd: ParcelFileDescriptor,
    private val renderer: PdfRenderer,
    private val tempFile: File?,
) : AutoCloseable {

    val pageCount: Int = renderer.pageCount

    private val mutex = Mutex()
    private val sizes = ConcurrentHashMap<Int, Pair<Int, Int>>()
    @Volatile private var closed = false

    private val cache = object : LruCache<String, Bitmap>(cacheBytes()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun cachedAspect(index: Int, rotation: Int): Float? {
        val (w, h) = sizes[index] ?: return null
        return if (rotation % 180 == 0) h.toFloat() / w else w.toFloat() / h
    }

    suspend fun aspect(index: Int, rotation: Int): Float {
        val (w, h) = pageSize(index)
        return if (rotation % 180 == 0) h.toFloat() / w else w.toFloat() / h
    }

    private suspend fun pageSize(index: Int): Pair<Int, Int> {
        sizes[index]?.let { return it }
        return withContext(Dispatchers.Default) {
            mutex.withLock {
                sizes[index] ?: run {
                    check(!closed) { "closed" }
                    val page = renderer.openPage(index)
                    try {
                        (page.width.coerceAtLeast(1) to page.height.coerceAtLeast(1)).also { sizes[index] = it }
                    } finally {
                        page.close()
                    }
                }
            }
        }
    }

    /** Renders page [index] at [widthPx] pixels wide, rotated by [rotation] degrees; null if closed. */
    suspend fun render(index: Int, widthPx: Int, rotation: Int): Bitmap? {
        val key = "$index@$widthPx@$rotation"
        cache.get(key)?.let { return it }
        return withContext(Dispatchers.Default) {
            mutex.withLock {
                ensureActive() // obsolete requests are dropped before any expensive work
                if (closed) return@withLock null
                cache.get(key)?.let { return@withLock it }
                val page = renderer.openPage(index)
                try {
                    val w = widthPx.coerceAtLeast(1)
                    val h = (w * page.height.toFloat() / page.width).roundToInt().coerceAtLeast(1)
                    var bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(android.graphics.Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    if (rotation != 0) {
                        val rotated = Bitmap.createBitmap(
                            bitmap, 0, 0, bitmap.width, bitmap.height,
                            Matrix().apply { postRotate(rotation.toFloat()) }, true,
                        )
                        bitmap.recycle()
                        bitmap = rotated
                    }
                    cache.put(key, bitmap)
                    bitmap
                } finally {
                    page.close()
                }
            }
        }
    }

    override fun close() {
        if (closed) return
        closed = true
        CoroutineScope(Dispatchers.Default + NonCancellable).launch {
            mutex.withLock {
                runCatching { renderer.close() }
                runCatching { pfd.close() }
                tempFile?.delete()
            }
        }
        cache.evictAll()
    }

    companion object {
        private const val MAX_PDF_BYTES = 512L * 1024 * 1024

        private fun cacheBytes(): Int =
            (Runtime.getRuntime().maxMemory() / 8).coerceAtMost(96L * 1024 * 1024).toInt()

        /**
         * Opens the PDF. Passwords are supported by the platform renderer on Android 15+ only; older versions
         * report [PasswordRequiredException] with supported = false.
         */
        suspend fun open(access: DocumentAccess, uri: Uri, password: String?): PdfSession = withContext(Dispatchers.IO) {
            var temp: File? = null
            var pfd = access.openFd(uri)
            try {
                val renderer = try {
                    createRenderer(pfd, password)
                } catch (e: PasswordRequiredException) {
                    throw e
                } catch (e: IOException) {
                    // Some providers hand out non-seekable descriptors: retry on a private copy.
                    runCatching { pfd.close() }
                    temp = access.copyToCache(uri, "pdf", MAX_PDF_BYTES)
                    pfd = ParcelFileDescriptor.open(temp, ParcelFileDescriptor.MODE_READ_ONLY)
                    createRenderer(pfd, password)
                }
                PdfSession(pfd, renderer, temp)
            } catch (t: Throwable) {
                runCatching { pfd.close() }
                temp?.delete()
                throw t
            }
        }

        private fun createRenderer(pfd: ParcelFileDescriptor, password: String?): PdfRenderer = try {
            if (Build.VERSION.SDK_INT >= 35) {
                val params = PdfRenderer.LoadParams.Builder().apply { if (password != null) setPassword(password) }.build()
                PdfRenderer(pfd, params)
            } else {
                PdfRenderer(pfd)
            }
        } catch (e: SecurityException) {
            throw PasswordRequiredException(wrong = password != null, supported = Build.VERSION.SDK_INT >= 35)
        }
    }
}
