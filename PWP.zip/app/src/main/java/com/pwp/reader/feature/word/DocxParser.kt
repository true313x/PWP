package com.pwp.reader.feature.word

import com.pwp.reader.core.common.LimitedInputStream
import com.pwp.reader.core.common.Opc
import com.pwp.reader.core.common.Relationship
import com.pwp.reader.core.common.XNode
import com.pwp.reader.core.common.Xml
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserException
import java.io.File
import java.io.IOException
import java.util.zip.ZipFile

private val DECODABLE_IMAGES = setOf("png", "jpg", "jpeg", "gif", "bmp", "webp")
private const val MAX_IMAGE_BYTES = 12L * 1024 * 1024
private const val MAX_IMAGES = 300
private const val EMU_PER_DP = 9525f

private fun onOff(node: XNode): Boolean {
    val v = node.attr("w:val")
    return v == null || (v != "0" && v != "false" && v != "off")
}

private fun parseHex(v: String): Int? {
    if (v.length != 6) return null
    return v.toIntOrNull(16)?.let { 0xFF000000.toInt() or it }
}

private data class RunProps(
    val bold: Boolean = false,
    val italic: Boolean = false,
    val underline: Boolean = false,
    val strike: Boolean = false,
    val color: Int? = null,
    val sizeHalfPts: Int? = null,
)

private class StyleDef(val id: String, val name: String?, val basedOn: String?, val pPr: XNode?, val rPr: XNode?)
private class ResolvedStyle(val run: RunProps, val align: String?, val heading: Int)

private class StyleSheet(private val byId: Map<String, StyleDef>, val defaultHalfPts: Int) {

    fun applyRPr(base: RunProps, rPr: XNode?, depth: Int = 0): RunProps {
        if (rPr == null) return base
        var p = base
        if (depth < 4) {
            rPr.child("w:rStyle")?.attr("w:val")?.let { sid -> byId[sid]?.let { p = applyRPr(p, it.rPr, depth + 1) } }
        }
        rPr.child("w:b")?.let { p = p.copy(bold = onOff(it)) }
        rPr.child("w:i")?.let { p = p.copy(italic = onOff(it)) }
        rPr.child("w:u")?.let { p = p.copy(underline = it.attr("w:val") != "none") }
        rPr.child("w:strike")?.let { p = p.copy(strike = onOff(it)) }
        rPr.child("w:color")?.attr("w:val")?.let { v -> parseHex(v)?.let { c -> p = p.copy(color = c) } }
        rPr.child("w:sz")?.attr("w:val")?.toIntOrNull()?.let { p = p.copy(sizeHalfPts = it) }
        return p
    }

    fun resolve(styleId: String?): ResolvedStyle {
        val chain = ArrayList<StyleDef>()
        var cur = styleId?.let { byId[it] }
        var guard = 0
        while (cur != null && guard++ < 12) {
            chain.add(0, cur)
            cur = cur.basedOn?.let { byId[it] }
        }
        var run = RunProps()
        var align: String? = null
        var heading = 0
        for (s in chain) {
            run = applyRPr(run, s.rPr)
            s.pPr?.child("w:jc")?.attr("w:val")?.let { align = it }
            headingLevel(s)?.let { heading = it }
            s.pPr?.child("w:outlineLvl")?.attr("w:val")?.toIntOrNull()?.takeIf { it in 0..5 }?.let { heading = it + 1 }
        }
        return ResolvedStyle(run, align, heading)
    }

    private fun headingLevel(s: StyleDef): Int? {
        val n = (s.name ?: s.id).lowercase()
        return when {
            n == "title" -> 1
            n.startsWith("heading ") -> n.removePrefix("heading ").trim().toIntOrNull()?.coerceIn(1, 6)
            else -> null
        }
    }

    companion object {
        fun load(zip: ZipFile): StyleSheet {
            val root = Opc.readXml(zip, "word/styles.xml") ?: return StyleSheet(emptyMap(), 22)
            val defaultSize = root.child("w:docDefaults")?.child("w:rPrDefault")?.child("w:rPr")
                ?.child("w:sz")?.attr("w:val")?.toIntOrNull() ?: 22
            val map = HashMap<String, StyleDef>()
            for (s in root.childrenNamed("w:style")) {
                val id = s.attr("w:styleId") ?: continue
                map[id] = StyleDef(id, s.child("w:name")?.attr("w:val"), s.child("w:basedOn")?.attr("w:val"), s.child("w:pPr"), s.child("w:rPr"))
            }
            return StyleSheet(map, defaultSize.coerceAtLeast(8))
        }
    }
}

private class LevelDef(val fmt: String, val text: String, val start: Int)

private class Numbering(private val nums: Map<Int, Int>, private val abstracts: Map<Int, List<LevelDef?>>) {

    fun label(numId: Int, ilvl: Int, counters: MutableMap<Int, IntArray>): String? {
        val levels = abstracts[nums[numId] ?: return null] ?: return null
        val l = ilvl.coerceIn(0, 8)
        val def = levels.getOrNull(l) ?: return null
        val c = counters.getOrPut(numId) { IntArray(9) { -1 } }
        c[l] = if (c[l] < 0) def.start else c[l] + 1
        for (d in l + 1..8) c[d] = -1
        if (def.fmt == "bullet") return BULLETS[l % BULLETS.size]
        if (def.fmt == "none") return ""
        var out = def.text.ifEmpty { "%${l + 1}." }
        for (k in 0..8) {
            val kd = levels.getOrNull(k)
            val v = if (c[k] < 0) (kd?.start ?: 1) else c[k]
            out = out.replace("%${k + 1}", formatCounter(kd?.fmt ?: "decimal", v))
        }
        return out
    }

    companion object {
        private val BULLETS = listOf("•", "◦", "▪")

        fun load(zip: ZipFile): Numbering {
            val root = Opc.readXml(zip, "word/numbering.xml") ?: return Numbering(emptyMap(), emptyMap())
            val abstracts = HashMap<Int, List<LevelDef?>>()
            for (a in root.childrenNamed("w:abstractNum")) {
                val id = a.attr("w:abstractNumId")?.toIntOrNull() ?: continue
                val levels = arrayOfNulls<LevelDef>(9)
                for (lvl in a.childrenNamed("w:lvl")) {
                    val i = lvl.attr("w:ilvl")?.toIntOrNull()?.takeIf { it in 0..8 } ?: continue
                    levels[i] = LevelDef(
                        fmt = lvl.child("w:numFmt")?.attr("w:val") ?: "decimal",
                        text = lvl.child("w:lvlText")?.attr("w:val") ?: "%${i + 1}.",
                        start = lvl.child("w:start")?.attr("w:val")?.toIntOrNull() ?: 1,
                    )
                }
                abstracts[id] = levels.toList()
            }
            val nums = HashMap<Int, Int>()
            for (n in root.childrenNamed("w:num")) {
                val id = n.attr("w:numId")?.toIntOrNull() ?: continue
                n.child("w:abstractNumId")?.attr("w:val")?.toIntOrNull()?.let { nums[id] = it }
            }
            return Numbering(nums, abstracts)
        }

        fun formatCounter(fmt: String, v: Int): String = when (fmt) {
            "decimalZero" -> "%02d".format(v)
            "lowerLetter" -> letters(v)
            "upperLetter" -> letters(v).uppercase()
            "lowerRoman" -> roman(v).lowercase()
            "upperRoman" -> roman(v)
            else -> v.toString()
        }

        private fun letters(v: Int): String {
            var n = v
            val sb = StringBuilder()
            while (n > 0) { n--; sb.append('a' + n % 26); n /= 26 }
            return sb.reverse().toString()
        }

        private fun roman(v: Int): String {
            val symbols = listOf(1000 to "M", 900 to "CM", 500 to "D", 400 to "CD", 100 to "C", 90 to "XC", 50 to "L", 40 to "XL", 10 to "X", 9 to "IX", 5 to "V", 4 to "IV", 1 to "I")
            var n = v.coerceIn(1, 3999)
            val sb = StringBuilder()
            for ((value, s) in symbols) while (n >= value) { sb.append(s); n -= value }
            return sb.toString()
        }
    }
}

/**
 * Real DOCX reader (no raw XML dump): headings, runs, lists, tables, hyperlinks, images and page/section breaks.
 * Unsupported content (text boxes, charts, headers/footers, footnotes, EMF/WMF images) is skipped and reported
 * through [DocxDocument.partial]. Nothing in the document is ever executed.
 */
class DocxParser private constructor(private val zip: ZipFile, private val imageDir: File) {
    private val rels: Map<String, Relationship> = Opc.readRelationships(zip, "word/document.xml")
    private val styles = StyleSheet.load(zip)
    private val numbering = Numbering.load(zip)
    private val counters = HashMap<Int, IntArray>()
    private val extracted = HashMap<String, String>()
    private var imageCount = 0
    private var skipped = 0
    private var truncated = false

    companion object {
        const val MAX_BLOCKS = 150_000
        fun parse(file: File, imageDir: File): DocxDocument = ZipFile(file).use { DocxParser(it, imageDir).run() }
    }

    private fun run(): DocxDocument {
        val entry = zip.getEntry("word/document.xml") ?: throw IOException("Not a Word document")
        val blocks = ArrayList<DocBlock>()
        zip.getInputStream(entry).use { raw ->
            val p = Xml.parser(LimitedInputStream(raw, Opc.MAX_XML_BYTES))
            try {
                var inBody = false
                loop@ while (true) {
                    when (p.next()) {
                        XmlPullParser.START_TAG -> when {
                            !inBody && p.name == "w:body" -> inBody = true
                            inBody -> {
                                parseBlock(Xml.readNode(p), blocks)
                                if (blocks.size > MAX_BLOCKS) { truncated = true; break@loop }
                            }
                        }
                        XmlPullParser.END_DOCUMENT -> break@loop
                    }
                }
            } catch (e: XmlPullParserException) {
                throw IOException("Malformed document", e)
            }
        }
        return DocxDocument(blocks, partial = truncated || skipped > 0)
    }

    private fun parseBlock(node: XNode, out: MutableList<DocBlock>) {
        when (node.name) {
            "w:p" -> parseParagraph(node, out)
            "w:tbl" -> out += parseTable(node)
            "w:sdt" -> node.child("w:sdtContent")?.children?.forEach { parseBlock(it, out) }
            "w:customXml", "w:ins", "w:smartTag" -> node.children.forEach { parseBlock(it, out) }
            "mc:AlternateContent" -> (node.child("mc:Choice") ?: node.child("mc:Fallback"))?.children?.forEach { parseBlock(it, out) }
        }
    }

    private inner class ParaBuilder {
        val segments = ArrayList<DocSegment>()
        val runs = ArrayList<DocRun>()
        var pageBreak = false

        fun flush() {
            if (runs.isNotEmpty()) { segments += DocSegment.Text(runs.toList()); runs.clear() }
        }
        fun addImage(image: DocImage) { flush(); segments += DocSegment.Image(image) }
    }

    private fun parseParagraph(node: XNode, out: MutableList<DocBlock>) {
        val pPr = node.child("w:pPr")
        val style = styles.resolve(pPr?.child("w:pStyle")?.attr("w:val"))
        val alignValue = pPr?.child("w:jc")?.attr("w:val") ?: style.align
        val align = when (alignValue) {
            "center" -> ParaAlign.CENTER
            "right", "end" -> ParaAlign.END
            "both", "distribute" -> ParaAlign.JUSTIFY
            else -> ParaAlign.START
        }
        val rtl = pPr?.child("w:bidi")?.let { onOff(it) } ?: false
        var heading = style.heading
        pPr?.child("w:outlineLvl")?.attr("w:val")?.toIntOrNull()?.takeIf { it in 0..5 }?.let { heading = it + 1 }

        if (pPr?.child("w:pageBreakBefore") != null) out += DocBreak(page = true)

        val numPr = pPr?.child("w:numPr")
        val numId = numPr?.child("w:numId")?.attr("w:val")?.toIntOrNull()
        val ilvl = numPr?.child("w:ilvl")?.attr("w:val")?.toIntOrNull() ?: 0
        val label = if (numId != null && numId != 0) numbering.label(numId, ilvl, counters) else null

        val builder = ParaBuilder()
        collectRuns(node, null, style.run, builder)
        builder.flush()

        out += DocParagraph(
            segments = builder.segments,
            headingLevel = heading,
            align = align,
            rtl = rtl,
            listLabel = label,
            listLevel = if (label != null) ilvl.coerceIn(0, 8) else 0,
        )
        if (pPr?.child("w:sectPr") != null) out += DocBreak(page = false)
        if (builder.pageBreak) out += DocBreak(page = true)
    }

    private fun collectRuns(parent: XNode, link: String?, base: RunProps, b: ParaBuilder) {
        for (c in parent.children) {
            when (c.name) {
                "w:r" -> parseRun(c, link, base, b)
                "w:hyperlink" -> {
                    val url = c.attr("r:id")?.let { rels[it] }?.takeIf { it.external }?.target
                    collectRuns(c, url ?: link, base, b)
                }
                "w:ins", "w:smartTag", "w:fldSimple", "w:sdt", "w:sdtContent", "w:customXml" -> collectRuns(c, link, base, b)
                "mc:AlternateContent" -> (c.child("mc:Choice") ?: c.child("mc:Fallback"))?.let { collectRuns(it, link, base, b) }
            }
        }
    }

    private fun parseRun(r: XNode, link: String?, base: RunProps, b: ParaBuilder) {
        val props = styles.applyRPr(base, r.child("w:rPr"))
        val sb = StringBuilder()
        fun flushText() {
            if (sb.isNotEmpty()) {
                b.runs += DocRun(
                    text = sb.toString(),
                    bold = props.bold,
                    italic = props.italic,
                    underline = props.underline,
                    strike = props.strike,
                    color = props.color,
                    sizeRatio = props.sizeHalfPts?.let { it.toFloat() / styles.defaultHalfPts },
                    link = link,
                )
                sb.clear()
            }
        }
        for (c in r.children) {
            when (c.name) {
                "w:t" -> sb.append(c.text)
                "w:tab" -> sb.append('\t')
                "w:br" -> if (c.attr("w:type") == "page") { flushText(); b.pageBreak = true } else sb.append('\n')
                "w:cr" -> sb.append('\n')
                "w:noBreakHyphen" -> sb.append('\u2011')
                "w:drawing", "w:pict" -> { flushText(); handleGraphic(c, b) }
                "w:object" -> skipped++
                "mc:AlternateContent" -> {
                    flushText()
                    (c.child("mc:Choice") ?: c.child("mc:Fallback"))?.children
                        ?.filter { it.name == "w:drawing" || it.name == "w:pict" }
                        ?.forEach { handleGraphic(it, b) }
                }
            }
        }
        flushText()
    }

    private fun handleGraphic(node: XNode, b: ParaBuilder) {
        if (node.descendant("w:txbxContent") != null) skipped++
        val relId = node.descendant("a:blip")?.attr("r:embed") ?: node.descendant("v:imagedata")?.attr("r:id")
        if (relId == null) {
            if (node.descendant("w:txbxContent") == null) skipped++ // chart, SmartArt or other drawing
            return
        }
        val extent = node.descendant("wp:extent")
        val widthDp = extent?.attr("cx")?.toFloatOrNull()?.div(EMU_PER_DP)
        val heightDp = extent?.attr("cy")?.toFloatOrNull()?.div(EMU_PER_DP)
        val alt = node.descendant("wp:docPr")?.attr("descr")?.takeIf { it.isNotBlank() }
        val path = extractImage(relId)
        if (path != null) b.addImage(DocImage(path, widthDp, heightDp, alt)) else skipped++
    }

    private fun extractImage(relId: String): String? {
        val rel = rels[relId] ?: return null
        if (rel.external) return null
        val zipPath = Opc.resolve("word/document.xml", rel.target)
        extracted[zipPath]?.let { return it }
        val ext = zipPath.substringAfterLast('.', "").lowercase()
        if (ext !in DECODABLE_IMAGES || imageCount >= MAX_IMAGES) return null
        val entry = zip.getEntry(zipPath) ?: return null
        if (entry.size > MAX_IMAGE_BYTES) return null
        imageDir.mkdirs()
        val target = File(imageDir, "img${imageCount++}.$ext")
        return try {
            zip.getInputStream(entry).use { ins ->
                LimitedInputStream(ins, MAX_IMAGE_BYTES).use { limited -> target.outputStream().use { limited.copyTo(it) } }
            }
            target.absolutePath.also { extracted[zipPath] = it }
        } catch (e: IOException) {
            target.delete()
            null
        }
    }

    private fun parseTable(tbl: XNode): DocTable {
        val rtl = tbl.child("w:tblPr")?.child("w:bidiVisual") != null
        val rows = tbl.childrenNamed("w:tr").map { tr ->
            val header = tr.child("w:trPr")?.child("w:tblHeader") != null
            val cells = tr.childrenNamed("w:tc").map { tc ->
                val tcPr = tc.child("w:tcPr")
                val span = tcPr?.child("w:gridSpan")?.attr("w:val")?.toIntOrNull()?.coerceIn(1, 32) ?: 1
                val fill = tcPr?.child("w:shd")?.attr("w:fill")?.let { parseHex(it) }
                val blocks = ArrayList<DocBlock>()
                tc.children.forEach { parseBlock(it, blocks) }
                DocCell(blocks, span, fill)
            }
            DocRow(cells, header)
        }
        return DocTable(rows, rtl)
    }
}
