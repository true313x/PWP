package com.pwp.reader.domain.repository

import com.pwp.reader.domain.model.Bookmark
import com.pwp.reader.domain.model.OpenResult
import com.pwp.reader.domain.model.PwpDocument
import com.pwp.reader.domain.model.UserSettings
import kotlinx.coroutines.flow.Flow

interface DocumentRepository {
    fun observeAll(): Flow<List<PwpDocument>>
    fun observe(uri: String): Flow<PwpDocument?>
    suspend fun get(uri: String): PwpDocument?

    /** Reads file metadata, keeps access across restarts and registers the document in history. */
    suspend fun open(uri: String): OpenResult
    suspend fun touch(uri: String)
    suspend fun setFavorite(uri: String, favorite: Boolean)
    suspend fun savePosition(uri: String, position: Int, offset: Int)
    suspend fun updatePageCount(uri: String, count: Int)
    suspend fun remove(uri: String)
    suspend fun clearAll()

    fun observeBookmarks(uri: String): Flow<List<Bookmark>>
    suspend fun addBookmark(uri: String, position: Int, label: String?)
    suspend fun removeBookmark(id: Long)

    suspend fun hasTextIndex(uri: String): Boolean
    suspend fun indexText(uri: String, text: String)
    suspend fun searchContent(query: String): List<PwpDocument>
}

interface SettingsRepository {
    val settings: Flow<UserSettings>
    suspend fun update(transform: (UserSettings) -> UserSettings)
}

interface SearchHistoryRepository {
    fun observeRecent(): Flow<List<String>>
    suspend fun add(query: String)
    suspend fun clear()
}
