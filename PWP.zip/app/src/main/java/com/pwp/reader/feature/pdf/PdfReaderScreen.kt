@file:OptIn(ExperimentalMaterial3Api::class, FlowPreview::class)

package com.pwp.reader.feature.pdf

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pwp.reader.R
import com.pwp.reader.core.common.rememberReducedMotion
import com.pwp.reader.core.common.shareDocument
import com.pwp.reader.core.designsystem.FullscreenEffect
import com.pwp.reader.core.designsystem.LoadingState
import com.pwp.reader.core.designsystem.PwpIcons
import com.pwp.reader.domain.model.DocumentFormat
import com.pwp.reader.domain.model.PdfZoomMode
import com.pwp.reader.domain.model.PwpDocument
import com.pwp.reader.feature.viewer.DocumentInfoDialog
import com.pwp.reader.feature.viewer.KeepScreenOnEffect
import com.pwp.reader.feature.viewer.ViewerErrorScreen
import com.pwp.reader.feature.viewer.ViewerTopBar
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.roundToInt

private const val FIT_WIDTH = 0
private const val FIT_PAGE = 1
private const val CUSTOM = 2
private const val MIN_ZOOM = 0.5f
private const val MAX_ZOOM = 3f
private const val MAX_RENDER_WIDTH = 2048
private const val DEFAULT_ASPECT = 1.414f

@Composable
fun PdfReaderScreen(onBack: () -> Unit, viewModel: PdfViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val document by viewModel.document.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val background = MaterialTheme.colorScheme.background

    when (val s = state) {
        PdfUiState.Loading -> Box(Modifier.fillMaxSize().background(background)) { LoadingState() }
        is PdfUiState.NeedsPassword -> {
            Box(Modifier.fillMaxSize().background(background))
            PasswordDialog(s, onSubmit = viewModel::load, onCancel = onBack)
        }
        is PdfUiState.Failed -> ViewerErrorScreen(
            error = s.error,
            onBack = onBack,
            onRemove = { scope.launch { viewModel.removeFromHistory(); onBack() } },
        )
        is PdfUiState.Ready -> PdfReader(s, document, viewModel, onBack)
    }
}

@Composable
private fun PasswordDialog(state: PdfUiState.NeedsPassword, onSubmit: (String) -> Unit, onCancel: () -> Unit) {
    var password by rememberSaveable { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(stringResource(R.string.pdf_password_title)) },
        text = {
            Column {
                Text(stringResource(if (state.supported) R.string.pdf_password_body else R.string.pdf_password_unsupported))
                if (state.supported) {
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        singleLine = true,
                        label = { Text(stringResource(R.string.pdf_password_hint)) },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        isError = state.wrong,
                        supportingText = if (state.wrong) ({ Text(stringResource(R.string.pdf_password_wrong)) }) else null,
                    )
                }
            }
        },
        confirmButton = {
            if (state.supported) {
                TextButton(onClick = { onSubmit(password) }, enabled = password.isNotEmpty()) { Text(stringResource(R.string.action_unlock)) }
            } else {
                TextButton(onClick = onCancel) { Text(stringResource(R.string.action_ok)) }
            }
        },
        dismissButton = if (state.supported) ({ TextButton(onClick = onCancel) { Text(stringResource(R.string.action_cancel)) } }) else null,
    )
}

@Composable
private fun PdfReader(ready: PdfUiState.Ready, document: PwpDocument?, viewModel: PdfViewModel, onBack: () -> Unit) {
    val session = ready.session
    val context = LocalContext.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val reduceMotion = rememberReducedMotion()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val bookmarks by viewModel.bookmarks.collectAsStateWithLifecycle()

    var fitMode by rememberSaveable { mutableIntStateOf(if (ready.zoomMode == PdfZoomMode.FIT_PAGE) FIT_PAGE else FIT_WIDTH) }
    var customZoom by rememberSaveable { mutableFloatStateOf(1f) }
    var rotation by rememberSaveable { mutableIntStateOf(0) }
    var chromeVisible by rememberSaveable { mutableStateOf(true) }
    var fullscreen by rememberSaveable { mutableStateOf(false) }
    var showGoTo by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    var showBookmarks by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var effectiveZoom by remember { mutableFloatStateOf(1f) }

    val listState = rememberLazyListState(
        initialFirstVisibleItemIndex = ready.startPage,
        initialFirstVisibleItemScrollOffset = ready.startOffset,
    )
    val currentPage by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            val mid = (info.viewportStartOffset + info.viewportEndOffset) / 2
            info.visibleItemsInfo.firstOrNull { it.offset + it.size > mid }?.index ?: listState.firstVisibleItemIndex
        }
    }
    var firstAspect by remember(rotation) { mutableStateOf(session.cachedAspect(0, rotation) ?: DEFAULT_ASPECT) }
    LaunchedEffect(rotation) { firstAspect = session.aspect(0, rotation) }

    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex to listState.firstVisibleItemScrollOffset }
            .debounce(600)
            .collect { (index, offset) -> viewModel.savePosition(index, offset) }
    }
    DisposableEffect(listState) {
        onDispose { viewModel.savePosition(listState.firstVisibleItemIndex, listState.firstVisibleItemScrollOffset) }
    }

    BackHandler(enabled = fullscreen) { fullscreen = false }
    FullscreenEffect(fullscreen)
    KeepScreenOnEffect(settings.keepScreenOn)

    fun goTo(page: Int) {
        val target = page.coerceIn(0, session.pageCount - 1)
        scope.launch { if (reduceMotion) listState.scrollToItem(target) else listState.animateScrollToItem(target) }
    }

    val statusTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceContainerHigh)) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val viewportW = constraints.maxWidth
            val viewportH = constraints.maxHeight
            val marginPx = with(density) { 16.dp.roundToPx() }
            val fitPageZoom = (viewportH.toFloat() / ((viewportW - 2 * marginPx).coerceAtLeast(1) * firstAspect)).coerceIn(0.35f, 1f)
            val zoom = when (fitMode) {
                FIT_WIDTH -> 1f
                FIT_PAGE -> fitPageZoom
                else -> customZoom
            }
            SideEffect { effectiveZoom = zoom }
            val pageWidthPx = ((viewportW - 2 * marginPx).coerceAtLeast(1) * zoom).roundToInt()
            val contentWidthPx = max(viewportW, pageWidthPx + 2 * marginPx)
            val pageWidthDp = with(density) { pageWidthPx.toDp() }

            val tapState = rememberUpdatedState(newValue = { chromeVisible = !chromeVisible })
            val doubleTapState = rememberUpdatedState(newValue = {
                if (zoom > 1.05f) { fitMode = FIT_WIDTH } else { customZoom = 2f; fitMode = CUSTOM }
            })

            Box(
                Modifier
                    .fillMaxSize()
                    .horizontalScroll(rememberScrollState())
                    .pinchToZoom { factor ->
                        customZoom = (zoom * factor).coerceIn(MIN_ZOOM, MAX_ZOOM)
                        fitMode = CUSTOM
                    }
                    .pointerInput(Unit) {
                        detectTapGestures(onTap = { tapState.value() }, onDoubleTap = { doubleTapState.value() })
                    },
            ) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.width(with(density) { contentWidthPx.toDp() }).fillMaxHeight(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    contentPadding = PaddingValues(top = statusTop + 64.dp, bottom = navBottom + 88.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(count = session.pageCount, key = { it }) { index ->
                        PdfPageItem(session, index, pageWidthPx, rotation, pageWidthDp)
                    }
                }
            }
        }

        val enter = if (reduceMotion) EnterTransition.None else fadeIn()
        val exit = if (reduceMotion) ExitTransition.None else fadeOut()

        AnimatedVisibility(chromeVisible, Modifier.align(Alignment.TopCenter), enter = enter, exit = exit) {
            val bookmarked = bookmarks.any { it.position == currentPage }
            ViewerTopBar(title = document?.name.orEmpty(), onBack = onBack) {
                IconButton(onClick = { viewModel.toggleBookmark(currentPage) }) {
                    Icon(
                        if (bookmarked) PwpIcons.Bookmark else PwpIcons.BookmarkOutline,
                        contentDescription = stringResource(if (bookmarked) R.string.bookmark_remove else R.string.bookmark_add),
                    )
                }
                IconButton(onClick = { fullscreen = !fullscreen }) {
                    Icon(
                        if (fullscreen) PwpIcons.FullscreenExit else PwpIcons.Fullscreen,
                        contentDescription = stringResource(if (fullscreen) R.string.exit_fullscreen else R.string.fullscreen),
                    )
                }
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(PwpIcons.More, contentDescription = stringResource(R.string.more_options))
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        MenuItem(R.string.go_to_page, PwpIcons.Search) { menuOpen = false; showGoTo = true }
                        MenuItem(R.string.bookmarks, PwpIcons.Bookmark) { menuOpen = false; showBookmarks = true }
                        MenuItem(R.string.fit_width, PwpIcons.FitPage) { menuOpen = false; fitMode = FIT_WIDTH }
                        MenuItem(R.string.fit_page, PwpIcons.FitPage) { menuOpen = false; fitMode = FIT_PAGE }
                        MenuItem(R.string.rotate, PwpIcons.Rotate) { menuOpen = false; rotation = (rotation + 90) % 360 }
                        MenuItem(R.string.print, PwpIcons.Print) { menuOpen = false; printPdf(context, viewModel.uri, document?.name ?: "PDF") }
                        MenuItem(R.string.share, PwpIcons.Share) {
                            menuOpen = false
                            context.shareDocument(viewModel.uri, DocumentFormat.PDF.mimeType, document?.name ?: "PDF")
                        }
                        MenuItem(R.string.document_info, PwpIcons.Info) { menuOpen = false; showInfo = true }
                    }
                }
            }
        }

        AnimatedVisibility(
            chromeVisible,
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp),
            enter = enter,
            exit = exit,
        ) {
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.97f),
                shadowElevation = 6.dp,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                Row(Modifier.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (settings.showPageControls) {
                        IconButton(onClick = { goTo(currentPage - 1) }, enabled = currentPage > 0) {
                            Icon(PwpIcons.ArrowUp, contentDescription = stringResource(R.string.previous_page))
                        }
                    }
                    TextButton(onClick = { showGoTo = true }) {
                        Text(stringResource(R.string.page_indicator, currentPage + 1, session.pageCount))
                    }
                    if (settings.showPageControls) {
                        IconButton(onClick = { goTo(currentPage + 1) }, enabled = currentPage < session.pageCount - 1) {
                            Icon(PwpIcons.ArrowDown, contentDescription = stringResource(R.string.next_page))
                        }
                    }
                    IconButton(onClick = { customZoom = (effectiveZoom / 1.25f).coerceAtLeast(MIN_ZOOM); fitMode = CUSTOM }) {
                        Icon(PwpIcons.ZoomOut, contentDescription = stringResource(R.string.zoom_out))
                    }
                    IconButton(onClick = { customZoom = (effectiveZoom * 1.25f).coerceAtMost(MAX_ZOOM); fitMode = CUSTOM }) {
                        Icon(PwpIcons.ZoomIn, contentDescription = stringResource(R.string.zoom_in))
                    }
                }
            }
        }
    }

    if (showGoTo) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showGoTo = false },
            title = { Text(stringResource(R.string.go_to_page)) },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { v -> text = v.filter { it.isDigit() }.take(6) },
                    singleLine = true,
                    label = { Text(stringResource(R.string.go_to_page_hint, session.pageCount)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
            },
            confirmButton = {
                TextButton(
                    enabled = text.toIntOrNull() != null,
                    onClick = { text.toIntOrNull()?.let { goTo(it - 1) }; showGoTo = false },
                ) { Text(stringResource(R.string.action_go)) }
            },
            dismissButton = { TextButton(onClick = { showGoTo = false }) { Text(stringResource(R.string.action_cancel)) } },
        )
    }
    if (showInfo) DocumentInfoDialog(document, "", onDismiss = { showInfo = false })
    if (showBookmarks) {
        ModalBottomSheet(onDismissRequest = { showBookmarks = false }, sheetState = rememberModalBottomSheetState()) {
            Column(Modifier.padding(bottom = 24.dp)) {
                Text(stringResource(R.string.bookmarks), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
                if (bookmarks.isEmpty()) {
                    Text(
                        stringResource(R.string.bookmarks_empty),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                    )
                }
                bookmarks.forEach { b ->
                    Row(Modifier.fillMaxWidth().padding(start = 24.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { showBookmarks = false; goTo(b.position) }, modifier = Modifier.weight(1f)) {
                            Text(stringResource(R.string.bookmark_page, b.position + 1), modifier = Modifier.fillMaxWidth())
                        }
                        IconButton(onClick = { viewModel.removeBookmark(b.id) }) {
                            Icon(PwpIcons.Delete, contentDescription = stringResource(R.string.bookmark_remove))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MenuItem(label: Int, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    DropdownMenuItem(
        text = { Text(stringResource(label)) },
        leadingIcon = { Icon(icon, contentDescription = null) },
        onClick = onClick,
    )
}

@Composable
private fun PdfPageItem(session: PdfSession, index: Int, pageWidthPx: Int, rotation: Int, pageWidthDp: Dp) {
    var aspect by remember(index, rotation) { mutableStateOf(session.cachedAspect(index, rotation)) }
    var bitmap by remember(index, rotation) { mutableStateOf<ImageBitmap?>(null) }
    val renderWidth = pageWidthPx.coerceIn(1, MAX_RENDER_WIDTH)

    // Cancelled automatically when the page scrolls away or the zoom changes; the previous bitmap stays visible meanwhile.
    LaunchedEffect(index, renderWidth, rotation) {
        if (aspect == null) aspect = session.aspect(index, rotation)
        session.render(index, renderWidth, rotation)?.let { bitmap = it.asImageBitmap() }
    }

    val description = stringResource(R.string.cd_pdf_page, index + 1)
    Box(
        Modifier
            .width(pageWidthDp)
            .aspectRatio(1f / (aspect ?: DEFAULT_ASPECT))
            .background(androidx.compose.ui.graphics.Color.White)
            .semantics { contentDescription = description },
    ) {
        bitmap?.let {
            Image(bitmap = it, contentDescription = null, contentScale = ContentScale.FillBounds, modifier = Modifier.fillMaxSize())
        }
    }
}

/** Two-finger pinch is intercepted before the list scroll sees it; single-finger gestures pass through. */
@Composable
private fun Modifier.pinchToZoom(onZoom: (Float) -> Unit): Modifier {
    val current by rememberUpdatedState(onZoom)
    return pointerInput(Unit) {
        awaitEachGesture {
            awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            do {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                if (event.changes.size >= 2) {
                    val change = event.calculateZoom()
                    if (change != 1f) {
                        current(change)
                        event.changes.forEach { it.consume() }
                    }
                }
            } while (event.changes.any { it.pressed })
        }
    }
}
