package com.pwp.reader.core.designsystem

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import com.pwp.reader.domain.model.AccentColor

private class AccentSpec(val light: Color, val dark: Color)

// Every light accent keeps >= 4.5:1 contrast with white text; every dark accent keeps >= 4.5:1 with near-black.
private fun AccentColor.spec(): AccentSpec = when (this) {
    AccentColor.INDIGO -> AccentSpec(Color(0xFF4B5BD6), Color(0xFF9AA8FF))
    AccentColor.BLUE -> AccentSpec(Color(0xFF1F6FEB), Color(0xFF7DB2FF))
    AccentColor.TEAL -> AccentSpec(Color(0xFF0E7C86), Color(0xFF5CD0D9))
    AccentColor.ROSE -> AccentSpec(Color(0xFFC2255C), Color(0xFFFF8AB0))
    AccentColor.ORANGE -> AccentSpec(Color(0xFFB85100), Color(0xFFFFB070))
}

fun AccentColor.swatch(dark: Boolean): Color = if (dark) spec().dark else spec().light

private fun onColorFor(background: Color): Color =
    if (background.luminance() > 0.25f) Color(0xFF0E0E10) else Color.White

internal fun lightScheme(accent: AccentColor): ColorScheme {
    val primary = accent.spec().light
    val container = lerp(Color.White, primary, 0.14f)
    return lightColorScheme(
        primary = primary,
        onPrimary = onColorFor(primary),
        primaryContainer = container,
        onPrimaryContainer = primary,
        secondary = primary,
        onSecondary = onColorFor(primary),
        secondaryContainer = container,
        onSecondaryContainer = primary,
        tertiary = primary,
        background = Color(0xFFF6F5F3),
        onBackground = Color(0xFF1C1C1E),
        surface = Color.White,
        onSurface = Color(0xFF1C1C1E),
        surfaceVariant = Color(0xFFEEEDEA),
        onSurfaceVariant = Color(0xFF6B6B72),
        surfaceContainerLowest = Color.White,
        surfaceContainerLow = Color(0xFFFBFAF9),
        surfaceContainer = Color(0xFFF3F2F0),
        surfaceContainerHigh = Color(0xFFEEEDEA),
        surfaceContainerHighest = Color(0xFFE8E7E4),
        outline = Color(0xFF8C8C94),
        outlineVariant = Color(0xFFE2E1DE),
        error = Color(0xFFB3261E),
        onError = Color.White,
        errorContainer = Color(0xFFFCE8E6),
        onErrorContainer = Color(0xFF8C1D18),
    )
}

internal fun darkScheme(accent: AccentColor): ColorScheme {
    val primary = accent.spec().dark
    val container = lerp(Color(0xFF1F1F23), primary, 0.22f)
    return darkColorScheme(
        primary = primary,
        onPrimary = onColorFor(primary),
        primaryContainer = container,
        onPrimaryContainer = primary,
        secondary = primary,
        onSecondary = onColorFor(primary),
        secondaryContainer = container,
        onSecondaryContainer = primary,
        tertiary = primary,
        background = Color(0xFF121214),
        onBackground = Color(0xFFF2F2F5),
        surface = Color(0xFF1A1A1D),
        onSurface = Color(0xFFF2F2F5),
        surfaceVariant = Color(0xFF26262B),
        onSurfaceVariant = Color(0xFFA3A3AB),
        surfaceContainerLowest = Color(0xFF0E0E10),
        surfaceContainerLow = Color(0xFF1A1A1D),
        surfaceContainer = Color(0xFF1F1F23),
        surfaceContainerHigh = Color(0xFF26262B),
        surfaceContainerHighest = Color(0xFF2D2D32),
        outline = Color(0xFF6E6E76),
        outlineVariant = Color(0xFF36363B),
        error = Color(0xFFFF8A80),
        onError = Color(0xFF3B0A06),
        errorContainer = Color(0xFF4A1612),
        onErrorContainer = Color(0xFFFFDAD6),
    )
}
