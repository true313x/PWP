@file:OptIn(ExperimentalMaterial3Api::class)

package com.pwp.reader.feature.powerpoint

import android.content.pm.ActivityInfo
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pwp.reader.R
import com.pwp.reader.core.common.findActivity
import com.pwp.reader.core.common.rememberReducedMotion
import com.pwp.reader.core.common.shareDocument
import com.pwp.reader.core.designsystem.FullscreenEffect
import com.pwp.reader.core.designsystem.LoadingState
import com.pwp.reader.core.designsystem.PwpIcons
import com.pwp.reader.domain.model.DocumentFormat
import com.pwp.reader.domain.model.PwpDocument
import com.pwp.reader.feature.viewer.DocumentInfoDialog
import com.pwp.reader.feature.viewer.KeepScreenOnEffect
import com.pwp.reader.feature.viewer.ViewerErrorScreen
import com.pwp.reader.feature.viewer.ViewerTopBar
import kotlinx.coroutines.launch
import kotlin.math.max

private sealed interface SlideResult {
    data object Loading : SlideResult
    data object Failed : SlideResult
    data class Loaded(val content: SlideContent) : SlideResult
}

@Composable
fun PowerPointReaderScreen(onBack: () -> Unit, viewModel: PptxViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val document by viewModel.document.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    when (val s = state) {
        PptxUiState.Loading -> Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) { LoadingState() }
        is PptxUiState.Failed -> ViewerErrorScreen(s.error, onBack) { scope.launch { viewModel.removeFromHistory(); onBack() } }
        is PptxUiState.Ready -> PptxReader(s, document, viewModel, onBack)
    }
}

@Composable
private fun PptxReader(ready: PptxUiState.Ready, document: PwpDocument?, viewModel: PptxViewModel, onBack: () -> Unit) {
    val pkg = ready.pkg
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val reduceMotion = rememberReducedMotion()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val partialSlides by viewModel.partialSlides.collectAsStateWithLifecycle()

    val pagerState = rememberPagerState(initialPage = ready.startSlide) { pkg.slideCount }
    var fullscreen by rememberSaveable { mutableStateOf(false) }
    var chromeVisible by rememberSaveable { mutableStateOf(true) }
    var showThumbs by rememberSaveable { mutableStateOf(ready.showThumbnails) }
    var zoomed by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    val current = pagerState.currentPage

    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.settledPage }.collect { viewModel.savePosition(it) }
    }
    LaunchedEffect(current) { zoomed = false }

    // Presentation mode: hide bars, and for landscape decks lock to landscape.
    val activity = context.findActivity()
    DisposableEffect(fullscreen) {
        if (fullscreen && pkg.size.width >= pkg.size.height) {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        onDispose { activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED }
    }
    BackHandler(enabled = fullscreen) { fullscreen = false }
    FullscreenEffect(fullscreen)
    KeepScreenOnEffect(settings.keepScreenOn)

    fun goTo(page: Int) {
        val target = page.coerceIn(0, pkg.slideCount - 1)
        scope.launch { if (reduceMotion) pagerState.scrollToPage(target) else pagerState.animateScrollToPage(target) }
    }

    val enter = if (reduceMotion) EnterTransition.None else fadeIn()
    val exit = if (reduceMotion) ExitTransition.None else fadeOut()
    val canvas = if (fullscreen) Color.Black else MaterialTheme.colorScheme.surfaceContainerHigh

    Box(Modifier.fillMaxSize().background(canvas)) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize(),
            pageSpacing = 16.dp,
            beyondViewportPageCount = 1,
            userScrollEnabled = !zoomed,
            key = { it },
        ) { page ->
            ZoomableBox(
                onTap = { chromeVisible = !chromeVisible },
                onZoomChange = { z -> if (pagerState.currentPage == page) zoomed = z },
            ) {
                BoxWithConstraints(Modifier.fillMaxSize().padding(horizontal = if (fullscreen) 0.dp else 12.dp), contentAlignment = Alignment.Center) {
                    val aspect = pkg.size.width / pkg.size.height
                    val slideWidth = minOf(maxWidth, maxHeight * aspect)
                    SlideLoader(viewModel, page, pkg.size, Modifier.width(slideWidth))
                }
            }
        }

        AnimatedVisibility(chromeVisible && !fullscreen, Modifier.align(Alignment.TopCenter), enter = enter, exit = exit) {
            ViewerTopBar(title = document?.name.orEmpty(), onBack = onBack) {
                IconButton(onClick = { showThumbs = !showThumbs }) {
                    Icon(PwpIcons.Grid, contentDescription = stringResource(R.string.slide_thumbnails_toggle))
                }
                IconButton(onClick = { fullscreen = true }) {
                    Icon(PwpIcons.Slides, contentDescription = stringResource(R.string.present))
                }
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(PwpIcons.More, contentDescription = stringResource(R.string.more_options))
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.share)) },
                            leadingIcon = { Icon(PwpIcons.Share, contentDescription = null) },
                            onClick = {
                                menuOpen = false
                                context.shareDocument(viewModel.uri, DocumentFormat.PPTX.mimeType, document?.name ?: "PPTX")
                            },
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.document_info)) },
                            leadingIcon = { Icon(PwpIcons.Info, contentDescription = null) },
                            onClick = { menuOpen = false; showInfo = true },
                        )
                    }
                }
            }
        }

        AnimatedVisibility(chromeVisible, Modifier.align(Alignment.BottomCenter), enter = enter, exit = exit) {
            Column(Modifier.navigationBarsPadding(), horizontalAlignment = Alignment.CenterHorizontally) {
                if (current in partialSlides) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                        shadowElevation = 2.dp,
                        modifier = Modifier.padding(bottom = 8.dp, start = 16.dp, end = 16.dp),
                    ) {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(PwpIcons.Info, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                stringResource(R.string.pptx_partial),
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(start = 8.dp),
                            )
                        }
                    }
                }
                Surface(
                    shape = RoundedCornerShape(28.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.97f),
                    shadowElevation = 6.dp,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.padding(bottom = 8.dp),
                ) {
                    Row(Modifier.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { goTo(current - 1) }, enabled = current > 0) {
                            Icon(PwpIcons.Previous, contentDescription = stringResource(R.string.previous_slide))
                        }
                        Text(
                            stringResource(R.string.page_indicator, current + 1, pkg.slideCount),
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.padding(horizontal = 8.dp),
                        )
                        IconButton(onClick = { goTo(current + 1) }, enabled = current < pkg.slideCount - 1) {
                            Icon(PwpIcons.Next, contentDescription = stringResource(R.string.next_slide))
                        }
                        if (fullscreen) {
                            IconButton(onClick = { fullscreen = false }) {
                                Icon(PwpIcons.FullscreenExit, contentDescription = stringResource(R.string.exit_fullscreen))
                            }
                        }
                    }
                }
                if (showThumbs && !fullscreen) {
                    ThumbnailStrip(viewModel, pkg, current, reduceMotion, onSelect = ::goTo)
                }
            }
        }
    }

    if (showInfo) DocumentInfoDialog(document, "", onDismiss = { showInfo = false })
}

@Composable
private fun SlideLoader(viewModel: PptxViewModel, index: Int, size: SlideSize, modifier: Modifier = Modifier) {
    val result by produceState<SlideResult>(SlideResult.Loading, index) {
        value = viewModel.slide(index)?.let { SlideResult.Loaded(it) } ?: SlideResult.Failed
    }
    val description = stringResource(R.string.cd_slide, index + 1)
    when (val r = result) {
        is SlideResult.Loaded -> Box(modifier.semantics { contentDescription = description }) {
            SlideView(r.content, size, viewModel::image, Modifier.fillMaxWidth())
        }
        else -> Box(
            modifier.then(Modifier.fillMaxWidth()).clip(RoundedCornerShape(4.dp)).background(MaterialTheme.colorScheme.surface),
            contentAlignment = Alignment.Center,
        ) {
            if (r == SlideResult.Failed) {
                Text(stringResource(R.string.error_corrupt), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(16.dp))
            }
        }
    }
}

@Composable
private fun ThumbnailStrip(viewModel: PptxViewModel, pkg: PptxPackage, current: Int, reduceMotion: Boolean, onSelect: (Int) -> Unit) {
    val listState = rememberLazyListState()
    LaunchedEffect(current) {
        val target = max(0, current - 1)
        if (reduceMotion) listState.scrollToItem(target) else listState.animateScrollToItem(target)
    }
    val primary = MaterialTheme.colorScheme.primary
    LazyRow(
        state = listState,
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface.copy(alpha = 0.97f)),
    ) {
        itemsIndexed(List(pkg.slideCount) { it }, key = { _, i -> i }) { _, i ->
            val selected = i == current
            Box(
                Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (selected) primary else Color.Transparent)
                    .padding(2.dp)
                    .clickable { onSelect(i) },
            ) {
                SlideLoader(viewModel, i, pkg.size, Modifier.width(112.dp))
            }
        }
    }
}

/** Pinch / double-tap zoom for a slide. Single-finger drags only pan while zoomed, so the pager keeps swiping at 1x. */
@Composable
private fun ZoomableBox(onTap: () -> Unit, onZoomChange: (Boolean) -> Unit, content: @Composable BoxScope.() -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    val reportZoom by rememberUpdatedState(onZoomChange)
    val tap by rememberUpdatedState(onTap)
    val isZoomed = scale > 1.01f
    LaunchedEffect(isZoomed) { reportZoom(isZoomed) }

    Box(
        Modifier
            .fillMaxSize()
            .clipToBounds()
            .onSizeChanged { box = it }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    do {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        val multi = event.changes.size >= 2
                        if (multi || scale > 1.01f) {
                            val zoomChange = if (multi) event.calculateZoom() else 1f
                            val pan = event.calculatePan()
                            val newScale = (scale * zoomChange).coerceIn(1f, 5f)
                            val maxX = box.width * (newScale - 1f) / 2f
                            val maxY = box.height * (newScale - 1f) / 2f
                            offset = if (newScale <= 1.01f) Offset.Zero
                            else Offset((offset.x + pan.x).coerceIn(-maxX, maxX), (offset.y + pan.y).coerceIn(-maxY, maxY))
                            scale = newScale
                            event.changes.forEach { it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { tap() },
                    onDoubleTap = { if (scale > 1.01f) { scale = 1f; offset = Offset.Zero } else { scale = 2.5f } },
                )
            }
            .graphicsLayer { scaleX = scale; scaleY = scale; translationX = offset.x; translationY = offset.y },
        content = content,
    )
}
