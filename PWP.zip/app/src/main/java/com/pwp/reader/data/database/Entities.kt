package com.pwp.reader.data.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.pwp.reader.domain.model.Bookmark
import com.pwp.reader.domain.model.DocumentFormat
import com.pwp.reader.domain.model.PwpDocument

@Entity(tableName = "documents")
data class DocumentEntity(
    @PrimaryKey val uri: String,
    val displayName: String,
    val format: String,
    val sizeBytes: Long? = null,
    val pageCount: Int? = null,
    val lastOpenedAt: Long,
    val isFavorite: Boolean = false,
    val lastPosition: Int = 0,
    val lastOffset: Int = 0,
)

@Entity(
    tableName = "bookmarks",
    foreignKeys = [ForeignKey(DocumentEntity::class, ["uri"], ["documentUri"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("documentUri")],
)
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val documentUri: String,
    val position: Int,
    val label: String?,
    val createdAt: Long,
)

@Entity(
    tableName = "document_text",
    foreignKeys = [ForeignKey(DocumentEntity::class, ["uri"], ["uri"], onDelete = ForeignKey.CASCADE)],
)
data class DocumentTextEntity(
    @PrimaryKey val uri: String,
    /** Normalised text (see TextNormalizer) of Word / PowerPoint documents the user has opened. */
    val content: String,
)

@Entity(tableName = "search_history")
data class SearchHistoryEntity(
    @PrimaryKey val term: String,
    val usedAt: Long,
)

fun DocumentEntity.toDomain() = PwpDocument(
    uri = uri,
    name = displayName,
    format = runCatching { DocumentFormat.valueOf(format) }.getOrDefault(DocumentFormat.PDF),
    sizeBytes = sizeBytes,
    pageCount = pageCount,
    lastOpenedAt = lastOpenedAt,
    isFavorite = isFavorite,
    lastPosition = lastPosition,
    lastOffset = lastOffset,
)

fun BookmarkEntity.toDomain() = Bookmark(id, documentUri, position, label, createdAt)
