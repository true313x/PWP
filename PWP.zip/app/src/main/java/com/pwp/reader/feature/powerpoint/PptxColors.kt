package com.pwp.reader.feature.powerpoint

import com.pwp.reader.core.common.XNode
import kotlin.math.abs
import kotlin.math.roundToInt

internal object Hsl {
    /** Applies DrawingML lumMod/lumOff to an 0xRRGGBB colour. */
    fun adjust(rgb: Int, lumMod: Float, lumOff: Float): Int {
        val r = ((rgb shr 16) and 0xFF) / 255f
        val g = ((rgb shr 8) and 0xFF) / 255f
        val b = (rgb and 0xFF) / 255f
        val max = maxOf(r, g, b)
        val min = minOf(r, g, b)
        val d = max - min
        val l = (max + min) / 2f
        val s = if (d == 0f) 0f else d / (1f - abs(2f * l - 1f))
        var h = 0f
        if (d != 0f) {
            val sector = when (max) {
                r -> ((g - b) / d) % 6f
                g -> (b - r) / d + 2f
                else -> (r - g) / d + 4f
            }
            h = sector * 60f
            if (h < 0f) h += 360f
        }
        val nl = (l * lumMod + lumOff).coerceIn(0f, 1f)
        val c = (1f - abs(2f * nl - 1f)) * s
        val x = c * (1f - abs((h / 60f) % 2f - 1f))
        val m = nl - c / 2f
        val (r1, g1, b1) = when ((h / 60f).toInt()) {
            0 -> Triple(c, x, 0f)
            1 -> Triple(x, c, 0f)
            2 -> Triple(0f, c, x)
            3 -> Triple(0f, x, c)
            4 -> Triple(x, 0f, c)
            else -> Triple(c, 0f, x)
        }
        fun ch(v: Float) = ((v + m) * 255f).roundToInt().coerceIn(0, 255)
        return (ch(r1) shl 16) or (ch(g1) shl 8) or ch(b1)
    }
}

internal val DEFAULT_CLR_MAP = mapOf("bg1" to "lt1", "tx1" to "dk1", "bg2" to "lt2", "tx2" to "dk2")

internal val DEFAULT_THEME = mapOf(
    "dk1" to 0x000000, "lt1" to 0xFFFFFF, "dk2" to 0x44546A, "lt2" to 0xE7E6E6,
    "accent1" to 0x4472C4, "accent2" to 0xED7D31, "accent3" to 0xA5A5A5,
    "accent4" to 0xFFC000, "accent5" to 0x5B9BD5, "accent6" to 0x70AD47,
    "hlink" to 0x0563C1, "folHlink" to 0x954F72,
)

/** Resolves DrawingML colour elements (srgb / scheme / system) against the theme and the master's colour map. */
internal class ColorResolver(private val theme: Map<String, Int>, private val clrMap: Map<String, String>) {

    /** 0xRRGGBB of a scheme colour name (bg1, tx1, accent1, ...). */
    fun scheme(name: String): Int? = theme[clrMap[name] ?: name]

    /** Opaque ARGB of a colour element, or null if it can't be resolved. */
    fun color(n: XNode): Int? {
        var rgb: Int = when (n.name) {
            "a:srgbClr" -> n.attr("val")?.toIntOrNull(16) ?: return null
            "a:schemeClr" -> scheme(n.attr("val") ?: return null) ?: return null
            "a:sysClr" -> n.attr("lastClr")?.toIntOrNull(16) ?: if (n.attr("val") == "window") 0xFFFFFF else 0x000000
            "a:prstClr" -> when (n.attr("val")) {
                "black" -> 0x000000
                "white" -> 0xFFFFFF
                "red" -> 0xFF0000
                "green" -> 0x008000
                "blue" -> 0x0000FF
                "yellow" -> 0xFFFF00
                "gray", "grey" -> 0x808080
                else -> return null
            }
            else -> return null
        }
        var lumMod = 1f
        var lumOff = 0f
        for (m in n.children) {
            val v = m.attr("val")?.toFloatOrNull()?.div(100000f)
            when (m.name) {
                "a:lumMod" -> if (v != null) lumMod = v
                "a:lumOff" -> if (v != null) lumOff = v
                "a:tint" -> if (v != null) rgb = mix(rgb, 0xFFFFFF, 1f - v)
                "a:shade" -> if (v != null) rgb = mix(rgb, 0x000000, 1f - v)
            }
        }
        if (lumMod != 1f || lumOff != 0f) rgb = Hsl.adjust(rgb, lumMod, lumOff)
        return opaque(rgb)
    }

    /** First resolvable colour child of a fill container (e.g. a:solidFill). */
    fun fill(container: XNode?): Int? = container?.children?.firstNotNullOfOrNull { color(it) }

    private fun mix(a: Int, b: Int, t: Float): Int {
        fun ch(shift: Int): Int {
            val x = (a shr shift) and 0xFF
            val y = (b shr shift) and 0xFF
            return (x + (y - x) * t).roundToInt().coerceIn(0, 255)
        }
        return (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }

    companion object {
        fun opaque(rgb: Int): Int = 0xFF000000.toInt() or (rgb and 0xFFFFFF)
    }
}
