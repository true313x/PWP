package com.pwp.reader.domain.usecase

import com.pwp.reader.domain.repository.DocumentRepository
import com.pwp.reader.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.first
import javax.inject.Inject

/** Persists the reading position unless the user turned "remember position" off. */
class SaveReadingPosition @Inject constructor(
    private val documents: DocumentRepository,
    private val settings: SettingsRepository,
) {
    suspend operator fun invoke(uri: String, position: Int, offset: Int) {
        if (settings.settings.first().rememberPosition) documents.savePosition(uri, position, offset)
    }
}
