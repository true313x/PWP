package com.pwp.reader.feature.powerpoint

import com.pwp.reader.core.common.Opc
import com.pwp.reader.core.common.Relationship
import com.pwp.reader.core.common.XNode
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.ZipFile

private val DECODABLE = setOf("png", "jpg", "jpeg", "gif", "bmp", "webp")
private const val DEFAULT_WIDTH = 9144000f
private const val DEFAULT_HEIGHT = 5143500f
private const val EMU_PER_PT = 12700f

private class Ph(val type: String?, val idx: Int?, val rect: EmuRect?, val sizePt: Float?)

private class TemplateData(
    val placeholders: List<Ph>,
    val shapes: List<SlideShape>,
    val background: Int?,
    val hidesMaster: Boolean,
    val clrMap: Map<String, String>,
    val parent: TemplateData?,
    val titleSize: Float?,
    val bodySize: Float?,
    val otherSize: Float?,
) {
    fun find(type: String?, idx: Int?, need: (Ph) -> Boolean): Ph? {
        val t = normType(type)
        placeholders.firstOrNull { idx != null && it.idx == idx && need(it) }?.let { return it }
        placeholders.firstOrNull { it.type == t && need(it) }?.let { return it }
        return parent?.find(type, idx, need)
    }
}

private fun normType(type: String?): String = when (type) {
    null, "body", "obj", "tbl", "chart", "clipArt", "dgm", "media", "pic" -> "body"
    "ctrTitle", "title" -> "title"
    else -> type
}

private class Xform(val tx: Float, val ty: Float, val sx: Float, val sy: Float) {
    fun rect(x: Float, y: Float, w: Float, h: Float) = EmuRect(tx + sx * x, ty + sy * y, w * sx, h * sy)
    companion object { val IDENTITY = Xform(0f, 0f, 1f, 1f) }
}

private class RawXfrm(val x: Float, val y: Float, val w: Float, val h: Float, val rotDeg: Float, val flipH: Boolean, val flipV: Boolean)

private fun rawXfrm(n: XNode?): RawXfrm? {
    val off = n?.child("a:off") ?: return null
    val ext = n.child("a:ext") ?: return null
    return RawXfrm(
        x = off.attr("x")?.toFloatOrNull() ?: 0f,
        y = off.attr("y")?.toFloatOrNull() ?: 0f,
        w = ext.attr("cx")?.toFloatOrNull() ?: 0f,
        h = ext.attr("cy")?.toFloatOrNull() ?: 0f,
        rotDeg = (n.attr("rot")?.toFloatOrNull() ?: 0f) / 60000f,
        flipH = n.attr("flipH") == "1",
        flipV = n.attr("flipV") == "1",
    )
}

private class ParseState {
    var partial = false
    val texts = ArrayList<String>()
}

private class Ctx(
    val partPath: String,
    val rels: Map<String, Relationship>,
    val colors: ColorResolver,
    val layout: TemplateData?,
    val state: ParseState,
)

/**
 * PPTX reader. Slides are parsed lazily one at a time (cached by the caller), layouts and masters once.
 * Handles text (with inherited placeholder positions and sizes), pictures, basic shapes, lines, tables and groups;
 * charts, SmartArt, animations, transitions and embedded media are reported as unsupported, never executed.
 */
class PptxPackage private constructor(
    private val file: File,
    private val zip: ZipFile,
    val size: SlideSize,
    private val slidePaths: List<String>,
    private val theme: Map<String, Int>,
) : AutoCloseable {

    val slideCount: Int get() = slidePaths.size
    private val templates = ConcurrentHashMap<String, TemplateData>()

    fun slide(index: Int): SlideContent {
        val path = slidePaths[index]
        val root = Opc.readXml(zip, path) ?: throw IOException("Missing slide")
        val rels = Opc.readRelationships(zip, path)
        val layout = rels.values.firstOrNull { it.type.endsWith("/slideLayout") }
            ?.let { loadTemplate(Opc.resolve(path, it.target), isMaster = false) }
        val master = layout?.parent
        val colors = ColorResolver(theme, layout?.clrMap ?: DEFAULT_CLR_MAP)
        val state = ParseState()
        val ctx = Ctx(path, rels, colors, layout, state)
        val cSld = root.child("p:cSld")

        val background = parseBackground(cSld, colors)
            ?: layout?.background ?: master?.background
            ?: ColorResolver.opaque(colors.scheme("bg1") ?: 0xFFFFFF)

        val shapes = ArrayList<SlideShape>()
        if (root.attr("showMasterSp") != "0" && layout != null) {
            if (!layout.hidesMaster && master != null) shapes += master.shapes
            shapes += layout.shapes
        }
        cSld?.child("p:spTree")?.let { parseTree(it, Xform.IDENTITY, ctx, template = false, out = shapes, phs = null) }
        return SlideContent(shapes, background, state.partial, state.texts.joinToString("\n"))
    }

    fun openEntry(name: String): InputStream? = zip.getEntry(name)?.let { zip.getInputStream(it) }

    override fun close() {
        runCatching { zip.close() }
        file.delete()
    }

    // ---------------- templates ----------------

    private fun loadTemplate(path: String, isMaster: Boolean): TemplateData = templates.getOrPut(path) {
        val root = Opc.readXml(zip, path)
        val rels = Opc.readRelationships(zip, path)
        val parent = if (isMaster) null else rels.values.firstOrNull { it.type.endsWith("/slideMaster") }
            ?.let { loadTemplate(Opc.resolve(path, it.target), isMaster = true) }
        val clrMap = if (isMaster) {
            root?.child("p:clrMap")?.attrs?.filterKeys { it in DEFAULT_CLR_MAP.keys } ?: DEFAULT_CLR_MAP
        } else parent?.clrMap ?: DEFAULT_CLR_MAP
        val colors = ColorResolver(theme, clrMap)
        val cSld = root?.child("p:cSld")
        val shapes = ArrayList<SlideShape>()
        val phs = ArrayList<Ph>()
        cSld?.child("p:spTree")?.let {
            parseTree(it, Xform.IDENTITY, Ctx(path, rels, colors, null, ParseState()), template = true, out = shapes, phs = phs)
        }
        fun masterSize(style: String): Float? = root?.child("p:txStyles")?.child(style)?.child("a:lvl1pPr")
            ?.child("a:defRPr")?.attr("sz")?.toFloatOrNull()?.div(100f)
        TemplateData(
            placeholders = phs,
            shapes = shapes,
            background = parseBackground(cSld, colors),
            hidesMaster = root?.attr("showMasterSp") == "0",
            clrMap = clrMap,
            parent = parent,
            titleSize = if (isMaster) masterSize("p:titleStyle") else parent?.titleSize,
            bodySize = if (isMaster) masterSize("p:bodyStyle") else parent?.bodySize,
            otherSize = if (isMaster) masterSize("p:otherStyle") else parent?.otherSize,
        )
    }

    private fun parseBackground(cSld: XNode?, colors: ColorResolver): Int? {
        val bg = cSld?.child("p:bg") ?: return null
        bg.child("p:bgPr")?.let { props ->
            for (ch in props.children) {
                when (ch.name) {
                    "a:solidFill" -> return colors.fill(ch)
                    "a:gradFill" -> return ch.child("a:gsLst")?.children?.firstOrNull()?.let { colors.color(it) }
                }
            }
            return null
        }
        return bg.child("p:bgRef")?.let { colors.fill(it) }
    }

    // ---------------- shape tree ----------------

    private fun parseTree(tree: XNode, tr: Xform, ctx: Ctx, template: Boolean, out: MutableList<SlideShape>, phs: MutableList<Ph>?) {
        for (n in tree.children) {
            when (n.name) {
                "p:sp" -> parseSp(n, tr, ctx, template, out, phs)
                "p:pic" -> parsePic(n, tr, ctx, out)
                "p:graphicFrame" -> parseFrame(n, tr, ctx, out)
                "p:cxnSp" -> parseConnector(n, tr, ctx, out)
                "p:grpSp" -> parseTree(n, groupTransform(n, tr), ctx, template, out, phs)
                "mc:AlternateContent" -> (n.child("mc:Choice") ?: n.child("mc:Fallback"))?.let { parseTree(it, tr, ctx, template, out, phs) }
            }
        }
    }

    private fun groupTransform(n: XNode, tr: Xform): Xform {
        val xf = n.child("p:grpSpPr")?.child("a:xfrm") ?: return tr
        val off = xf.child("a:off")
        val ext = xf.child("a:ext")
        val chOff = xf.child("a:chOff")
        val chExt = xf.child("a:chExt")
        if (off == null || ext == null || chOff == null || chExt == null) return tr
        fun f(node: XNode, key: String) = node.attr(key)?.toFloatOrNull() ?: 0f
        val cw = f(chExt, "cx")
        val ch = f(chExt, "cy")
        val kx = if (cw != 0f) f(ext, "cx") / cw else 1f
        val ky = if (ch != 0f) f(ext, "cy") / ch else 1f
        return Xform(
            tx = tr.tx + tr.sx * (f(off, "x") - f(chOff, "x") * kx),
            ty = tr.ty + tr.sy * (f(off, "y") - f(chOff, "y") * ky),
            sx = tr.sx * kx,
            sy = tr.sy * ky,
        )
    }

    private fun parseSp(n: XNode, tr: Xform, ctx: Ctx, template: Boolean, out: MutableList<SlideShape>, phs: MutableList<Ph>?) {
        val ph = n.child("p:nvSpPr")?.child("p:nvPr")?.child("p:ph")
        val spPr = n.child("p:spPr")
        val tx = n.child("p:txBody")
        val raw = rawXfrm(spPr?.child("a:xfrm"))
        val phType = ph?.attr("type")
        val phIdx = ph?.attr("idx")?.toIntOrNull()
        val ownRect = raw?.let { tr.rect(it.x, it.y, it.w, it.h) }

        if (template && ph != null) {
            val size = tx?.child("a:lstStyle")?.child("a:lvl1pPr")?.child("a:defRPr")?.attr("sz")?.toFloatOrNull()?.div(100f)
            phs?.add(Ph(normType(phType), phIdx, ownRect, size))
            return
        }

        val rect = ownRect
            ?: ctx.layout?.find(phType, phIdx) { it.rect != null }?.rect
            ?: run { ctx.state.partial = true; return }
        val rotation = raw?.rotDeg ?: 0f
        val prst = spPr?.child("a:prstGeom")?.attr("prst") ?: "rect"
        val style = n.child("p:style")

        if (prst == "line" || prst == "straightConnector1") {
            val (lc, lw) = shapeLine(spPr, style, ctx.colors)
            out += LineShape(rect, rotation, raw?.flipH ?: false, raw?.flipV ?: false, lc ?: defaultTextColor(ctx), if (lw > 0f) lw else 12700f)
            return
        }

        val geometry = when (prst) {
            "roundRect" -> Geometry.ROUND_RECT
            "ellipse" -> Geometry.ELLIPSE
            else -> Geometry.RECT
        }
        val fill = shapeFill(spPr, style, ctx.colors)
        val (lineColor, lineWidth) = shapeLine(spPr, style, ctx.colors)
        if (prst !in KNOWN_GEOMETRY && (fill != null || lineColor != null)) ctx.state.partial = true

        val text = tx?.let {
            val isBodyLike = ph != null && normType(phType) !in setOf("title", "subTitle", "dt", "ftr", "sldNum")
            val size = defaultSize(phType, phIdx, ph != null, ctx)
            parseTextBody(it, ctx, size, bulletDefault = isBodyLike, defaultColor = defaultTextColor(ctx))
        }
        if (fill != null || lineColor != null || text != null) {
            out += BoxShape(rect, rotation, geometry, fill, lineColor, lineWidth, text)
        }
    }

    private fun defaultSize(type: String?, idx: Int?, isPlaceholder: Boolean, ctx: Ctx): Float {
        if (!isPlaceholder) return ctx.layout?.otherSize ?: 18f
        ctx.layout?.find(type, idx) { it.sizePt != null }?.sizePt?.let { return it }
        return when (normType(type)) {
            "title" -> ctx.layout?.titleSize ?: 44f
            "subTitle" -> 24f
            "dt", "ftr", "sldNum" -> 12f
            else -> ctx.layout?.bodySize ?: 28f
        }
    }

    private fun defaultTextColor(ctx: Ctx): Int = ColorResolver.opaque(ctx.colors.scheme("tx1") ?: 0x000000)

    private fun shapeFill(spPr: XNode?, style: XNode?, c: ColorResolver): Int? {
        spPr?.children?.forEach { ch ->
            when (ch.name) {
                "a:noFill", "a:blipFill", "a:pattFill", "a:grpFill" -> return null
                "a:solidFill" -> return c.fill(ch)
                "a:gradFill" -> return ch.child("a:gsLst")?.children?.firstOrNull()?.let { c.color(it) }
            }
        }
        val ref = style?.child("a:fillRef")
        return if (ref != null && ref.attr("idx") != "0") c.fill(ref) else null
    }

    private fun shapeLine(spPr: XNode?, style: XNode?, c: ColorResolver): Pair<Int?, Float> {
        val ln = spPr?.child("a:ln")
        if (ln != null) {
            if (ln.child("a:noFill") != null) return null to 0f
            val color = c.fill(ln.child("a:solidFill"))
            if (color != null) return color to (ln.attr("w")?.toFloatOrNull() ?: 12700f)
        }
        val ref = style?.child("a:lnRef")
        if (ref != null && ref.attr("idx") != "0") c.fill(ref)?.let { return it to (ln?.attr("w")?.toFloatOrNull() ?: 12700f) }
        return null to 0f
    }

    private fun parseConnector(n: XNode, tr: Xform, ctx: Ctx, out: MutableList<SlideShape>) {
        val spPr = n.child("p:spPr")
        val raw = rawXfrm(spPr?.child("a:xfrm")) ?: return
        val (color, width) = shapeLine(spPr, n.child("p:style"), ctx.colors)
        out += LineShape(
            tr.rect(raw.x, raw.y, raw.w, raw.h), raw.rotDeg, raw.flipH, raw.flipV,
            color ?: defaultTextColor(ctx), if (width > 0f) width else 12700f,
        )
    }

    private fun parsePic(n: XNode, tr: Xform, ctx: Ctx, out: MutableList<SlideShape>) {
        val raw = rawXfrm(n.child("p:spPr")?.child("a:xfrm")) ?: run { ctx.state.partial = true; return }
        val rect = tr.rect(raw.x, raw.y, raw.w, raw.h)
        val rel = n.child("p:blipFill")?.child("a:blip")?.attr("r:embed")?.let { ctx.rels[it] }
        val entry = rel?.takeIf { !it.external }?.let { Opc.resolve(ctx.partPath, it.target) }
        val ext = entry?.substringAfterLast('.', "")?.lowercase()
        if (entry == null || ext == null || ext !in DECODABLE) {
            ctx.state.partial = true
            out += UnsupportedShape(rect, raw.rotDeg, UnsupportedKind.OTHER)
            return
        }
        val alt = n.child("p:nvPicPr")?.child("p:cNvPr")?.attr("descr")?.takeIf { it.isNotBlank() }
        out += PictureShape(rect, raw.rotDeg, entry, alt)
    }

    private fun parseFrame(n: XNode, tr: Xform, ctx: Ctx, out: MutableList<SlideShape>) {
        val raw = rawXfrm(n.child("p:xfrm")) ?: return
        val rect = tr.rect(raw.x, raw.y, raw.w, raw.h)
        val data = n.child("a:graphic")?.child("a:graphicData")
        val tbl = data?.child("a:tbl")
        if (tbl != null) {
            out += parseTable(tbl, rect, tr, ctx)
            return
        }
        val uri = data?.attr("uri").orEmpty()
        ctx.state.partial = true
        out += UnsupportedShape(
            rect, raw.rotDeg,
            when {
                "chart" in uri -> UnsupportedKind.CHART
                "diagram" in uri -> UnsupportedKind.SMART_ART
                else -> UnsupportedKind.OTHER
            },
        )
    }

    private fun parseTable(tbl: XNode, rect: EmuRect, tr: Xform, ctx: Ctx): TableShape {
        val columns = tbl.child("a:tblGrid")?.childrenNamed("a:gridCol").orEmpty().map { (it.attr("w")?.toFloatOrNull() ?: 0f) * tr.sx }
        val props = tbl.child("a:tblPr")
        val styled = props?.child("a:tableStyleId") != null
        val firstRow = props?.attr("firstRow") == "1"
        val banded = props?.attr("bandRow") == "1"
        val accent = ctx.colors.scheme("accent1") ?: 0x4472C4
        val white = ColorResolver.opaque(0xFFFFFF)
        val rows = tbl.childrenNamed("a:tr").mapIndexed { ri, tr0 ->
            val height = (tr0.attr("h")?.toFloatOrNull() ?: 0f) * tr.sy
            val cells = tr0.childrenNamed("a:tc").map { tc ->
                val explicit = ctx.colors.fill(tc.child("a:tcPr")?.child("a:solidFill"))
                val isHeader = styled && firstRow && ri == 0
                val fill = explicit ?: when {
                    isHeader -> ColorResolver.opaque(accent)
                    styled && banded -> ColorResolver.opaque(Hsl.adjust(accent, 0.2f, if ((ri % 2) == 1) 0.8f else 0.9f))
                    else -> null
                }
                val textColor = if (isHeader && explicit == null) white else defaultTextColor(ctx)
                val body = tc.child("a:txBody")?.let { parseTextBody(it, ctx, 18f, bulletDefault = false, defaultColor = textColor) }
                TableCell(body, fill)
            }
            TableRow(height, cells)
        }
        return TableShape(rect, 0f, columns, rows)
    }

    // ---------------- text ----------------

    private fun parseTextBody(tx: XNode, ctx: Ctx, baseSizePt: Float, bulletDefault: Boolean, defaultColor: Int): TextBody {
        val bodyPr = tx.child("a:bodyPr")
        val anchor = when (bodyPr?.attr("anchor")) {
            "ctr" -> TextAnchor.CENTER
            "b" -> TextAnchor.BOTTOM
            else -> TextAnchor.TOP
        }
        fun inset(attr: String, def: Float) = bodyPr?.attr(attr)?.toFloatOrNull() ?: def
        val fontScale = bodyPr?.child("a:normAutofit")?.attr("fontScale")?.toFloatOrNull()?.div(100000f) ?: 1f
        val listSize = tx.child("a:lstStyle")?.child("a:lvl1pPr")?.child("a:defRPr")?.attr("sz")?.toFloatOrNull()?.div(100f)
        val base = listSize ?: baseSizePt
        val counters = IntArray(9)
        val paragraphs = tx.childrenNamed("a:p").map { parseParagraph(it, ctx, base, bulletDefault, defaultColor, counters) }
        paragraphs.forEach { p -> p.text.takeIf { it.isNotBlank() }?.let { ctx.state.texts += it } }
        return TextBody(paragraphs, anchor, inset("lIns", 91440f), inset("tIns", 45720f), inset("rIns", 91440f), inset("bIns", 45720f), fontScale)
    }

    private fun parseParagraph(p: XNode, ctx: Ctx, base: Float, bulletDefault: Boolean, defaultColor: Int, counters: IntArray): SlideParagraph {
        val pPr = p.child("a:pPr")
        val level = pPr?.attr("lvl")?.toIntOrNull()?.coerceIn(0, 8) ?: 0
        val rtl = pPr?.attr("rtl") == "1"
        val align = when (pPr?.attr("algn")) {
            "ctr" -> PptAlign.CENTER
            "r" -> PptAlign.RIGHT
            "just", "dist" -> PptAlign.JUSTIFY
            "l" -> PptAlign.LEFT
            else -> if (rtl) PptAlign.RIGHT else PptAlign.LEFT
        }
        val buChar = pPr?.child("a:buChar")
        val symbolFont = pPr?.child("a:buFont")?.attr("typeface")?.let { it.startsWith("Wingdings") || it.startsWith("Symbol") } ?: false
        val bullet: String? = when {
            pPr?.child("a:buNone") != null -> { counters[level] = 0; null }
            buChar != null -> if (symbolFont) "•" else buChar.attr("char")?.takeIf { it.isNotEmpty() } ?: "•"
            pPr?.child("a:buAutoNum") != null -> { counters[level]++; "${counters[level]}." }
            bulletDefault -> "•"
            else -> null
        }
        val levelSize = if (bulletDefault && level > 0) (base - 2f * level).coerceAtLeast(10f) else base

        val runs = ArrayList<SlideRun>()
        for (c in p.children) {
            when (c.name) {
                "a:r", "a:fld" -> {
                    val rPr = c.child("a:rPr")
                    runs += SlideRun(
                        text = c.child("a:t")?.text.orEmpty(),
                        sizePt = rPr?.attr("sz")?.toFloatOrNull()?.div(100f) ?: levelSize,
                        bold = rPr?.attr("b") == "1",
                        italic = rPr?.attr("i") == "1",
                        underline = rPr?.attr("u")?.let { it != "none" } ?: false,
                        strike = rPr?.attr("strike")?.let { it != "noStrike" } ?: false,
                        color = ctx.colors.fill(rPr?.child("a:solidFill")) ?: defaultColor,
                    )
                }
                "a:br" -> runs += SlideRun("\n", levelSize, false, false, false, false, defaultColor)
            }
        }
        if (runs.isEmpty()) {
            val size = p.child("a:endParaRPr")?.attr("sz")?.toFloatOrNull()?.div(100f) ?: levelSize
            runs += SlideRun("", size, false, false, false, false, defaultColor)
        }
        return SlideParagraph(runs, align, level, bullet, rtl)
    }

    companion object {
        private val KNOWN_GEOMETRY = setOf("rect", "roundRect", "ellipse", "line", "straightConnector1")

        fun open(file: File): PptxPackage {
            val zip = ZipFile(file)
            try {
                val pres = Opc.readXml(zip, "ppt/presentation.xml") ?: throw IOException("Not a presentation")
                val sz = pres.child("p:sldSz")
                val size = SlideSize(
                    sz?.attr("cx")?.toFloatOrNull()?.takeIf { it > 0 } ?: DEFAULT_WIDTH,
                    sz?.attr("cy")?.toFloatOrNull()?.takeIf { it > 0 } ?: DEFAULT_HEIGHT,
                )
                val rels = Opc.readRelationships(zip, "ppt/presentation.xml")
                val paths = pres.child("p:sldIdLst")?.childrenNamed("p:sldId").orEmpty()
                    .mapNotNull { id -> id.attr("r:id")?.let { rels[it] } }
                    .map { Opc.resolve("ppt/presentation.xml", it.target) }
                    .filter { zip.getEntry(it) != null }
                if (paths.isEmpty()) throw IOException("No slides")
                val themePath = rels.values.firstOrNull { it.type.endsWith("/theme") }
                    ?.let { Opc.resolve("ppt/presentation.xml", it.target) } ?: "ppt/theme/theme1.xml"
                return PptxPackage(file, zip, size, paths, loadTheme(zip, themePath))
            } catch (t: Throwable) {
                runCatching { zip.close() }
                throw t
            }
        }

        private fun loadTheme(zip: ZipFile, path: String): Map<String, Int> {
            val scheme = Opc.readXml(zip, path)?.child("a:themeElements")?.child("a:clrScheme") ?: return DEFAULT_THEME
            val map = HashMap(DEFAULT_THEME)
            for (c in scheme.children) {
                val key = c.name.removePrefix("a:")
                val value = c.child("a:srgbClr")?.attr("val")?.toIntOrNull(16)
                    ?: c.child("a:sysClr")?.attr("lastClr")?.toIntOrNull(16)
                if (value != null) map[key] = value
            }
            return map
        }
    }
}
