package com.pwp.reader.feature.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pwp.reader.R
import com.pwp.reader.core.designsystem.DocumentRow
import com.pwp.reader.core.designsystem.EmptyState
import com.pwp.reader.core.designsystem.LocalSnackbarHostState
import com.pwp.reader.core.designsystem.PwpIcons
import com.pwp.reader.core.designsystem.PwpLogo
import com.pwp.reader.core.designsystem.PwpScreen
import com.pwp.reader.core.designsystem.SectionHeader
import com.pwp.reader.core.designsystem.accent
import com.pwp.reader.domain.model.DocumentFormat
import com.pwp.reader.feature.viewer.rememberDocumentLauncher
import kotlinx.coroutines.launch
import java.time.LocalTime

@Composable
fun HomeScreen(
    onOpenDocument: (DocumentFormat, String) -> Unit,
    onOpenSearch: () -> Unit,
    onOpenSettings: () -> Unit,
    onBrowseFiles: () -> Unit,
    onSeeAllRecent: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val unavailable by viewModel.unavailable.collectAsStateWithLifecycle()
    val launcher = rememberDocumentLauncher(onOpenDocument)
    val snackbar = LocalSnackbarHostState.current
    val scope = rememberCoroutineScope()
    val removedMessage = stringResource(R.string.removed_from_history)
    val greeting = stringResource(remember { greetingRes() })

    PwpScreen {
        LazyColumn(
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item(key = "header") { HomeHeader(greeting, onOpenSettings) }
            item(key = "search") { SearchEntry(onOpenSearch) }
            item(key = "actions") {
                QuickActions(
                    onPdf = launcher::openPdf,
                    onWord = launcher::openWord,
                    onPowerPoint = launcher::openPowerPoint,
                    onBrowse = onBrowseFiles,
                )
            }
            if (!state.isLoading) {
                if (state.totalCount == 0) {
                    item(key = "empty") {
                        EmptyState(
                            title = stringResource(R.string.home_empty_title),
                            body = stringResource(R.string.home_empty_body),
                            actionLabel = stringResource(R.string.action_open_document),
                            onAction = launcher::browse,
                        )
                    }
                } else {
                    item(key = "stats") {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            StatCard(stringResource(R.string.home_stat_recent), state.totalCount, Modifier.weight(1f))
                            StatCard(stringResource(R.string.home_stat_favorites), state.favoriteCount, Modifier.weight(1f))
                        }
                    }
                    item(key = "recent-header") {
                        SectionHeader(stringResource(R.string.home_recent)) {
                            TextButton(onClick = onSeeAllRecent) { Text(stringResource(R.string.home_see_all)) }
                        }
                    }
                    items(state.recent, key = { it.uri }) { d ->
                        DocumentRow(
                            document = d,
                            unavailable = d.uri in unavailable,
                            onClick = { onOpenDocument(d.format, d.uri) },
                            onToggleFavorite = { viewModel.toggleFavorite(d) },
                            onRemove = { scope.launch { viewModel.remove(d); snackbar.showSnackbar(removedMessage) } },
                        )
                    }
                }
            }
        }
    }
}

private fun greetingRes(): Int {
    val hour = LocalTime.now().hour
    return when {
        hour < 12 -> R.string.greeting_morning
        hour < 18 -> R.string.greeting_afternoon
        else -> R.string.greeting_evening
    }
}

@Composable
private fun HomeHeader(greeting: String, onOpenSettings: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        PwpLogo(size = 48.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(stringResource(R.string.app_tagline), style = MaterialTheme.typography.titleLarge)
            Text(greeting, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        IconButton(onClick = onOpenSettings) {
            Icon(PwpIcons.Settings, contentDescription = stringResource(R.string.cd_settings))
        }
    }
}

@Composable
private fun SearchEntry(onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
    ) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(PwpIcons.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(12.dp))
            Text(stringResource(R.string.search_hint), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyLarge)
        }
    }
}

@Composable
private fun QuickActions(onPdf: () -> Unit, onWord: () -> Unit, onPowerPoint: () -> Unit, onBrowse: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickActionCard(stringResource(R.string.action_open_pdf), PwpIcons.Pdf, DocumentFormat.PDF.accent(), onPdf, Modifier.weight(1f))
            QuickActionCard(stringResource(R.string.action_open_word), PwpIcons.Word, DocumentFormat.DOCX.accent(), onWord, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickActionCard(stringResource(R.string.action_open_powerpoint), PwpIcons.Slides, DocumentFormat.PPTX.accent(), onPowerPoint, Modifier.weight(1f))
            QuickActionCard(stringResource(R.string.action_browse_files), PwpIcons.OpenFolder, MaterialTheme.colorScheme.primary, onBrowse, Modifier.weight(1f))
        }
    }
}

@Composable
private fun QuickActionCard(label: String, icon: ImageVector, tint: Color, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(Modifier.padding(16.dp)) {
            Box(
                Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(tint.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center,
            ) { Icon(icon, contentDescription = null, tint = tint) }
            Spacer(Modifier.height(12.dp))
            Text(label, style = MaterialTheme.typography.titleSmall, maxLines = 2)
        }
    }
}

@Composable
private fun StatCard(label: String, value: Int, modifier: Modifier = Modifier) {
    Surface(modifier, shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainer) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text(value.toString(), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
