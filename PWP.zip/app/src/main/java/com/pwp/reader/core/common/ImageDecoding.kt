package com.pwp.reader.core.common

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.InputStream

/** Decodes an image no larger than ~[maxDimension] px on its longest side; null if undecodable. */
fun decodeSampled(maxDimension: Int, open: () -> InputStream?): Bitmap? = runCatching {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    open()?.use { BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@runCatching null
    var sample = 1
    val longest = maxOf(bounds.outWidth, bounds.outHeight)
    while (longest / (sample * 2) >= maxDimension) sample *= 2
    val options = BitmapFactory.Options().apply { inSampleSize = sample }
    open()?.use { BitmapFactory.decodeStream(it, null, options) }
}.getOrNull()
