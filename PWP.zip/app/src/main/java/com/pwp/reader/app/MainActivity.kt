package com.pwp.reader.app

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ExperimentalMaterial3WindowSizeClassApi
import androidx.compose.material3.windowsizeclass.calculateWindowSizeClass
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pwp.reader.core.designsystem.PwpTheme
import com.pwp.reader.domain.model.ThemeMode
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {
    private val incomingUri = mutableStateOf<Uri?>(null)

    @OptIn(ExperimentalMaterial3WindowSizeClassApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Only the first launch consumes the VIEW intent; recreation (language/theme change) must not reopen it.
        if (savedInstanceState == null) incomingUri.value = viewUri(intent)

        setContent {
            val appViewModel: AppViewModel = hiltViewModel()
            val settings by appViewModel.settings.collectAsStateWithLifecycle()
            val s = settings
            if (s != null) {
                val dark = when (s.themeMode) {
                    ThemeMode.SYSTEM -> isSystemInDarkTheme()
                    ThemeMode.LIGHT -> false
                    ThemeMode.DARK -> true
                }
                DisposableEffect(dark) {
                    enableEdgeToEdge(
                        statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark },
                        navigationBarStyle = SystemBarStyle.auto(
                            Color.argb(0xE6, 0xFF, 0xFF, 0xFF),
                            Color.argb(0x80, 0x1B, 0x1B, 0x1B),
                        ) { dark },
                    )
                    onDispose { }
                }
                PwpTheme(darkTheme = dark, accent = s.accent) {
                    PwpApp(
                        windowSizeClass = calculateWindowSizeClass(this@MainActivity),
                        incomingUri = incomingUri.value,
                        onIncomingConsumed = { incomingUri.value = null },
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        viewUri(intent)?.let { incomingUri.value = it }
    }

    private fun viewUri(intent: Intent?): Uri? = if (intent?.action == Intent.ACTION_VIEW) intent.data else null
}
