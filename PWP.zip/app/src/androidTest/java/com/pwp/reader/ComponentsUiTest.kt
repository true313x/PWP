package com.pwp.reader

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.platform.app.InstrumentationRegistry
import com.pwp.reader.core.designsystem.DocumentRow
import com.pwp.reader.core.designsystem.EmptyState
import com.pwp.reader.core.designsystem.PwpTheme
import com.pwp.reader.core.navigation.PwpNavigationBar
import com.pwp.reader.core.navigation.Routes
import com.pwp.reader.core.navigation.TopLevelDestination
import com.pwp.reader.domain.model.AccentColor
import com.pwp.reader.domain.model.DocumentFormat
import com.pwp.reader.domain.model.PwpDocument
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

class ComponentsUiTest {
    @get:Rule val rule = createComposeRule()

    private val context get() = InstrumentationRegistry.getInstrumentation().targetContext

    private val document = PwpDocument(
        uri = "content://x/1", name = "Quarterly report.pdf", format = DocumentFormat.PDF, sizeBytes = 2048,
        pageCount = 12, lastOpenedAt = System.currentTimeMillis(), isFavorite = false, lastPosition = 0, lastOffset = 0,
    )

    @Test fun bottomNavigationShowsAllFiveSectionsAndReportsSelection() {
        var selected: TopLevelDestination? = null
        rule.setContent { PwpTheme(false, AccentColor.INDIGO) { PwpNavigationBar(Routes.HOME, onNavigate = { selected = it }) } }
        TopLevelDestination.entries.forEach { rule.onNodeWithText(context.getString(it.label)).assertIsDisplayed() }
        rule.onNodeWithText(context.getString(R.string.nav_files)).performClick()
        assertEquals(TopLevelDestination.FILES, selected)
    }

    @Test fun documentRowTogglesFavoriteAndOpens() {
        var favorite = 0
        var opened = 0
        rule.setContent {
            PwpTheme(false, AccentColor.INDIGO) {
                DocumentRow(document, unavailable = false, onClick = { opened++ }, onToggleFavorite = { favorite++ }, onRemove = null)
            }
        }
        rule.onNodeWithContentDescription(context.getString(R.string.favorite_add), useUnmergedTree = true).performClick()
        rule.onNodeWithText("Quarterly report.pdf", substring = true, useUnmergedTree = true).performClick()
        assertEquals(1, favorite)
        assertEquals(1, opened)
    }

    @Test fun unavailableDocumentsAreMarked() {
        rule.setContent { PwpTheme(true, AccentColor.TEAL) { DocumentRow(document, true, {}, {}, null) } }
        rule.onNodeWithText(context.getString(R.string.file_unavailable), useUnmergedTree = true).assertIsDisplayed()
    }

    @Test fun emptyStateShowsMessageAndAction() {
        var clicked = false
        rule.setContent {
            PwpTheme(false, AccentColor.INDIGO) {
                EmptyState("Nothing", "Body text", actionLabel = "Open", onAction = { clicked = true })
            }
        }
        rule.onNodeWithText("Nothing").assertIsDisplayed()
        rule.onNodeWithText("Open").performClick()
        assertTrue(clicked)
    }
}
