# PWP — Document Reader (Android)

Premium, offline, multilingual reader for **PDF, DOCX and PPTX**. Kotlin · Jetpack Compose · Material 3 · Clean Architecture + MVVM · Hilt · Room · DataStore · Navigation Compose.

> **Build status: NOT compiled and NOT run.** The environment this project was written in had no Android SDK, no Gradle and no network access, so nothing below has been built or tested. Only the static checks in `tools/` were executed (see "Verification"). Expect a first round of compile fixes on your machine.

## Build

1. Open the folder in Android Studio (Ladybug or newer, JDK 17) — it will create the Gradle wrapper and sync. Or, with Gradle 8.10+ installed: `gradle wrapper --gradle-version 8.10.2`.
2. `./gradlew assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`
3. `./gradlew testDebugUnitTest` (unit tests) · `./gradlew connectedDebugAndroidTest` (Compose UI tests, needs a device/emulator)
4. Release: create `keystore.properties` (`storeFile`, `storePassword`, `keyAlias`, `keyPassword`) in the project root, then `./gradlew assembleRelease`.

## What is implemented

| Area | Notes |
|---|---|
| Design system | Custom M3 light/dark schemes (indigo-blue default, 5 contrast-checked accents), 4dp grid, file-type accents, custom empty-state illustration, adaptive launcher icon recreated as vectors from `design/pwp-icon-source.png` |
| Navigation | Home · Files · Favorites · Recent · Settings; bottom bar on phones, rail on wide screens; per-tab state saved/restored; reduced-motion aware |
| Home / Files / Search | Real SAF pickers (PDF / Word / PowerPoint / browse), history list, list+grid, sort (name/date/size/type), format filter, filename search that folds Arabic/Persian letter variants, diacritics and digits; content search over Word/PowerPoint documents you opened; recent searches |
| PDF | `PdfRenderer`, lazy per-page rendering, cancellable, byte-bounded LRU cache, pinch / double-tap zoom, fit width / fit page, rotate, go-to-page, bookmarks, fullscreen, print (framework), share original, info, saved position, password prompt (Android 15+) |
| Word | Own DOCX parser: headings, runs (bold/italic/underline/strike/colour/size), alignment, bulleted & numbered lists (multi-level), tables (spans, shading), hyperlinks (http/https/mailto/tel only), images, page/section breaks, RTL paragraphs; reader: text size, line spacing, margins, light/dark/auto, find-in-document with highlights, bookmarks, saved position |
| PowerPoint | Own PPTX parser: slides in order, text with inherited placeholder geometry/sizes, fills, rounded rects/ellipses/lines, pictures, tables, groups, master/layout shapes, theme colours; pager with swipe, thumbnails strip, pinch zoom, presentation (fullscreen, landscape for landscape decks), saved slide |
| Persistence | Room (documents, favourites, positions, bookmarks, content index, search history), DataStore (settings), persisted URI permissions |
| i18n | English, Arabic, Persian, Spanish, French, German, Chinese; per-app language via `AppCompatDelegate` (activity recreated, state kept); RTL; bidi-isolated filenames |
| Privacy | No INTERNET or storage permission, no analytics/ads/accounts, `allowBackup=false`, temp copies deleted on start and close, no macro/script execution, zip-bomb and size limits |

## Not supported / known limitations (please read)

* **DOC and PPT (legacy binary) are not supported** — they are not offered in pickers and are rejected with a message.
* **Kurdish is not included**: no reviewed translation was available. Add `values-ckb/strings.xml` (see `tools/gen_strings.py`) after native-speaker review.
* All translations were written without native review — have them checked before release.
* PDF: no text search, selection or OCR (platform `PdfRenderer` is image-only). Password-protected PDFs open only on Android 15+. Zoom beyond ~2048 px render width is upscaled.
* DOCX: headers/footers, footnotes, text boxes, charts, EMF/WMF images are skipped (a notice is shown); numbering linked only through styles is not resolved; layout is approximate, not Word-exact.
* PPTX: charts, SmartArt, animations, transitions, media are shown as labelled placeholders; only rect/roundRect/ellipse/line geometries are drawn; picture crops, flips on pictures, and per-level master text styles beyond level-1 size are not applied.
* Content search covers only Word/PowerPoint files that were opened in PWP (PDF text is not indexed).
* No document thumbnails in lists (type badges are used instead); Coil was deliberately not added.
* Tests: unit tests (normaliser, filter/sort, repository with fake DAOs, DOCX and PPTX parsers) and a few Compose component tests exist. There are **no** instrumented end-to-end reading-flow tests, Room DAO tests or RTL screenshot tests.

## Layout

```
app/src/main/java/com/pwp/reader
  app/            Application, MainActivity, root composable
  core/           common (text normaliser, XML/OPC, errors), storage (SAF), designsystem, navigation, localization, di
  data/           Room database + repository implementations (DataStore for settings)
  domain/         models, repository interfaces, use cases
  feature/        home, files, search, favorites, recent, settings, viewer (shared), pdf, word, powerpoint
tools/            gen_strings.py (strings for 7 languages), static_check.py, import_check.py
design/           original icon artwork
```

## Dependencies (all Apache-2.0)

AndroidX (core, appcompat, activity, lifecycle, navigation, Room, DataStore), Compose BOM + Material 3 + material-icons-extended, Hilt/Dagger, kotlinx.coroutines. Test only: JUnit, kxml2/xmlpull (JVM XML parser), coroutines-test, Compose UI test. No third-party document engines — PDF uses the platform renderer; DOCX/PPTX use the in-repo parsers (`feature/word`, `feature/powerpoint`).

## Verification performed

`tools/gen_strings.py` (every `R.string` used in code exists in all 7 languages with matching format placeholders), `tools/static_check.py` (package/dir agreement, balanced brackets, every project import resolves), `tools/import_check.py` (heuristic for missing imports). **No compiler, test or APK build was run.**
